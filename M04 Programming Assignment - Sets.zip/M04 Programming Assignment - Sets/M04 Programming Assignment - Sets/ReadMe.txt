Project Name: Power of Sets!
Author: Michael Krause
Last Update: 3/04/2022
Purpose: Take in words from a text file and store them in a set. Print set in Ascending Order with no dublicate words.

Assignment:
Write a program that reads words from a text file and displays all the nonduplicate words in ascending order.

My Implementation:
The infile opens the text file with the list of repeated words. The while loop runs through the file one word at 
a time. Once a space is found it stops and considers that the string which is stored in 'Temp'. The word in 'Temp' is
then immediately inserted to the set of strings 'Words' until the file is empty. 

I used the iterator for the set 'i' and set it equal to the beginning of the set in memory. This is why the dereference
operator is needed to print the value at that location is memory. Incrementing the iterator just moves it to the next
memory location which is then printed printed on the next iteration of the while loop. Loop runs until it reaches the
end of the set. The great thing about sets is they were designed to hold non dublicate information and order the information
is ascending order from front to back. You could print from rear to front and have descending order. Printing in descending
the DoWhile is needed to make sure the first value in 'Words' is printed and then the loop end.

I included a function to print in descending order as well and gave the user the choice to print the list in ascending or
descending order.