/*
Project Name: Power of Sets!
Author: Michael Krause
Last Update: 3/04/2022
Purpose: Take in words from a text file and store them in a set. Print set in Ascending Order with no dublicate words.
*/

#include <iostream>
#include <fstream>
#include <string>
#include <set>
using namespace std;

void PrintAscending(set<string> &Words) {

    cout << "**Ascending Order Of Set**" << endl;
    set<string>::iterator i = Words.begin();    //Create iterator for set 

    while (i != Words.end()) {                  //Loop to run through set and print the iterator location until end
        cout << *i << endl;                     //Print value at iterator location with dereference operator(*)
        i++;                                    //Increment iterator to next word
    }
};

void PrintDescending(set<string> &Words) {

    cout << "**Descending Order Of Set**" << endl;
    set<string>::iterator i = Words.end();      //Create iterator for set

    do {                                        
        if (i == Words.end()) {                 //Words end is Null so we need to go one location back or program breaks
            i--;
        }
        else {                                  //Prints each value in set from end to beginning
            cout << *i << endl;                 //Use dereference operator to print value
            i--;                                //Decrement iterator to previous word
        }
    } while (i != Words.begin());               //End DoWhile loop after the first value in set has printed
};

//
//Main
//
int main() {

    ifstream inFile("test.txt");                //Open input stream for text file
    set<string> Words;                          //Create string set 'Words'
    string Temp;                                //String to store each incoming string value
    bool boolean = true;                       //Boolean value for Main Menu loop

    while (inFile >> Temp) {                    //Run through text document and store each word in set
        Words.insert(Temp);                     //Insert new string into the set from text file
    }
    inFile.close();                             //close input stream from file
    
    while (boolean) {

        cout << "See the list in Ascending or Descending Order." << endl;
        cout << "1. Ascending Order" << endl;
        cout << "2. Descending Order" << endl;
        cout << "3. End Program" << endl;
        cout << "Input: ";
        cin >> Temp;
        cout << endl;

        try {
            if (Temp == "1") {
                PrintAscending(Words);              //Print the set in Ascending Order
                cout << endl;                       //Skip a line
                continue;                           //Continue to next iteration of loop
            }
            if (Temp == "2") {
                PrintDescending(Words);             //Print the set in Descending Order
                cout << endl;                       //Skip a line
                continue;                           //Continue to next iteration of loop
            }
            if (Temp == "3") {
                cout << "Goodbye" << endl;          //Print farewell
                boolean = false;                    //Change boolean to false to end loop
                continue;                           //Continue to next iteration which will check the conditional
            }
            else {
                throw string("Invalid Entry. Please input 1-3 only.");          //Prompt User with correct entry
            }
        }
        catch (string err) {
            cout << err << endl;                    //Print thrown string
            cin.clear();                            //Clear the input stream
            cin.ignore(1, '\n');                    //Ignore anything left behind
        }
    }

    return 0;
}