/*
Program name: Sorry! the digital version
Author: Michael Krause
Last updated: 7/31/2021
Purpose: Play the game sorry
Variables:
PlayerSize-stores the number of players set the loops to it
Size-used in the validation loop of PlayerSize
count-count in for loops
count1-count used in nested for loops
countup-used as count to display the user with the current player number
index-used to store the other user when comparing players to each other
x-used to store the last place or first place player and compare it to the other players
die1-stores the first RNG (dice roll)
die2-stores the second RNG (dice roll)
totaldie-stores the addition of both RNG's
foul-used to determine whether player has rolled doubles or multiple doubles
w-used to store winning player
currentb-used to carry over the data from void function displaying board and updates the current players struct with the array location of their game token
response-used to briefly store input from user
again-used in validation loop to play game again
previousboard-used to carry over the data from void function displaying board and updates the current players struct with the previous array location so that after board has been displayed this value will be returned to the array before the next round
Enum values:
(Since I don't know how to use bool yet)
False-always 0 and useful for while loops
True-always 1 and useful to break while loops
*/

//Headers
#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>
using namespace std;

//Display Board saved in an array
string Board[14][13] = {
"W  ","49 ","48 ","47 ","46 ","45 ","44 ","43 ","42 ","41 ","40 ","39 ","38 ",
"1  "," "," "," "," ","                       "," "," "," "," "," "," ","37 ",
"2  "," "," "," "," ","                       "," "," "," "," "," "," ","36 ",
"3  "," "," ","            ","*","T","H","E","*","            "," "," ","35 ",
"4  "," "," "," "," "," ","                       "," "," "," "," "," ","34 ",
"5  "," "," "," ","  ","***","                 ","***","  "," "," "," ","33 ",
"6  "," ","           *", "G","A","M","E"," ","O","F","*           "," ","32 ",
"7  "," "," "," "," "," "," ","                       "," "," "," "," ","31 ",
"8  "," "," "," "," "," "," ","                       "," "," "," "," ","30 ",
"9  "," ","            ","*","S","O","R","R","Y","*","            "," ","29 ",
"10 "," "," "," ","  ","***","                 ","***","  "," "," "," ","28 ",
"11 "," "," "," "," "," "," ","                       "," "," "," "," ","27 ",
"12 "," "," "," "," "," "," ","                       "," "," "," "," ","26 ",
"13 ","14 ","15 ","16 ","17 ","18 ","19 ","20 ","21 ","22 ","23 ","24 ","25 " };

//Variables
int PlayerSize, Size, player, count, count1, countup = 1, index, x, die1, die2, totaldie, foul, w, currentb;
string response, again, previousboard;
string token1 = "\033[0;34mP1" "\033[0;0m ";
string token2 = "\033[0;32mP2" "\033[0;0m ";
string token3 = "\033[0;33mP3" "\033[0;0m ";
string token4 = "\033[0;36mP4" "\033[0;0m ";

//Enum (just cause)
enum {
    False, True
};

//Arrays
struct Character {
    string name;
    int number;
    int location;
    int start = 0;
    int b;
    string token;
    string previous = "***";
    string board;
    string status = "Playing";
};
//Functions
//Print the rules of Sorry!
void printtherules(string) {
    cout << "\nTHE RULES OF SORRY!\n\n1. The dice have special conditions:\n\n2 = Move two spaces\n3 = Move three spaces\n4 = Move back one space.\n5 = Move five spaces.\n6 = Move six spaces.\n7 = Swap spots with the leading layer / or nothing if player is in lead.\n8 = Move Eight spaces.\n9 = Move nine spaces.\n10 = Move ten spaces.\n11 = Swap spots with the last player / or do nothing if player is last.\n12 = Start Over\n\n2. A player must roll a double to start.\n\n3. If a player lands on the same space as another, the other player must return to the beginning. Example: If P1 lands on a space where P3 is, P3 would go back to the start.\n\n4. A player must roll an EXACT number to enter the winning space.\n\nEND OF RULES" << endl;
}
//To make sure an accidental press of enter doesn't start another game
void playagain(string response) {
    x = False;
    while (x == False) {
        if (response == "yes" || response == "no") {
            x = True;
        }
        else {
            cout << "\nInvalid response. 'yes' or 'no' to playing again?" << endl;
            cin >> response;
        }
    }
    again = response;
}//end playagain

//Validate correct number of players
void validatePlayerSize(int PlayerSize) {
    x = False;
    //Statement remains "false" until a proper entry is put in
    while (x == False) {
        if (PlayerSize == 2 || PlayerSize == 3 || PlayerSize == 4) {
            x = True;
        }
        else {
            cout << "\nInvalid input, please enter correct number of players. (2-4 players)" << endl;
            cin >> PlayerSize;
        }
    }
    //Takes the correct player size back to the main program in 'size'
    Size = PlayerSize;
}//end validatePlayerSize

//Dice Roller (RNG)
int dieroll(int die) {
    die = rand() % 6 + 1;
    return die;
}//end dieroll

//Fill Data into Board
//Fills the perimeter values of the array with the players current location. saves the array location in 'player.b' and saves the current string value in the array to 'player.board' and applies the player's icon to that location 
void fillBoard(Character player) {
    //changes color of players token

    //if player is ever at location 0, saves the start position token to '.previous' and places the players icon in that location
    if (player.location == 0) {
        if (player.number == 1) {
            player.previous = Board[5][5];
            Board[5][5] = player.token;
        }
        if (player.number == 2) {
            player.previous = Board[5][7];
            Board[5][7] = player.token;
        }
        if (player.number == 3) {
            player.previous = Board[10][5];
            Board[10][5] = player.token;
        }
        if (player.number == 4) {
            player.previous = Board[10][7];
            Board[10][7] = player.token;
        }
    }
    //if player is not at 0, whatever location the player falls on determines it's location on the perimeter of the array. 
    if (player.location >= 1 && player.location <= 13) {
        //player.b stores the players location corresponding to that location within the array
        player.b = player.location;
        //player.board stores what is currently in that location of the array
        player.board = Board[player.b][0];
        //then place the players icon or token into that location in the array
        Board[player.b][0] = player.token;
    }
    //same thing different location
    if (player.location >= 14 && player.location <= 25) {
        player.b = player.location - 13;
        player.board = Board[13][player.b];
        Board[13][player.b] = player.token;
    }
    //same thing different location
    if (player.location >= 26 && player.location <= 37) {
        player.b = (player.location - 38) * -1;
        player.board = Board[player.b][12];
        Board[player.b][12] = player.token;
    }
    //samething different location
    if (player.location >= 38 && player.location <= 49) {
        player.b = (player.location - 50) * -1;
        player.board = Board[0][player.b];
        Board[0][player.b] = player.token;
    }
    //Takes the saved positions back into the main program to update the players struct for the game. The updated data is what comes back in next time.
    previousboard = player.board;
    currentb = player.b;
}//end fillboard

//Display board
void printBoard() {
    //Prints the array one whole row at a time to make the square display properly
    for (int count = 0; count < 14; count++) {
        cout << Board[count][0] << Board[count][1] << Board[count][2] << Board[count][3] << Board[count][4] << Board[count][5] << Board[count][6] << Board[count][7] << Board[count][8] << Board[count][9] << Board[count][10] << Board[count][11] << Board[count][12] << endl;
    }//end for
}//end printBoard

//Reset The Board
void resetBoard(Character player) {
    //if player was on 0 '.previous' will place the starting icon back into it's place in the array
    if (player.location == 0) {
        if (player.number == 1) {
            Board[5][5] = player.previous;
        }
        if (player.number == 2) {
            Board[5][7] = player.previous;
        }
        if (player.number == 3) {
            Board[10][5] = player.previous;
        }
        if (player.number == 4) {
            Board[10][7] = player.previous;
        }
    }
    //if player was anywhere else it will determine where the player was and restore the original value of the array to the proper location
    if (player.location >= 1 && player.location <= 13) {
        Board[player.b][0] = player.board;
    }
    if (player.location >= 14 && player.location <= 25) {
        Board[13][player.b] = player.board;
    }
    if (player.location >= 26 && player.location <= 37) {
        Board[player.b][12] = player.board;
    }
    if (player.location >= 38 && player.location <= 49) {
        Board[0][player.b] = player.board;
    }
}//end resetBoard
//////////////////////////////////////////////////////////////////////////////
int main() {

    cout << "\nWelcome to the digital game of Sorry!" << endl;

    //Main game loop
    while (response != "Game Over") {
        //Had to make the struct array 5 instead of 4 because for some reason I was getting, segmentation fault(core dumped), if you chose 4 players until I changed the array to 5, now you can choose 4 players all day long.
        Character Player[5];
        srand(time(NULL));

        //Determine how many people are playing and set the player size accordingly
        cout << "\nHow many people will be playing today?" << endl;
        cin >> PlayerSize;
        //Validate entry
        validatePlayerSize(PlayerSize);
        PlayerSize = Size;
        //Enter player Info
        for (int count = 0; count < PlayerSize; count++) {
            cout << "\nWhat is the name of player " << countup << "?" << endl;
            //Need this 'if statement' to catch the data properly but only on the first loop
            if (count == 0) {
                cin.ignore();
            }
            getline(cin, Player[count].name);
            Player[count].number = countup;
            Player[count].location = 0;
            countup++;
        }
        //Reset countup for next game
        countup = 1;

        //Ask if user wants to see the rules
        cout << "\nWould you like to see the rules? Type 'yes' or 'no' and press enter." << endl;
        cin >> response;
        //Print rules to player if yes
        if (response == "yes") {
            printtherules(response);
        }
        //'cin.ignore()' stops it from skipping player 1's turn going from name entry into player 1's turn
        cin.ignore();
        //Print board to players
        printBoard();

        //Apply tokens to the players playing
        for (int count = 0; count < PlayerSize; count++) {
            if (count == 0) {
                Player[count].token = token1;
            }
            if (count == 1) {
                Player[count].token = token2;
            }
            if (count == 2) {
                Player[count].token = token3;
            }
            if (count == 3) {
                Player[count].token = token4;
            }
        }
        //Game Loop
        while (Player[w].status == "Playing") {
            //For Loop below to take it through each players turn and the while loop above checks for a 'winner' after each loop
            for (int count = 0; count < PlayerSize; count++) {
                //determine if player is coming in with a double roll if so it resets the count to their place.
                if (foul == 1) {
                    //if last player
                    if (count == 0) {
                        count = (PlayerSize - 1);
                    }
                    //if any other player
                    else {
                        count -= 1;
                    }
                }
                //Announce which players turn it is and tell them to hit enter to roll their dice
                cout << "\nIt is player " << Player[count].number << "'s turn. " << Player[count].name << ", when ready press enter to roll your dice." << endl;
                //
                getline(cin, response);
                //Rolls the dice and saves it into each die
                die1 = dieroll(die1);
                die2 = dieroll(die2);
                //Display dice roll
                cout << "First roll: " << die1 << "\nSecond roll: " << die2 << endl;
                //stores total of die 1 and 2
                totaldie = die1 + die2;
                //Will check to see if the player just rolled doubles twice. Sending them back to start and resetting the foul. Ends the turn immediatly.
                if (foul == 1 && die1 == die2) {
                    cout << "\nTwo doubles in a row! " << Player[count].name << ", is so lucky they are getting sent back to the starting position and their turn ends!" << endl;
                    Player[count].location = 0;
                    foul = 0;
                    //resets the loop and increase the count by one so it goes to the next player automatically
                    continue;
                }
                //Will reset 'foul' back to 0 after player fails to roll doubles twice in a row
                if (foul == 1 && die1 != die2) {
                    foul = 0;
                }
                //Once out of the starting position this loop will take effect
                if (Player[count].start == 1) {
                    //check if roll is one of these and if so add it to their location
                    if (totaldie == 2 || totaldie == 3 || totaldie == 5 || totaldie == 6 || totaldie == 8 || totaldie == 9 || totaldie == 10) {
                        Player[count].location += totaldie;
                        //Check if player has hit 50, declaring them the winner and ending the game 
                        if (Player[count].location == 50) {
                            Player[count].status = "winner";
                            w = count;
                            //breaks the current loop and changes the current players status to winner and carries the current player to the while loop to check status and exit the while loop 
                            break;
                        }
                        //Check if player is over 50 and subtracting 50 to essentially make the board a round robin effect
                        if (Player[count].location > 50) {
                            Player[count].location -= 50;
                        }
                        //Check if player is on the same square
                        x = Player[count].location;
                        index = count;
                        for (count1 = 0; count1 < PlayerSize; count1++) {
                            if (x == Player[count1].location && Player[count1].start == 1) {
                                if (count1 != count) {
                                    index = count1;
                                }
                            }
                        }
                        //if count is equal to index then it's the same player. Allow player to move to position
                        if (count == index) {
                            cout << "\n" << Player[count].name << " has moved " << totaldie << " spaces." << endl;
                        }
                        //if count is not equal to index then it's another player in the same location. Send other player back to start
                        if (count != index) {
                            Player[index].location = 0;
                            cout << "\n" << Player[count].name << " has landed on " << Player[index].name << " and sent them back to the start position." << endl;
                        }
                    }
                    //if player roll four subtract 1 space from their location
                    if (totaldie == 4) {
                        Player[count].location -= 1;
                        if (Player[count].location == 0) {
                            cout << "\n" << Player[count].name << " has been moved back to the start position." << endl;
                        }
                        if (Player[count].location > 0) {
                            cout << "\n" << Player[count].name << " has been moved back 1 space to " << Player[count].location << "." << endl;
                            x = Player[count].location;
                            index = count;
                            for (count1 = 0; count1 < PlayerSize; count1++) {
                                if (x == Player[count1].location && Player[count1].start == 1) {
                                    if (count1 != count) {
                                        index = count1;
                                    }
                                }
                            }
                            //If players land on the same square, send other player back to start.
                            if (count != index) {
                                Player[index].location = 0;
                                cout << "\n" << Player[count].name << " has landed on " << Player[index].name << " and sent them back to the start position." << endl;
                            }
                        }
                        if (Player[count].location < 0) {
                            Player[count].location = 0;
                            cout << "\n" << Player[count].name << " is already on the start position. You can not go back further!" << endl;
                        }
                    }
                    //if player roll 7 swap with the leader
                    if (totaldie == 7) {
                        //find the current leader
                        x = Player[count].location;
                        for (count1 = 0; count1 < PlayerSize; count1++) {
                            if (x <= Player[count1].location && Player[count1].start == 1) {
                                x = Player[count1].location;
                                index = count1;
                            }
                        }
                        //swap places with leader
                        if (count != index) {
                            Player[index].location = Player[count].location;
                            Player[count].location = x;
                            cout << "\n" << Player[count].name << ", has switched places with " << Player[index].name << "." << endl;
                        }
                        //if player is already in the lead
                        else if (index == count) {
                            cout << "\n" << Player[count].name << " is already in the lead and will keep their position." << endl;
                        }
                    }
                    //if player rolls an 11 swap with last place who is not in starting position
                    if (totaldie == 11) {
                        //stores current players location in x
                        x = Player[count].location;
                        //compares all other players against x to find anyone in a higher position and stores the players count as index for comparison
                        for (count1 = 0; count1 < PlayerSize; count1++) {
                            if (x >= Player[count1].location && Player[count1].start == 1) {
                                x = Player[count1].location;
                                index = count1;
                            }
                        }
                        //if count and index don't equal then the two players swap 
                        if (count != index) {
                            Player[index].location = Player[count].location;
                            Player[count].location = x;
                            cout << "\n" << Player[count].name << " has switched places with " << Player[index].name << "." << endl;
                        }
                        //if count and index do equal then players is already in last
                        if (count == index) {
                            cout << "\n" << Player[count].name << " is already in the last place and will keep their position." << endl;
                        }
                    }
                    //if player rolls a 12 whether through doubles or addition and then they are sent back to 0
                    if (totaldie == 12) {
                        Player[count].location = 0;
                        cout << "\n" << Player[count].name << " has been moved back to the starting point for rolling a 12." << endl;
                    }
                    //determines if player has rolled doubles and applys a foul to the player
                    if (die1 == die2 && foul == 0) {
                        cout << "\nCongratulations! " << Player[count].name << " rolled doubles and gets another turn!" << endl;
                        foul = 1;
                    }
                }//Outside of starting position
                if (Player[count].start == 0) {
                    //if player rolls doubles change their start to 1 so the rest of the game takes effect and this if statement is forever blocked off
                    if (die1 == die2) {
                        cout << "\nGreat! " << Player[count].name << " is no longer trapped in the starting position!" << endl;
                        Player[count].location = totaldie;
                        Player[count].start = 1;
                        //Check to see if there is another player on current players location and send them back to start if so
                        x = Player[count].location;
                        index = count;
                        for (count1 = 0; count1 < PlayerSize; count1++) {
                            if (x == Player[count1].location && Player[count1].start == 1) {
                                if (count1 != count) {
                                    index = count1;
                                }
                            }
                        }
                        //If count and index are equal it's the same player
                        if (count == index) {
                            cout << "\n" << Player[count].name << " has moved " << totaldie << " spaces." << endl;
                        }
                        //If count and index are not equal then there is another player on the square, send the other back to start position
                        if (count != index) {
                            Player[index].location = 0;
                            cout << "\n" << Player[count].name << " has landed on " << Player[index].name << " and sent them back to the start position." << endl;
                        }
                    }
                    //If player hasn't rolled doubles      
                    if (die1 != die2) {
                        cout << "\nSorry " << Player[count].name << ", but without getting doubles you can't leave the starting gate. Better luck next turn." << endl;
                    }
                }//Inside starting position
            }//Game for loop bracket: (above)
            //Check for winner
            if (Player[w].status == "winner") {
                break;
            }
            //Print the Board array and returns data for tracking players location in array and restoring original values after each turn
            for (int count = 0; count < PlayerSize; count++) {
                fillBoard(Player[count]);
                Player[count].board = previousboard;
                Player[count].b = currentb;
            }
            //Print Board to player with all current player stats new line is cosmetics
            cout << "\n";
            printBoard();
            //Loop to reset the game board back to it's original values for the new player data coming in on the next phase 
            for (int count = 0; count < PlayerSize; count++) {
                resetBoard(Player[count]);
            }
            //Print Player Info Every Loop after printing board
            //for (count=0; count<PlayerSize; count++){
            //Header
              //cout << "\n" << Player[count].name << "'s Data" << endl;
              //cout << setfill('-') << setw(20) << "\n";
            //Players name
              //cout << "Name: " << Player[count].name << endl;
            //Players placeholder number
              //cout << "Player: " << Player[count].number << endl;
            //Location on board
              //cout << "Location: " << Player[count].location << endl;
            //Status on whether player has gotten their first double
              //cout << "Stage: " << Player[count].start << endl;
            //Status on whether player has won
              //cout << "Status: " << Player[count].status << endl;
            //}
        }//while bracket: (above)
        //Announce winner
        cout << "\nCongratulations! " << Player[w].name << " just stomped all over everyone else and has won the game!" << endl;
        //Prompt User to play again  
        cout << "\nDo you want to play again?\nType 'yes' or 'no' and press enter." << endl;
        getline(cin, response);
        //validation loop to make sure game doesn't repeat on accident
        playagain(response);
        response = again;
        //Repeats game or ends program
        if (response == "no") {
            response = "Game Over";
        }
        else {
            response.clear();
        }
    }//while bracket: (above)
    //Outing message to player
    cout << "\nThank you for playing. Come back anytime!" << endl;
}//main bracket: (above)



//See you spacecowboy...