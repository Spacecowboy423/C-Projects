Program Name: Q&A (queue and array)
Author: Michael Krause
Last Updated: 2/22/2022
Purpose: To use the template of a queue class from the book to make a program using a queue array.

Problem Statement:
13. This chapter describes the array implementation of queues that use a special array slot, called the reserved slot, to distinguish 
between an empty and a full queue. Write the definition of the class and the definitions of the function members of this queue 
design. Also, write a test program to test various operations on a queue.

My Application:
I made a few modifications to the class definitions, and I modified the template class given class by adding some void function
needed for the program design I had in mind. I did the same thing as the linked queue program but I changed the functions to fit
with the type of queue being used in the program. I made a menu-driven program to allow the user the option of manipulating the 
queue to add a number to the queue, delete the front element, get the size of the queue, print the front element, print the rear 
element, add all the numbers in the queue for a grand total, print out the entire queue, or the user can simply end the program. 

Because the class is from the book, I'm only going to explain the things that I added/changed and the design of my program.

Declared and Defined size():
This was fun to make because I all it does is return the current count.

Declared and Defined SumOfQueue():
The method, SumOfQueue, is used to run through the queue and add all the values together and output the result to the user. The
method checks if the queue is empty and prints an error message to the user if empty. Variable 'x' is used to store the current value
of queueFront. Variable 'total' is used to add all the numbers from the queue. The while loop uses 'x' as the beginning to start printing
and increments the value of x after each loop. While loop ends once x equals queueRear + 1 to ensure the rear item is printed before the
loop ends.

Declared and Defined toString():
The method, toString, does the exact same process as described above but each iteration is used to print the current value stored in
the front position of the queue.

Declared and Defined printMain():
The void function, printMain, is used to print the main menu the user sees each iteration of the program.

Main Program():
Declare the type and name of the queueType. Declare and initialize program variables. The while loop runs until the user decides
to end the program by entering 8. The try catch block is used to handle any exceptions from the users input in the main menu. All
options except for option 1 simply call a method and don't require further handling. The only exception to that rule is if the user
enters 1 to add a number to the queue. Instead of validating the user input I forced it into a valid input. Line 46 converts any the
entry from the user into an int variable. I then set the users entry back to the converted int before proceeding. In case the user enters
a decimal number link 48 and 49 are there to clear the input stream and ignore anything left behind, leaving a new line ready for user
entry. If the user enters any decimal only the numbers before the decimal are stored in the int variable. If user enters a char or
string a 0 is applied instead. When the user ends the program they will see a farewell message and the destructor will deallocate any
memory used.