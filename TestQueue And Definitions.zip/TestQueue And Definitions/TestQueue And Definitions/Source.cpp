/*
Program Name: Q&A (queue and array)
Author: Michael Krause
Last Updated: 2/22/2022
Purpose: To use the template of a queue class from the book to make a program using a queue array.
*/

#include <iostream>
#include "queueTemplate.h"
//#include <assert>					//In the linkedQueueType header file
//using namespace std;				//In the linkedQueueType header file

void printMain() {
	cout << "***************************************" << endl;
	cout << "**      1. Insert Number             **" << endl;
	cout << "**      2. Delete Front Number       **" << endl;
	cout << "**      3. Get Size of Queue         **" << endl;
	cout << "**      4. Print Front Number        **" << endl;
	cout << "**      5. Print Rear Number         **" << endl;
	cout << "**      6. Add Numbers in Queue      **" << endl;
	cout << "**      7. Print Entire Queue        **" << endl;
	cout << "**      8. End Program               **" << endl;
	cout << "***************************************" << endl;
}
//
//Main
//
int main() {

	queueType<int> queue;		//Declare queueType of type int
	int x = 0, y = 0, z;		//Declare program variables
	queue.initializeQueue();	//Initialize the queue

	while (x != 8) {		//While loop runs until user enters 8

		printMain();
		cin >> x;

		try {					//Try catch block handles any exceptions from users entry for menu
			
			switch (x) {		//switch case runs through the possible user entries
			case 1:
				cout << "Please input a number." << endl;
				cin >> y;

				if (y >= 0 || y < 0) {
					z = (int)y;				//Convert user input to type int
					y = z;					//Reassign 'y' a proper int value 
					cin.clear();			//Clear input stream
					cin.ignore(100, '\n');  //Ignore 100 characters or new line for input stream to get rid of anything from a decimal input 
					queue.addQueue(y);		//Call addQueue method to add item to queue
					break;
				}
				else {
					cout << "Please only input numbers." << endl;
					break;
				}

			case 2:
				if (!queue.isEmptyQueue()) {	//if statement will catch if queue is empty before it tries to print the front queue in the next line
					cout << "Number to be deleted is: " << queue.front() << endl;	//Print element to be removed from front of queue
					queue.deleteQueue();											//Delete element in front of queue
					cout << "Number has been removed successfully." << endl;		//Print successful excution message
					break;
				}
				else {
					cout << "Cannot remove from an empty queue." << endl;
					break;
				}

			case 3:
				queue.size();		//Returns count as the current size of queue
				break;

			case 4:
				if (!queue.isEmptyQueue()) {    //if statement will catch if queue is empty before it tries to print the front queue in the next line
					cout << "Front (first) number in queue is: " << queue.front() << endl;
					break;	
				}
				else {
					cout << "Queue is empty." << endl;
					break;
				}

			case 5:
				if (!queue.isEmptyQueue()) {    //if statement will catch if queue is empty before it tries to print the front queue in the next line
					cout << "Rear number in queue is: " << queue.back() << endl;
					break;
				}
				else {
					cout << "Queue is empty." << endl;
					break;
				}

			case 6:
				queue.SumOfQueue();				//Method finds the sum of all values and prints the total
				break;

			case 7:
				queue.toString();				//Method prints every element in the queue to user
				break;

			case 8:
				cout << "Thanks for using the program. Have a great day!" << endl;		//Print ending message to user
				break;

			default:
				throw string("Please only enter a number 1-8 from the main menu.");		//Throw string into ostream for exception handling
			}//end switch
		}//end try

		catch (string err) {
			cout << err << endl;
			cin.clear();
			cin.ignore(1, '\n');
		}//end catch
	}//end while
	queue.~queueType();
	return 0;
}//end main




	//queueType<int> queue;
	//int x = 0, y = 0;

	//queue.initializeQueue();
	//x = 20;
	//y = 35;
	//queue.addQueue(x);
	//queue.addQueue(y);
	//x = queue.front();
	//queue.deleteQueue();
	//queue.addQueue(x + 7);
	//queue.addQueue(78);
	//queue.addQueue(x);
	//queue.addQueue(y - 6);

	//cout << "Queue Elements: ";

	//while (!queue.isEmptyQueue()) {
	//	cout << queue.front() << " ";
	//	queue.deleteQueue();
	//}// end while

	//cout << endl;