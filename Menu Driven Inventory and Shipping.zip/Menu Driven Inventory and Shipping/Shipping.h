#pragma once
#pragma once
#include <iostream>
#include <string>
using namespace std;

class Shipping {
private:
	//Fields
	string Product;
	int Quantity;
	double Price;
	double Cost;
	string Address;
	string State;
	string City;
	int Zip;
	string Company;
	string Email;
	string Phone;

public:
	//Default Constructor
	Shipping() {
		Product = "N/A";
		Quantity = 0;
		Price = 0;
		Cost = 0;
		Address = "N/A";
		State = "N/A";
		City = "N/A";
		Zip = 0;
		Company = "N/A";
		Email = "N/A";
		Phone = "N/A";
	}

	//Partial Parameterized Constructor
	Shipping(string Product, int Quantity, double Price, double Cost, string Address, string State, string City, int Zip, string Company, string Email, string Phone) {
		this->Product = Product;
		this->Quantity = Quantity;
		this->Price = Price;
		this->Cost = Cost;
		this->Address = Address;
		this->State = State;
		this->City = City;
		this->Zip = Zip;
		this->Company = Company;
		this->Email = Email;
		this->Phone = Phone;
	}

	//Accessors
	string getProduct() {
		return Product;
	}
	double getQuantity() {
		return Quantity;
	}
	double getPrice() {
		return Price;
	}
	double getCost() {
		return Cost;
	}
	string getAddress() {
		return Address;
	}
	string getState() {
		return State;
	}
	string getCity() {
		return City;
	}
	int getZip() {
		return Zip;
	}
	string getCompany() {
		return Company;
	}
	string getEmail() {
		return Email;
	}
	string getPhone() {
		return Phone;
	}

	//Setters
	void setProduct(string Product) {
		this->Product = Product;
	}
	void setQuantity(double Quantity) {
		this->Quantity = Quantity;
	}
	void setPrice(double Price) {
		this->Price = Price;
	}
	void setCost(double Cost) {
		this->Cost = Cost;
	}
	void setAddress(string Address) {
		this->Address = Address;
	}
	void setState(string State) {
		this->State = State;
	}
	void setCity(string City) {
		this->City = City;
	}
	void setZip(int Zip) {
		this->Zip = Zip;
	}
	void setCompany(string Company) {
		this->Company = Company;
	}
	void setEmail(string Email) {
		this->Email = Email;
	}
	void setPhone(string Phone) {
		this->Phone = Phone;
	}

	//toString
	void toString(ostream& ostream) {
		setPrice(getQuantity() * getCost());
		cout << "\nProduct: " << getProduct()
			<< "\nQuantity: " << getQuantity()
			<< "\nTotal Price: " << getPrice()
			<< "\nCost Per Item: " << getCost()
			<< "\nAddress: " << getAddress()
			<< "\nState: " << getState()
			<< "\nCity: " << getCity()
			<< "\nZip Code: " << getZip()
			<< "\nCompany: " << getCompany()
			<< "\nCompany Email: " << getEmail()
			<< "\nCompany Phone Number: " << getPhone();
	}
	//toString for outFile
	string toString() {
		// Set price before converting to string
		setPrice(getQuantity() * getCost());
		// To convert int, double, or float to string
		// Forced to use the stringstream to setprecision. 
		// It was filling out the bit size with 0's, only going into the outFile and only for doubles or floats
		stringstream stream, stream1, stream2;
		stream << fixed << setprecision(2) << getPrice();
		string price = stream.str();
		stream1 << fixed << setprecision(2) << getCost();
		string cost = stream1.str();
		stream2 << fixed << setprecision(2) << getQuantity();
		string quantity = stream2.str();
		
		return "Product: " + getProduct()
			+ "\nQuantity: " + quantity
			+ "\nTotal Price: " + price
			+ "\nCost Per Item: " + cost
			+ "\nAddress: " + getAddress()
			+ "\nState: " + getState()
			+ "\nCity: " + getCity()
			+ "\nZip Code: " + to_string(getZip())
			+ "\nCompany: " + getCompany()
			+ "\nCompany Email: " + getEmail()
			+ "\nCompany Phone Number: " + getPhone() + "\n\n";
	}
};