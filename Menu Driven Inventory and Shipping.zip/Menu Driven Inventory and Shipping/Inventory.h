#pragma once
#pragma once
//#include <iostream>
//#include <iomanip>
#include <string>
using namespace std;

class Inventory {
private:
	//Fields
	string Product;
	int Quantity;
	double Price;

public:
	//Default Constructor
	Inventory() {
		setProduct("N/A");
		setQuantity(0);
		setPrice(0);
	}

	//Parameterized Constructor
	Inventory(string Product, int Quantity, double Price) {
		this->Product = Product;
		this->Quantity = Quantity;
		this->Price = Price;
	}

	//Accessors
	string getProduct() {
		return Product;
	}
	int getQuantity() {
		return Quantity;
	}
	double getPrice() {
		return Price;
	}

	//Mutators
	void setProduct(string Product) {
		this->Product = Product;
	}
	void setQuantity(int Quantity) {
		this->Quantity = Quantity;
	}
	void setPrice(double Price) {
		this->Price = Price;
	}

	//toString
	void toString(ostream& ostream) {
		cout << "\nInventory item: " << getProduct()
			<< "\nAmount in inventory: " << getQuantity()
			<< "\nCost Per Item: " << getPrice();
	}
	//toString to outFile
	string toString() {
		stringstream stream;
		stream << fixed << setprecision(2) << getPrice();
		string price = stream.str();

		return "\nInventory item: " + getProduct()
			+ "\nAmount in inventory: " + to_string(getQuantity())
			+ "\nCost Per Item: " + price;
	}
};