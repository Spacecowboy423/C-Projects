#pragma once
#pragma once
#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>
using namespace std;

class Employee {
private:
	//Fields
	int EmpID;
	string First;
	string Last;
	double Rate;
	double Hours;
	double Wage;
	time_t Clock_In;
	time_t Clock_Out;
	// current date/time based on current system
	//time_t now = time(0);

	// convert now to string form
	//char* dt = ctime(&now);
public:
	//Default Constructor
	Employee() {
		setEmpID(0);
		setFirst("Unknown");
		setLast("Unknown");
		setRate(0);
		setHours(0);
		setWage(0);
		setClockIn(NULL);
		setClockOut(NULL);
		//double difftime(time_t time2, time_t time1);
	}

	//Parameterized Constructor
	Employee(int EmpID, string First, string Last) {
		this->EmpID = EmpID;
		this->First = First;
		this->Last = Last;
		setRate(0);
		setHours(0);
		setWage(0);
		setClockIn(NULL);
		setClockOut(NULL);
	}

	//Parameterized Constructor
	Employee(int EmpID, string First, string Last, double Rate, double Hours, double Wage) {
		this->EmpID = EmpID;
		this->First = First;
		this->Last = Last;
		this->Rate = Rate;
		this->Hours = Hours;
		this->Wage = Wage;
		setClockIn(NULL);
		setClockOut(NULL);
	}

	//Destructor
	~Employee() {
		//
	}

	//Accessors
	int getEmpID() {
		return EmpID;
	}
	string getFirst() {
		return First;
	}
	string getLast() {
		return Last;
	}
	double getRate() {
		return Rate;
	}
	double getHours() {
		return Hours;
	}
	double getWage() {
		return Wage;
	}
	time_t getClockIn() {
		return Clock_In;
	}
	time_t getClockOut() {
		return Clock_Out;
	}

	//Mutators
	void setEmpID(int EmpID) {
		this->EmpID = EmpID;
	}
	void setFirst(string First) {
		this->First = First;
	}
	void setLast(string Last) {
		this->Last = Last;
	}
	void setRate(double Rate) {
		this->Rate = Rate;
	}
	void setHours(double Hours) {
		this->Hours = Hours;
	}
	void setWage(double Wage) {
		this->Wage = Wage;
	}

	//
	void setClockIn(time_t Clock_In) {
		this->Clock_In = Clock_In;
	}
	void setClockOut(time_t Clock_Out) {
		this->Clock_Out = Clock_Out;
	}
	//

	//Methods
	double CalculateWage() {
		//double difftime(time_t time2, time_t time1);
		return (((getClockOut() - getClockIn())));
		// / 3.6e+6) * Rate);
	}

	//toString
	void toString(ostream& ostream) {
		cout << "\nEmployee ID: " << getEmpID()
			<< "\nEmployee: " << getFirst() << " " << getLast()
			<< "\nPay Rate: $" << getRate()
			<< "\nHours Worked: " << getHours()
			<< "\nWage: $" << getWage()
			<< "\nClock-In: " << getClockIn()
			<< "\nClock-Out: " << getClockOut();
	}
	//toString for outFile
	string toString() {
		setWage(getRate() * getHours());
		stringstream stream, stream1, stream2;
		stream << fixed << setprecision(2) << getWage();
		string wage = stream.str();
		stream1 << fixed << setprecision(2) << getHours();
		string hours = stream1.str();
		stream2 << fixed << setprecision(2) << getRate();
		string rate = stream2.str();

		return "Employee ID: " + to_string(getEmpID())
			+ "\nEmployee: " + getFirst() + " " + getLast()
			+ "\nPay Rate: $" + rate
			+ "\nHours Worked: " + hours
			+ "\nWage: $" + wage
			//+ "\nWage: $" + CalculateWage()
			+ "\nClock-In: " + to_string(getClockIn())
			+ "\nClock-Out: " + to_string(getClockOut()) + "\n\n";
	}
};