﻿/*
Program Name: Inventory Management and Shipping Log
Author: Michael Krause
Last Updated: 12/14/2021 
Purpose: The goal was to create a program that would be used in the warehouse industry to create a log of 
shipping, inventory, and employee information. Initially the plan was to have the user clock in and out instead
of reporting their wages but I didn't have time to fully implement it. Otherwise, the program will fill each database
with information from their respective text files. The user can then read or manipulate the data existing in storage or 
create and manipulate new user defined data. The information from the shipping database can be added to an external
text file to create a shipping log of all products being shipped. The user can choose how many and what to add to 
the text file. Overload operators are used to add or subtract an inventory item by 1, and print the data from each database. 
Enum 'Reset' is used to reset variables to a base of 0 after being used.
*/

//For messing with time clock
#include <windows.globalization.datetimeformatting.h>
#include "time.h"
#include <ctime>

//For program
#include <map>
#include "Employee.h"
#include "Inventory.h"
#include "Shipping.h"
#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <sstream>
using namespace std;

//boolean operator overload (--) to decrease inventory amount by 1
bool operator -- (Inventory& current) {
	try {
		if (current.getQuantity() > 0) {
			current.setQuantity(current.getQuantity() - 1);
			cout << "Quantity for: " << current.getProduct() << ", has been decreased to " << current.getQuantity() << endl;
		}
		else {
			throw string("Product cannot be reduced further.");
		}
	}
	catch (string error) {
		cout << error << endl;
	}
}
//boolean operator overload (++) to increase inventory amount by 1
bool operator ++ (Inventory& current) {
	try {
		if (current.getQuantity() >= 0) {
			current.setQuantity(current.getQuantity() + 1);
			cout << "Quantity for: " << current.getProduct() << ", has been increased to " << current.getQuantity() << endl;
		}
		else {
			throw string("Illegal Exception Handling.");
		}
	}
	catch (string error) {
		cout << error << endl;
	}
}

//ostream operators overload (<<) for Employees
ostream& operator << (ostream& ostream, Employee& current) {
	current.toString(ostream);
	return ostream;
}
//ostream operators overload (<<) for Inventory
ostream& operator << (ostream& ostream, Inventory& current) {
	current.toString(ostream);
	return ostream;
}
//ostream operators overload (<<) for Shipping
ostream& operator << (ostream& ostream, Shipping& current) {
	current.toString(ostream);
	return ostream;
}


//enum to reset a value or count back to 0, use anywhere
enum {
	Reset
};

//Void Function to store a text file in the Employee map
void FillEmployee(map<int, Employee>& Map, ifstream& inFile) {
	//Strings to hold incoming values from text file
	int ID;
	string EmpID, First, Last, Rate, Hours, Wage;
	double rate, hours, wage;
	//Loop to take in text file and store values in struct and map
	//Accepts the first value as the key and the rest as the contents for the struct
	while (getline(inFile, EmpID, ':')) {
		getline(inFile, First, ':');
		getline(inFile, Last, ':');
		getline(inFile, Rate, ':');
		getline(inFile, Hours, ':');
		getline(inFile, Wage, '\n');
		//Convert necessary string to numbers
		stringstream converter(EmpID);
		converter >> ID;
		stringstream converter1(Rate);
		converter1 >> rate;
		stringstream converter2(Hours);
		converter2 >> hours;
		stringstream converter3(Wage);
		converter3 >> wage;

		//Struct with contents from text file
		Employee employee = { ID, First, Last, rate, hours, wage };
		//Store the new struct in Map by the key value
		Map[ID] = employee;
		ID = Reset, rate = Reset, hours = Reset, wage = Reset;
	}
}
//Void Function to store a text file in the Inventoy map
void FillInventory(map<string, Inventory>& Map, ifstream& inFile) {
	//Strings to hold incoming values from text file
	string Product, Quantity, Price;
	int quantity;
	double price;
	//Loop to take in text file and store values in struct and map
	//Accepts the first value as the key and the rest as the contents for the struct
	while (getline(inFile, Product, ':')) {
		getline(inFile, Quantity, ':');
		getline(inFile, Price, '\n');
		//Convert necessary string to numbers
		stringstream converter(Quantity);
		converter >> quantity;
		stringstream converter1(Price);
		converter1 >> price;

		//Struct with contents from text file
		Inventory inventory = { Product, quantity, price };
		//Store the new struct in Map by the key value
		Map[Product] = inventory;
		quantity = Reset, price = Reset;
	}
}
//Void Function to store a text file in the Shipping map
void FillShipping(map<string, Shipping>& Map, ifstream& inFile) {
	//Strings to hold incoming values from text file
	string Product, Quantity, Price, Cost, Address, State, City, Zip, Company, Email, Phone;
	int quantity, zip;
	double price, cost;
	//Loop to take in text file and store values in struct and map
	//Accepts the first value as the key and the rest as the contents for the struct
	while (getline(inFile, Company, ':')) {
		getline(inFile, Product, ':');
		getline(inFile, Quantity, ':');
		getline(inFile, Price, ':');
		getline(inFile, Cost, ':');
		getline(inFile, Address, ':');
		getline(inFile, State, ':');
		getline(inFile, City, ':');
		getline(inFile, Zip, ':');
		getline(inFile, Email, ':');
		getline(inFile, Phone, '\n');
		//Convert necessary string to numbers
		stringstream converter(Quantity);
		converter >> quantity;
		stringstream converter1(Zip);
		converter1 >> zip;
		stringstream converter2(Price);
		converter2 >> price;
		stringstream converter3(Cost);
		converter3 >> cost;

		//Struct with contents from text file
		Shipping shipping = { Product, quantity, price, cost, Address, State, City, zip, Company, Email, Phone };
		//Store the new struct in Map by the key value
		Map[Company] = shipping;
		quantity = Reset, zip = Reset, price = Reset, cost = Reset;
	}
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Main///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int main() {
	//Map for Employees Key value is EmpID (int)
	map<int, Employee> employee;
	ifstream inFile("Employee.txt");
	FillEmployee(employee, inFile);
	inFile.close();

	//Map for Inventory Key value is the product (string)
	map<string, Inventory> inventory;
	ifstream inFile1("Inventory.txt");
	FillInventory(inventory, inFile1);
	inFile1.close();

	//Map for Shipping Key value is the Company for order (string)
	map<string, Shipping> shipping;
	//str Product, int Quantity, dou Price, dou Cost, str Address, str State, str City, int Zip, str Company, str Email, str Phone)
	//Key is Company string
	ifstream inFile2("Shipping.txt");
	FillShipping(shipping, inFile2);
	inFile2.close();

	//Testing Output stream of employee by creating an employee output file//
	ofstream outFile("EmployeeOutFile.txt");
	int count = 1;
	while (employee.find(count) != employee.end()) {
		outFile << employee.at(count).toString();
		count++;
	}
	count = Reset;
	outFile << employee.at(1).toString();
	outFile.close();
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//Menu driven variables
	int MainMenu;
	int UserInput;
	ofstream ShippingOrders("ShippingOrderFile.txt");
	
	//Inventory variables (also used for Shipping but for clarity I left this in)
	//string Product;
	//int Quantity;
	//double Price;

	//Shipping variables
	string Product;
	int Quantity;
	double Price;
	double Cost;
	string Address;
	string State;
	string City;
	int Zip;
	string Company;
	string Email;
	string Phone;

	//Employee variables
	int EmpID;
	string First;
	string Last;
	double Rate;
	double Hours;
	double Wage;
	time_t Clock_In = NULL;
	time_t Clock_Out = NULL;

	//Prompt user with message about program
	cout << "This application will allow you to search through an existing 'database'. You can add and remove shipping details, inventory items, and employee info." << endl;
	cout << "The goal was to create a program that would be used in the warehouse industry to create a log of shipping details, keep track of inventory, and keep track of employee information." << endl;
	cout << "Including using it as a time clock for employees, but this is an extra feature I didn't get worked out in time." << endl;
	cout << "Have fun trying out the program!" << endl;

	do {
		//Main loop menu
		cout << "\n*********  Main menu for application  **********" << endl;
		cout << "**                                            **" << endl;
		cout << "**      1. Enter the Inventory Database       **" << endl;
		cout << "**      2. Enter the Shipping Database        **" << endl;
		cout << "**      3. Enter the Employee Database        **" << endl;
		cout << "**      4. Exit Main Program                  **" << endl;
		cout << "**                                            **" << endl;
		cout << "************************************************" << endl;
		cin >> MainMenu;
		try {
			if (MainMenu >= 1 && MainMenu <=3) {
				switch (MainMenu) {
				//Inventory/////////////////////////////////////////////////////////////////////////////////////////
				case(1):
					//Loop runs until user enters integer 6 
					do {
						//Prompt user with menu
						cout << "\n**************  Inventory Menu ***************" << endl;
						cout << "**                                          **" << endl;
						cout << "**     1. Add Product                       **" << endl;
						cout << "**     2. Remove Product from database      **" << endl;
						cout << "**     3. Change Quantity of Product        **" << endl;
						cout << "**     4. Change Price of Product           **" << endl;
						cout << "**     5. Reduce Quantity by 1              **" << endl;
						cout << "**     6. Increase Quantity by 1            **" << endl;
						cout << "**     7. Print Inventory Product           **" << endl;
						cout << "**     8. Exit Inventory                    **" << endl;
						cout << "**          Enter an integer (1-8)          **" << endl;
						cout << "**                                          **" << endl;
						cout << "**********************************************" << endl;
						cin >> UserInput;

						try {
							//Gather Product Name
							if (UserInput >= 1 && UserInput <= 7) {
								cout << "\nWhat is the product?" << endl;
								cin >> Product;

								switch (UserInput) {
								//Add new Inventory Item
								case (1):
									if (inventory.find(Product) != inventory.end()) {
										cout << "Enter an integer for the Quantity of product: " << inventory.at(Product).getProduct() << endl;
										cin >> Quantity;
										cout << "What is the price per item of the product: " << inventory.at(Product).getProduct() << endl;
										cin >> Price;
										//Create new inventory item from user input
										inventory.emplace(Product, Inventory(Product, Quantity, Price));
										break;
									}
									else {
										cout << "Product is not contained within the inventory database." << endl;
										break;
									}

								//Remove Inventory Item
								case(2):
									if (inventory.find(Product) != inventory.end()) {
										inventory.erase(Product);
										cout << "Specified Product has been removed from Inventory." << endl;
										break;
									}
									else {
										cout << "Specified Product does not exist within database." << endl;
										break;
									}

								//Change Quantity of Inventory item
								case(3):
									//Check Product exists before changing the quantity
									if (inventory.find(Product) != inventory.end()) {
										cout << "The current quantity of " << inventory.at(Product).getProduct() << ", is " + inventory.at(Product).getQuantity() << endl;
										cout << "Please enter a new quantity for " << inventory.at(Product).getProduct() << endl;
										cin >> Quantity;
										inventory.at(Product).setQuantity(Quantity);
										cout << "Product quantity has changed to: " + inventory.at(Product).getQuantity() << endl;
										break;
									}
									else {
										cout << "Specified Product does not exist within database." << endl;
										break;
									}

								//Change Price of Inventory item
								case(4):
									//Check inventory item exists before changing the price
									if (inventory.find(Product) != inventory.end()) {
										cout << "The current price of " << inventory.at(Product).getProduct() + ", is $" << inventory.at(Product).getPrice() << endl;
										cout << "Please enter a new price for " << inventory.at(Product).getProduct() << endl;
										cin >> Price;
										inventory.at(Product).setPrice(Price);
										cout << "Price has been changed to $" << inventory.at(Product).getPrice();
										break;
									}
									else {
										cout << "Specified Product does not exist within database." << endl;
										break;
									}
								//Decrease Quantity of Product by 1 using (--) operator overload
								case(5):
									if (inventory.find(Product) != inventory.end()) {
										--inventory.at(Product);
										break;
									}
									else {
										cout << "Specified Product does not exist within database." << endl;
										break;
									}
								//Increase Quantity of Product by 1 using (++) operator overload
								case(6):
									if (inventory.find(Product) != inventory.end()) {
										++inventory.at(Product);
										break;
									}
									else {
										cout << "Specified Product does not exist within database." << endl;
										break;
									}
								//Print Product Info
								case(7):
									if (inventory.find(Product) != inventory.end()) {
										cout << inventory.at(Product) << endl;
										break;
									}
									else {
										cout << "Specified item does not exist within database." << endl;
										break;
									}
								}
							}
							//Exit Inventory
							if (UserInput == 8) {
								cout << "Leaving Inventory Menu...\n" << endl;
								break;
							}
							else {
								throw string("\nIllegal Exception Handling. Invalid Input.");
							}
						}
						catch (string err) {
							cout << err << endl;
							throw string();
							cin.clear();
							cin.ignore(1, '\n');
							break;
						}
					//End do{} while() condition
					} while (UserInput != 8);
					break;

				//Shipping///////////////////////////////////////////////////////////////////////////////////////////
				case(2):
					//Loop runs until user enters integer 7
					do {
						//Prompt user with menu
						cout << "\n*************  Shipping Menu  *************" << endl;
						cout << "**                                       **" << endl;
						cout << "**     1. Add Shipping Order             **" << endl;
						cout << "**     2. Remove Shipping Order          **" << endl;
						cout << "**     3. Edit Shipping Product          **" << endl;
						cout << "**     4. Edit Shipping Address          **" << endl;
						cout << "**     5. Edit Shipping Contact Info     **" << endl;
						cout << "**     6. Print Shipping Details         **" << endl;
						cout << "**     7. Send Shipping Order to File    **" << endl;
						cout << "**     8. Exit Shipping                  **" << endl;
						cout << "**         Enter an integer (1-8)        **" << endl;
						cout << "**                                       **" << endl;
						cout << "*******************************************" << endl;
						cin >> UserInput;

						try {
							//Gather Company name
							if (UserInput >= 1 && UserInput <= 7) {
								cout << "What is the Company attached to the shipping order?" << endl;
								cin >> Company;
							}

							switch (UserInput) {
							//Add Shipping Order
							case (1):
								//Check Company exists before adding shipping details
								if (shipping.find(Company) == shipping.end()) {
									cout << "**Product Information**" << endl;
									cout << "What is the Product or product description?" << endl;
									cin >> Product;
									cout << "What is the Quantity of the product being shipped?" << endl;
									cin >> Quantity;
									cout << "What is the Price per item of the product?" << endl;
									cin >> Price;

									Cost = Quantity * Price;

									cout << "**Shipping Information**" << endl;
									cout << "What is the Street Address?" << endl;
									cin >> Address;
									cout << "What is the State?" << endl;
									cin >> State;
									cout << "What is the City?" << endl;
									cin >> City;
									cout << "What is the Zip Code" << endl;
									cin >> Zip;

									cout << "**Contact Information**" << endl;
									cout << "What is the contacts Email?" << endl;
									cin >> Email;
									cout << "What is the contacts Phone number?" << endl;
									cin >> Phone;

									//Create new shipping order from user input
									shipping.at(Company) = Shipping(Product, Quantity, Price, Cost, Address, State, City, Zip, Company, Email, Phone);
									break;
								}
								else {
									cout << "Shipping order does not exist for " << Company << "." << endl;
									break;
								}

							//Remove Shipping Order
							case(2):
								if (shipping.find(Company) != shipping.end()) {
									shipping.erase(Company);
									cout << "Specified shipping order has been removed from the shipping database." << endl;
									break;
								}
								else {
									cout << "Specified shipping order does not exist for " << Company << "." << endl;
									break;
								}

							// Edit Product, Quantity, and Price
							case(3):
								//Check shipping order exists before editing
								if (shipping.find(Company) != shipping.end()) {
									cout << "What is the Product you are shipping?" << endl;
									cin >> Product;
									cout << "What is the Quantity of product being shipped?" << endl;
									cin >> Quantity;
									cout << "What is the Price per item of the product being shipped?" << endl;
									cin >> Price;
									break;
								}
								else {
									cout << "Specified shipping order does not exist in database for " << Company << "." << endl;
									break;
								}

							//Edit Shipping Address, State, City, and Zip
							case(4):
								//Check shipping order exists before assigning a job
								if (shipping.find(Company) != shipping.end()) {
									cout << "What is the street Address for the shipping order?" << endl;
									cin >> Address;
									cout << "What is the City for the Address?" << endl;
									cin >> City;
									cout << "What is the Zip Code for the Address?" << endl;
									cin >> Zip;
									break;
								}
								else {
									cout << "Specified shipping order does not exist in database for " << Company << "." << endl;
									break;
								}

							//Edit Contact Info Email and Phone number
							case(5):
								//Check Company exists before editting info
								if (shipping.find(Company) != shipping.end()) {
									cout << "What is the Email for, " << Company << "?" << endl;
									cin >> Email;
									cout << "What is the Phone number for, " << Company << "?" << endl;
									cin >> Phone;
									break;
								}
								else {
									cout << "Specified shipping order does not exist in database for, " << Company << "." << endl;
									break;
								}

							//Print Shipping Order to console
							case(6):
								if (shipping.find(Company) != shipping.end()) {
									cout << shipping.at(Company);
									break;
								}
								else {
									cout << "Specified shipping order does not exist for, " << Company << "." << endl;
									break;
								}
							//Add shipping order to output file
							case(7):
								if (shipping.find(Company) != shipping.end()) {
									ShippingOrders << shipping.at(Company).toString();
									cout << Company << " has been added to shipping orders." << endl;
									break;
								}
								else {
									cout << "Specified shipping order does not exist for, " << Company << "." << endl;
									break;
								}
							}
							//Exit Shipping
							if (UserInput == 8) {
								cout << "\nLeaving Shipping Menu...\n";
								break;
							}
							else {
								throw string("\nIllegal Exception Handling. Invalid Input.");
							}
						}
						catch (string err) {
							cout << err << endl;
							throw string();
							cin.clear();
							cin.ignore(1, '\n');
							break;
						}
					//End do{} while() condition
					} while (UserInput != 8);
					break;

				//Employees//////////////////////////////////////////////////////////////////////////////////////////
				case(3):
					//Loop runs until user enters integer 7
					do {
						//Prompt user with menu
						cout << "\n************  Employee Menu  *************" << endl;
						cout << "**                                      **" << endl;
						cout << "**      1. Add an Employee              **" << endl;
						cout << "**      2. Delete an Employee           **" << endl;
						cout << "**      3. Clock In                     **" << endl;
						cout << "**      4. Clock Out                    **" << endl;
						cout << "**      5. Print Employee Info          **" << endl;
						cout << "**      6. Get Wage from Time Clock     **" << endl;
						cout << "**      7. Exit                         **" << endl;
						cout << "**        Enter an integer (1-7)        **" << endl;
						cout << "**                                      **" << endl;
						cout << "******************************************" << endl;
						cin >> UserInput;

						try {
							//Gather Employee ID number 
							if (UserInput >= 1 && UserInput <= 6) {
								cout << "\nWhat is the employee ID number?" << endl;
								cin >> EmpID;

								switch (UserInput) {
								//Add Employee
								case (1):
									try {
										//Check if employee already exists in database
										if (employee.find(EmpID) != employee.end() && cin) {
											cout << "Employee ID is already in use. Cannot overwrite employee: " << employee.at(EmpID).getLast() << endl;
											break;
										}
										// Create new employee from user input after checking if already someone there
										if (employee.find(EmpID) == employee.end()) {
											cout << "What is the new employee's first name?" << endl;
											cin >> First;
											cout << "What is the new employee's last name?" << endl;
											cin >> Last;
											employee[EmpID] = Employee(EmpID, First, Last);
											cout << "New Employee has been added to the database." << endl;
											break;
										}
										else {
											throw string("\nIllegal Exception Handling. Attempted String Input.");
										}
									}
									catch (string err) {
										cout << err << endl;
										cin.clear();
										cin.ignore(1, '\n');
										break;
									}

								//Remove Employee
								case(2):
									try {
										if (employee.find(EmpID) != employee.end()) {
											employee.erase(EmpID);
											cout << "Employee has been successfully removed from the database." << endl;
											break;
										}
										if (employee.find(EmpID) == employee.end()) {
											cout << "Employee with specified ID does not exist within database." << endl;
											break;
										}
										else {
											throw string("\nIllegal Exception Handling. Attempted String Input.");
										}
									}
									catch (string err) {
										cout << err << endl;
										cin.clear();
										cin.ignore(1, '\n');
										break;
									}

								//Clock In
								case(3):
									try {
										//Check employee exists before assigning a job
										if (employee.find(EmpID) != employee.end()) {
											cout << employee.at(EmpID).getFirst() << " " << employee.at(EmpID).getLast() << ", has been clocked in." << endl;
											employee.at(EmpID).setClockIn(Clock_In);
											cout << "Clocked in at: " + employee.at(EmpID).getClockIn() << endl;
											break;
										}
										if (employee.find(EmpID) == employee.end()) {
											cout << "Employee does not exist in database. Check employee ID and try again." << endl;
											break;
										}
										else {
											throw string("\nIllegal Exception Handling. Attempted String Input.");
										}
									}
									catch (string err) {
										cout << err << endl;
										cin.clear();
										cin.ignore(1, '\n');
										break;
									}

								//Clock Out
								case(4):
									try {
										//Check employee exists before assigning a job
										if (employee.find(EmpID) != employee.end()) {
											cout << employee.at(EmpID).getFirst() << " " << employee.at(EmpID).getLast() << ", has been clocked out." << endl;
											employee.at(EmpID).setClockOut(Clock_Out);
											cout << "Clocked out at: " + employee.at(EmpID).getClockOut() << endl;
											break;
										}
										if (employee.find(EmpID) == employee.end()) {
											cout << "Employee does not exist in database. Check employee ID and try again." << endl;
											break;
										}
										else {
											throw string("\nIllegal Exception Handling. Attempted String Input.");
										}
									}
									catch (string err) {
										cout << err << endl;
										cin.clear();
										cin.ignore(1, '\n');
										break;
									}

								//Print Employee
								case(5):
									try {
										if (employee.find(EmpID) != employee.end()) {
											cout << employee.at(EmpID) << endl;
											break;
										}
										if (employee.find(EmpID) == employee.end()) {
											cout << "Specified employee ID does not exist within database." << endl;
											break;
										}
										else {
											throw string("\nIllegal Exception Handling. Attempted String Input.");
										}
									}
									catch (string err) {
										cout << err << endl;
										cin.clear();
										cin.ignore(1, '\n');
										break;
									}

								//Report daily wages back to employee from time clock
								case(6):
									try {
										if (employee.find(EmpID) != employee.end() && employee.at(EmpID).getClockIn() != NULL && employee.at(EmpID).getClockOut() != NULL) {
											//Set wage by subtracting clock-out by clock-in, convert milliseconds to hours, multiply by rate
											employee.at(EmpID).setWage(employee.at(EmpID).CalculateWage());
											cout << "Potential wage based on time clock:\n$" << employee.at(EmpID).getWage() << endl;
											break;
										}
										if (employee.find(EmpID) != employee.end() && (employee.at(EmpID).getClockIn() == NULL || employee.at(EmpID).getClockOut() == NULL)) {
											cout << "Employee needs to clock in and clock out before the system can process their wage." << endl;
											break;
										}
										if (employee.find(EmpID) == employee.end()) {
											cout << "Specified Employee ID could not be found in the database." << endl;
											break;
										}
										else {
											throw string("\nIllegal Exception Handling. Attempted String Input.");
										}
									}
									catch (string err) {
										cout << err << endl;
										cin.clear();
										cin.ignore(1, '\n');
										break;
									}
								}
							}
							//Exit Employee
							if (UserInput == 7) {
								cout << "Leaving Employee Menu..." << endl;
								break;
							}
							else {
								throw string("\nIllegal Exception Handling. Attempted Invalid Input.");
							}
						}
						catch (string err) {
							cout << err << endl;
							throw string();
							cin.clear();
							cin.ignore(1, '\n');
							break;
						}
					//End do{} while() condition
					} while (UserInput != 7);
					break;
				}
			}
			//Exit Program
			if (MainMenu == 4) {
				cout << "\nProgram closing..." << endl;
			}
			//Invalid Input
			else {
				throw string("\nIllegal Exception Handling. Invalid Input.");
			}
		}
		//Catch errors and clear input
		catch (string err) {
			cout << err << endl;
			cin.clear();
			cin.ignore(1, '\n');
		}
	} while (MainMenu != 4);
	//Close output stream and output final message to user
	ShippingOrders.close();
	cout << "\nProgram closed. See you Space Cowboy...\n";
}

/*
To do list:
Functionality:
1. Work on Exception Handling for Adding Employee. If can't get just take it out and turn it in. If I do get it working,
add it into other loop and then I will call it done. Otherwise, we are there. I could probably force a string input,
convert it to an integer value, check if it's in map, and if not just print out message and done.

//Exception handling ideas to implement in test classes first
Use this when the class no longer exists or is not found
public class NoClassDefFoundError extends LinkageError {
	//
	public NoClassDefFoundError(){}
	//
	public NoClassDefFoundError​(String s){
		try {
			if(){

			}
			else{
				throw new LinkageError("Object does not exist within database.");
			}
		}
	}
}

//Might be able to use this when calculating cost or wage
	System.out.print("Enter two integers: ");
	int number1 = input.nextInt();
	int number2 = input.nextInt();
	//
	try {
		int result = quotient(number1, number2);
		cout << number1 + " / " + number2 + " is" + result);
	}
	//
	catch (ArithmeticException ex) {
		cout << "Exception: an integer " + "cannot be divided by zero ");
	}
	//
	cout << "Execution continues...");


//Use this to handle a string input for an int, or an int input for a string
	public void setRadius(double Radius) throws IllegalArgumentException {
		if (Radius >= 0)
			radius = newRadius;
		else
			throw new IllegalArgumentException("Radius cannot be negative");
	}
*/