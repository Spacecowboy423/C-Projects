Project Name: The Power of Maps and Keys
Author: Michael Krause
Last Update: 3/04/2022
Purpose: Create a class to hold information about all 50 states. Allow the user to search the map by key value to find the
data stored in the map. The prompt wanted state and capital but I did a lot of extra for fun. Search by abbreviation instead
of state, but the user will get the capital, current governor, and state flower.

Assignment:
Write a program to store pairs of each state and its capital in a map. Your program should prompt the user to enter a state
and should display the capital for the state.

My Implementation:
I created a class object with the fields capable of holding the strings from the text file. The Paramterized Constructor takes in
the information we want to store for later and print out. Normal Accessors and Mutators and then the method that does the heavy
lifting.

The FillMap method takes in the map and input file declared in the main program. I used the getline function because some capitals,
the governors, and some flowers are multiple words strings, the ':' acts as a token for the scanner to recognize the end of the word.
The last token is the '\n' for new line. The scanner recognizes where the end of the line is and know to stop there. For the loop and
scanner to function correctly each line from the text file has to be set up in the same order we are trying to store the values. The
first string in the text file is the Key(state abbreviation), second is the State, third is the Capital, fourth is the Governor, and 
fifth is the State Flower. After the flower is a new line so the scanner stops. I then construct a new 'States' object with the 
textfile information and use the state abbreviation as the key to store the new object inside the Map. The loop ends when it reaches
the end of the textfile and returns to main.

Main Function:
Right off the bat I declare the object and map for the program. Open the textfile and run the method to fill the map, once done the
input stream is closed before proceeding into the rest of the program. From here the user enters a while loop and is told enter the 
abbreviation of the state they wish to look for in the Map. If the user enters the correct key value the results are printed back,
if not an error message is printed to the user. They are then given the choice to continue or end the program.


