/*
Project Name: The Power of Maps and Keys
Author: Michael Krause
Last Update: 3/04/2022
Purpose: Create a class to hold information about all 50 states. Allow the user to search the map by key value to find the
data stored in the map. The prompt wanted state and capital but I did a lot of extra for fun. Search by abbreviation instead
of state, but the user will get the capital, current governor, and state flower.
*/

#include<iostream>
#include<fstream>
#include<map>
#include<string>
using namespace std;

class States {
private:
    //Fields
    string State, Capital, Governor, Flower;

public:
    //Default Constructor
    States() {
        State = "Blank";
        Capital = "Blank";
        Governor = "Blank";
        Flower = "Blank";
    }//end d-constructor

    //Parameterized Constructor
    States(string State, string Capital, string Governor, string Flower) {
        this->State = State;
        this->Capital = Capital;
        this->Governor = Governor;
        this->Flower = Flower;
    }//end p-constructor

    //Destructor
    ~States() {
        //Intentionally Blank
    }//end destructor

    //Accessors
    string getState() {
        return State;
    }//end getState

    string getCapital() {
        return Capital;
    }//end getCapital

    string getGovernor() {
        return Governor;
    }//end getGovernor

    string getFlower() {
        return Flower;
    }//end getFlower

    //Mutators
    void setState(string State) {
        this->State = State;
    }//end setState

    void setCapital(string Capital) {
        this->Capital = Capital;
    }//end setCapital

    void setGovernor(string Governor) {
        this->Governor = Governor;
    }//end setGovernor

    void setFlower(string Flower) {
        this->Flower = Flower;
    }//end setFlower

    //Method to fill the map with the information from the txt file
    void FillMap(map<string, States>& Map, ifstream& inFile) {
        
        //Key holds the first string from file to be the key-value for the map
        string Key;                                 
        
        //Loop to take in text file and store values as objects in the map
        while (getline(inFile, Key, ':')) {
            getline(inFile, State, ':');
            getline(inFile, Capital, ':');
            getline(inFile, Governor, ':');
            getline(inFile, Flower, '\n');
            
            //Construct a new object from text file and store in Map by the key-value
            Map[Key] = States(State, Capital, Governor, Flower);

        }//end while

    }//end FillMap

};//end class
//
//Main
//
int main() {
    
    States State;                               //Declare class and map
    map<string, States> Map;
    string UserKey, x = "y";                    //User variables for program
    
    ifstream inFile("StateInfo.txt");           //Open stream for text file 
    State.FillMap(Map, inFile);                 //Call class method to fill the map
    inFile.close();                             //Close stream
    
    
    while (x.compare("y") == 0 || x.compare("Y") == 0) {    //Loop ends when user enters anything but "y" or "Y"
        
        //Prompt user for a value to check against keys in map
        cout << "Enter the Abbreviation of the State.   ** Example: IN **" << endl;
        cout << "Input State: ";
        cin >> UserKey;
        
        //Check if entry exists in map
        if (Map.find(UserKey) != Map.end()) {    
            //Copy current data from Map and Print out information
            State = Map.at(UserKey);
            cout << endl;
            cout << "State: " << State.getState() << endl;          
            cout << "Capital: " << State.getCapital() << endl;
            cout << "Governor: " << State.getGovernor() << endl;
            cout << "Flower: " << State.getFlower() << endl;
        }//end if

        //Error message if no match
        else {
            cout << endl;
            cout << "Invalid key entered. '" << UserKey << "' was not found." << endl;
        }//end else

        //Ask user if they want to continue 
        cout << endl;
        cout << "Do you want to continue? (y/n): ";           
        cin >> x;
        cout << endl;

    }//end while

    return 0;
}//end main