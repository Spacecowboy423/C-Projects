Program Name: Simple Inventory with Linked Queue
Author: Michael Krause
Last Update: 2/22/2022
Purpose: To use a linked queue to make a simple program. I made a few changes to the direct class from the book 
to make a menu-driven program to do some simple inventory esque things to show some simple uses of a linked queue.

Problem Statement:
17. Write the definition of the class linkedQueueType, which is derived from the class unorderedLinkedList, as explained in this 
chapter. Also, write a program to test various operations of this class.

My Application:
I had to make a few modifications to the class definitions, constructor and the destructor where not defined, and I modified the 
class by adding some void functions that I needed for the program design I had in mind. I made a menu-driven program to allow the
user the option of manipulating the linked queue to add a number to the queue, delete the front element, get the size of the queue,
print the front element, print the rear element, add all the numbers in the queue for a grand total, print out the entire queue, or
the user can simply end the program. 

I stored the template class for a linkedqueue in a seperate header file to save room on each screen. Because the class was from the
book I only want to use the ReadMe doc to explain the things that I added and the design of my program.

Defined the Parameterized Constructor:
The constructor will take in a queue declared from the main program. If the queue is empty then the object based linked queue is set
to a new front and rear node. If the queue is not empty then the object queue front is set to the main program queue front. And the
same is done for the queue rear of each. This way the object queue has the info and link needed to traverse the linked queue until the
proper end node is found. 

Defined the Destructor:
The destructor runs a while loop that continously deletes the front element of the queue until the queue is empty. To deallocate any
memory used in the program before the program ends.

Declared and Defined size():
The method, size, is used to run through the entire linked list and keep count of how many iterations it takes for queueFront to find
queueRear and return the value to the user before returning to the main program. It checks to make sure the linked queue is not empty
before iterating through. The, count, variable is declared and initialized to 0. A temporary node is created to store the information
and link from queueFront. queueFront moves through the list and is incremented to the next node in the list until queueRear is found 
and queueFront is equal to a nullptr. The temporary node is used to restor queueFront back to it's original settings and the, count, 
is displayed to the user.


Declared and Defined SumOfQueue():
The method, SumOfQueue, is used to run through the linked queue and add all the values together and output the results to the user. The
method checks if the queue is empty and terminates if it is. Pretty much the exact same process as above is used to traverse each node
and add the info stored there to the variable x. When the rear is found the while loop ends and queueFront is restored to its original
values. The total is output to the user and then returns to main program.

Declared and Defined toString():
The method, toString, does the exact same process as described above but each iteration is used to print the current value stored in
the front position of the queue. Once done it restores queueFront to it's original values and returns to the main program.

Declared and Defined printMain():
The void function, printMain, is used to print the main menu the user sees each iteration of the program.

Main Program():
Declare the type and name of the linkedQueueType. Declare and initialize program variables. The while loop runs until the user decides
to end the program by entering 8. The try catch block is used to handle any exceptions from the users input in the main menu. All
options except for option 1 simply call a method and don't require further handling. The only exception to that rule is if the user
enters 1 to add a number to the queue. Instead of validating the user input I forced it into a valid input. Line 47 converts any the
entry from the user into an int variable. I then set the users entry back to the converted int before proceeding. In case the user enters
a decimal number link 49 and 50 are there to clear the input stream and ignore anything left behind, leaving a new line ready for user
entry. If the user enters any decimal only the numbers before the decimal are stored in the int variable. If user enters a char or
string a 0 is applied instead. When the user ends the program they will see a farewell message and the destructor will deallocate any
memory used in the linked queue.

