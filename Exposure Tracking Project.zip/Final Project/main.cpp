/*
Program Name: Exposure Tracking Database
Author: Michael Krause
Last Update: May 10, 2022
Purpose: To design and create a database and then implement a program to interact with the database. 
Command line user interface to search the database in multiple ways. Add patients and create new exposure cases.
Edit any patient or exposure case and the info there in. Remove smaller tables from the database. All in an effort
to track any food born illness to stop a potential pathogen from spreading or to track outbreaks occuring in a community
to call the proper response.  
*/


#include <iostream>
#include <string>
#include "sqlite3.h"
using namespace std;


//Things for any user to know not used to sqlite
//query = "begin transaction";                                                  //send string to exec statement to create save point if errors happen
//rollback                                                                      //rollback database to previous save point (state when "begin transaction" was used)
//commit                                                                        //commit changes in the database
//callback(database, argc, argv, azColName)                                     //function takes the results from database, the rows, the value of each row and the name of each column
//sqlite3_exec(database, query(string), callback, statement, error);            //primarly used to update, insert, create, or delete
//sqlite3_prepare_v2(database, query(string), callback, statement, error);      //primarly used with select statements
//sqlite3_reset(statement);                                                     //used to reset statement to beginning of query
//sqlite3_step(statement);                                                      //progress through results from query
//sqlite3_finalize(statement);                                                  //reset statement to a null state for reuse


//function to rollback database to before error occurred
void rollback(sqlite3* db){
    string query = "rollback;";
    sqlite3_exec(db, query.c_str(), NULL, NULL, NULL);
}//end rollback


//function to commit changes made to database through transactions
void commit(sqlite3* db){
    string query = "commit;";
    sqlite3_exec(db, query.c_str(), NULL, NULL, NULL);
}//end commit


//function to validate string is made up of digits 0-9 only
bool isDigit(string userInput) {
    //Check input is an int using the string as an array and checking each character of it to be within the constraint
	for (int i = 0; i < userInput.length(); i++) {
		if (userInput[i] < '0' || userInput[i] > '9') {
			return false;
		}
	}
	return true;
}//end isDigit


//function to validate string is made up of only allowed letters and spaces
bool isWord(string userInput){
    //Check input is made up only of letters from the alphabet
    for (int i = 0; i < userInput.length(); i++){
        if(((userInput[i] < 'a' || userInput[i] > 'z') && (userInput[i] < 'A' || userInput[i] > 'Z')) && userInput[i] != ' '){
            return false;
        }
    }//end for
    return true;
}//end isWord


//function to validate string is made up on letters, numbers, and spaces
bool isAddress(string userInput){
    //Check input is made up only of letters from the alphabet or numbers for the stree address
    for(int i = 0; i < userInput.length(); i++){
        if(((userInput[i] < 'a' || userInput[i] > 'z') && (userInput[i] < 'A' || userInput[i] > 'Z')) && userInput[i] != ' ' && (userInput[i] < '0' || userInput[i] > '9')){
            return false;
        }
    }//end for
    return true;
}//end isAddress


//function to validate is char is a letter
bool isCharLetter(char userInput){
    //Check input is made up only of letters from the alphabet
    if(userInput < 'a' || userInput > 'z' || userInput < 'A' || userInput > 'Z'){
        return false;
    }
    return true;
}


//function to validate email input from user
bool isEmail(string userInput) {
    int count1 = 0, count2 = 0;                         //count 1 tracks '@' count2 tracks '.'
    for (int i = 0; i < userInput.length(); i++) {      //runs the length of the input
        if (userInput[i] == '@') {                      //checks for only 1 '@'
            count1++;                                   //increment count1
            if (i == 0 || i == userInput.length() - 1) {    //check that the character is not first or last
                return false;
            }
        }
        if (userInput[i] == '.') {                          //check for'.'
            count2++;                                       //increment count by 1
            if (i == 0 || i == userInput.length() - 1) {    //check character is not first or last
                return false;
            }
        }
    }//end for
    if (count1 == 1 && count2 == 1) {                       //check that both count1 and count2 are only 1
        return true;
    }
    return false;                                           //Otherwise return false
}//end isEmail


//function to validate date input from user
bool isDate(string Date){
    for(int i = 0; i < Date.length(); i++){                                     //loop runs the length of Date (8)
        switch(i){                                                              //switch check that each element of Date falls into certain parameters of MMDDYYYY
            case 0:                                         
				if(Date[i] == '0' || Date[i] == '1'){                           //if first element is 0 or 1 break and continue loop
					break;
				}
				else{
					return false;                                               //else return false
				}
                break;                                                          //break case 0

			case 1:				
                if(Date[0] == '0'){                                             //for element 1 two different things happen if element 0 is '0' or '1'
                    goto here;
                }                                                   
                else if(Date[0] == '1'){                                        //if date[0] is 1
                    if(Date[i] == '0' || Date[i] == '1' || Date[i] == '2'){     //check that date[1] is 0, 1, or 2 only
                        break;
                    }
                    else{                                                       //if not return false
                        return false;
                    }
                }
                else{                                                           //if date[0] is anything but 0 or 1 return false
                    return false;
                }            
                break;                                                          //end case 1

            case 2:                                                             //i = 2
				if(Date[i] >= '0' && Date[i] <= '3'){                           //checks Date[2] is 0, 1, 2, or 3
					break;
				}
				else{                                                           //else return false
					return false;
				}
                break;                                                          //end case 2

			case 4:				//the fourth element must be 1 or 2 for the year to be 1xxx or 2xxx  
                if(Date[i] == '1' || Date[i] == '2'){   //check Date[4] is 1 or 2
                    break;
                }
                else{                                   //else false
                    return false;
                }
                break;                                  //end case 4

            case 5:                                     //i = 5, two different things if Date[4] is 1 or 2 for Date[5]
                if(Date[4] == '1'){                     //if Date[4] is 1
                    if(Date[i] == '9'){                 //Date[5] must be 9
                        break;
                    }
                    else{                               //else false
                        return false;
                    }
                }
                else if(Date[4] == '2'){                //if Date[4] is 2
                    goto here;                          //follow label to 'here' to perform check that input is between 0-9
                }
                else {                                  //else return false
                    return false;
                }
                break;                                  //end case 5

            here:                                       //label to direct traffic only other iterations to perform defualt case
            default:        //if not the specified element needs to be between 0 and 9
                if(Date[i] >= '0' && Date[i] <= '9'){       //check element is between 0 and 9 and breaks switch to continue for loop
                    break;
                }
                else{                                       //else return false
                    return false;
                }
        }//end switch
    }//end for

    //Checks each element individually now check the combined forms of in their related parts
    //Check that month (00), day (00), and year (0000) fit within the proper constraint once put together
    string month;
    month = Date[0];
    month += Date[1];
    if(month >= "01" && month <= "12"){     //check that the month is constrained to 01 thru 12
        string day;
        day = Date[2];
        day += Date[3];
        if(day >= "01" && day <= "31"){     //check that the day is constrained to 01 thru 31
            string year;
            year = Date[4];
            year += Date[5];
            year += Date[6];
            year += Date[7];
            if(year > "1899" && year <= "2999"){       //check that the year is constrained to 1900 to 2999 (because i have non real characters in here with random time periods, otherwise restriction would be more relevant)
                return true;
            }
            else{
                //cout << "Error on year." << endl;
                return false;
            }
        }
        else{
            //cout << "Error on day." << endl;
            return false;
        }
    }//end if
    else{
        //cout << "Error on month." << endl;
        return false;
    }
}//end isDate


//function to print the results of a query directly
int callback(void *data, int argc, char **argv, char **azColName);      //definition after main


//function to print the menu for searching the database
void searchMenu(){
    cout << "************ Menu ************" << endl;
    cout << "1. Search by Patient_ID" << endl;
    cout << "2. Search by Name" << endl;
    cout << "3. Search by Name and DOB" << endl;
    cout << "4. Find patients with the same Pathogen" << endl;
    cout << "5. Find patients with the same Pathogen and County" << endl;
}//end searchMenu


//function to create a new investigator
void createInvestigator(sqlite3 *db){
/*
****Investigator****
Investigator_ID                 int                         (Primary Key)
Investigator_First_Name         varchar(20) NOT NULL
Investigator_Last_Name          varchar(20) NOT NULL
Job_Title                       varchar(20) NOT NULL
Phone                           char(10) NOT NULL
Email                           varchar(50) NOT NULL
*/

    //need to come back to implement
}//end createInvestigator


//function to edit from the pet table
void editPet(sqlite3* db){
/*
****Pet****
Pet_ID                          int                         (Primary Key)
Pet_Species                     varchar(20)
Pet_Breed                       varchar(20)
Pet_Age                         int
*/    
    string query;
    query = "begin transaction;";
    sqlite3_stmt *result;
    string strLastError, temp;
    int userInput, pet_id;
    bool boolean = true;
    string Input;
    char *err;
    int i = 1;
    int rc;

    rc = sqlite3_exec(db, query.c_str(), NULL, NULL, &err);
    if(rc != SQLITE_OK){
        cout << "Error starting transaction: " << err << endl;
        sqlite3_free(err);
        return;
    }

    query = "select * from Pet;";
    rc = sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL);
    if(rc != SQLITE_OK){
        strLastError = sqlite3_errmsg(db);
        sqlite3_finalize(result);
        cout << "There was an error with selecting from Pet table: " << strLastError << endl;
        rollback(db);
        return;
    }
    
    rc = sqlite3_step(result);
    if(sqlite3_column_text(result, 0) == NULL){                     //if pet id returns null pet does not exist within database
        cout << "Pet could not be found in database." << endl << endl;
        sqlite3_finalize(result);
        rollback(db);
        return;
    }

    cout << "Choose pet you would like to edit." << endl;
    cout << "****Pets****" << endl;
    while (rc == SQLITE_ROW){               //Print pet id, species, bread and age for user to choose from
        cout << i << ". " << sqlite3_column_text(result, 1) << ": ";     //print the current count/pet id and the species from pet table
        cout << sqlite3_column_text(result, 2);
        if(sqlite3_column_text(result, 3) != NULL){                      //make sure age is not null
            cout << " - " << sqlite3_column_text(result, 3);             //print age if not null
        }
        cout << endl;
        i++;                                        //increment i by 1
        rc = sqlite3_step(result);                  //step to the next row if row exists
    }//end while

    cout << "Enter choice: ";
    cin >> userInput;
    cout << endl;                                                                   //skip line for output
    while(!cin || userInput < 1 || userInput > i){
        if (!cin){
            cin.clear();
            cin.ignore(1000, '\n');
        }
        cout << "That is not a pet! Try again!" << endl;
        cin >> userInput;
        cout << endl;                                                                   //skip line for output
    }
    sqlite3_reset(result);

    for (int j = 0; j < userInput; j++){
        sqlite3_step(result);
    }

    pet_id = sqlite3_column_int(result, 0);
    sqlite3_finalize(result);

	query = "select * from pet where pet_id = " + to_string(pet_id) + ";";
    rc = sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL);
	if(rc != SQLITE_OK) {
		strLastError = sqlite3_errmsg(db);
		sqlite3_finalize(result);
		cout << "There was an error: " << strLastError << endl;
		rollback(db);
		return;
	}

    cout << "What would you like to edit?" << endl;
    cout << "1. Pet Species" << endl;
    cout << "2. Pet Breed" << endl;
    cout << "3. Pet Age" << endl;
    cout << "Enter choice: " << endl;

    cin >> userInput;
    cout << endl;                                                                   //skip line for output
    while(!cin || userInput < 1 || userInput > 3){
        if (!cin){
            cin.clear();
            cin.ignore(1000, '\n');
        }
        cout << "That is not an option! Try again!" << endl;
        cin >> userInput;
        cout << endl;                                                                   //skip line for output
    }//end while

    switch(userInput){
        case 1:
            cout << "What is the new Species?" << endl;
            cout << "Enter Species: ";
            
            while(boolean){
                cin >> Input;
                cout << endl;
                if(isWord(Input)) {
                    boolean = false;
                }
                else {
                    cout << "Please only enter letters of the alphabet for species." << endl;
                    cin.clear();
                    cin.ignore(1000, '\n');
                }
            }//end while

            query = "update pet set pet_species = '" + Input + "' where pet_id = " + to_string(pet_id);
            rc = sqlite3_exec(db, query.c_str(), NULL, &result, NULL);
            if(rc != SQLITE_OK) {
                strLastError = sqlite3_errmsg(db);
                sqlite3_finalize(result);
                cout << "There was an error updating Pet Species: " << strLastError << endl;
                rollback(db);
                return;
            }

            cout << "Pet Species updated successfully." << endl;
            commit(db);
            break;  //end case 1

        case 2:
            cout << "What is the new Breed?" << endl;
            cout << "Enter Breed: ";
            
            while(boolean){
                cin >> Input;
                cout << endl;
                if(isWord(Input)) {
                    boolean = false;
                }
                else {
                    cout << "Please only enter letters of the alphabet for the Breed." << endl;
                    cin.clear();
                    cin.ignore(1000, '\n');
                }
            }//end while
            
            query = "update pet set pet_breed = '" + Input + "' where pet_id = " + to_string(pet_id);
            rc = sqlite3_exec(db, query.c_str(), NULL, &result, NULL);
            if(rc != SQLITE_OK) {
                strLastError = sqlite3_errmsg(db);
                sqlite3_finalize(result);
                cout << "There was an error updating Pet Breed: " << strLastError << endl;
                rollback(db);
                return;
            }

            cout << "Pet Breed updated successfully." << endl;
            commit(db);
            break;  //end case 2

        case 3:
            cout << "What is the pets age?" << endl;
            cout << "Enter age: ";

            while(boolean){
                cin >> Input;
                cout << endl;
                if(isDigit(Input)) {
                    boolean = false;
                }
                else {
                    cout << "Please only enter an integer number for the Pet age." << endl;
                    cin.clear();
                    cin.ignore(1000, '\n');
                }
            }//end while
            
            query = "update pet set pet_age = " + Input + " where pet_id = " + to_string(pet_id);
            rc = sqlite3_exec(db, query.c_str(), NULL, &result, NULL);
            if(rc != SQLITE_OK) {
                strLastError = sqlite3_errmsg(db);
                sqlite3_finalize(result);
                cout << "There was an error updating Pet Age: " << strLastError << endl;
                rollback(db);
                return;
            }

            cout << "Pet Age updated successfully." << endl;
            commit(db);
            break;  //end case 3
    }//end switch case
}//end editPet


//function to edit from the Symptom table
void editSymptom(sqlite3* db){
/*
****Symptom****
Symptom_ID                      int                         (Primary Key)
Epi_ID                          int                         (Foreign Key)
Symptom_Type                    varchar(200) NOT NULL
Start_Of_Symptom                char(8) NOT NULL
Symptom_Severity                int NOT NULL
Symptom_Effected_Area           varchar(100) NOT NULL
Symptom_Contagious              varchar(100) NOT NULL
*/


}//end editSymptom


//function to edit from the symtpom table
void editChronic(sqlite3* db){
/*
****Chronic Condition****
Chronin_ID                      int                         (Primary Key)
Epi_ID                          int                         (Foreign Key)
Chronic_Condition               varchar(100) NOT NULL
Start_Of_Condition              char(8) NOT NULL
Condition_Severity              int NOT NULL
Condition_Effected_Area         varchar(100) NOT NULL
*/





}//end editChronic


//function to print all of the patients information in database
void printPatient(sqlite3 *db, string query){
    string LastError;
    sqlite3_stmt *results;

    if (sqlite3_prepare_v2(db, query.c_str(), -1, &results, NULL) != SQLITE_OK) {
        LastError = sqlite3_errmsg(db);
        sqlite3_finalize(results);
        cout << "There was an error: " << LastError << endl;
        return;
    }
    else {
        while (sqlite3_step(results) == SQLITE_ROW) {
            cout << "****Patient Information****" << endl;
            cout << "Patient ID: " << sqlite3_column_text(results, 0) << endl;  // print column with id number
            cout << "Patient Name: " << sqlite3_column_text(results, 1) << " "; // print column with first name

            if (sqlite3_column_text(results, 2) != NULL) { // If middle initial is null don't try to print it
                cout << sqlite3_column_text(results, 2) << ". ";
            }

            cout << sqlite3_column_text(results, 3) << endl;                                                                                         // print column with last name
            string temp = reinterpret_cast<const char *>(sqlite3_column_text(results, 4));                                                           // cast column with dob to string then split for output
            cout << "Date of Birth: " << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7] << endl; // custom print the dob
            cout << "Address: " << sqlite3_column_text(results, 5) << ", " << sqlite3_column_text(results, 6) << endl;                               // combine county with street address for address
            cout << "Gender: " << sqlite3_column_text(results, 7) << endl;                                                                           // print column with gender
            cout << "Marital Status: " << sqlite3_column_text(results, 8) << endl;                                                                   // print column with marital status
            cout << "Ethnicity: " << sqlite3_column_text(results, 9) << endl;                                                                        // print column with ethnicity
            cout << "Nationality: " << sqlite3_column_text(results, 10) << endl;                                                                     // print column with nationality

            if (sqlite3_column_text(results, 13) != NULL) {               // if not epi case attached to patient column will be null, don't print if null
                cout << "Exposure ID: " << sqlite3_column_text(results, 13) << endl; // print column with exposure ID if not NULL
            }

            cout << "---Contact Info---" << endl;                                      // Organize and display patient contact information
            temp = reinterpret_cast<const char *>(sqlite3_column_text(results, 11)); // use temp string again to case column with phone number into temp to split for output
            cout << "Phone Number: (" << temp[0] << temp[1] << temp[2] << ") " << temp[3] << temp[4] << temp[5] << "-" << temp[6] << temp[7] << temp[8] << temp[9] << endl;
            cout << "Email: " << sqlite3_column_text(results, 12) << endl; // print column with email address
            //sqlite3_finalize(results);

            //IF patient has epi_id in their file find it and print the exposure case for that individual
            if(sqlite3_column_text(results, 13) != NULL){       //if epi_id != NULL print the epi information attached to patient automatically for ease of lookup
                cout << endl;
                sqlite3_stmt *results2;

                temp = reinterpret_cast<const char*>(sqlite3_column_text(results, 13));
                query = "select * from Epi_Case, Patient where Patient.Epi_ID = Epi_Case.Epi_ID and Patient.Epi_ID = " + temp + ";";
                if (sqlite3_prepare_v2(db, query.c_str(), -1, &results, NULL) != SQLITE_OK) {
                    LastError = sqlite3_errmsg(db);
                    sqlite3_finalize(results);
                    cout << "There was an error: " << LastError << endl;
                    return;
                }
                else {
                    while (sqlite3_step(results) == SQLITE_ROW) {
                        cout << "****Epidemiology Case****" << endl;
                        cout << "Housing Situation: " << sqlite3_column_text(results, 2) << endl;
                        cout << "Household Size: " << sqlite3_column_text(results, 4) << endl;  
                        cout << "Source of Water: " << sqlite3_column_text(results, 5) << endl; 
                        cout << "Any Water Contact: " << sqlite3_column_text(results, 6) << endl;
                        cout << "Sexualy Active: " << sqlite3_column_text(results, 7) << endl;
                        cout << "Any Animal Contact: " << sqlite3_column_text(results, 8) << endl;
                        cout << "Recent Travel: " << sqlite3_column_text(results, 10) << endl;
                        
                        string notes = reinterpret_cast<const char*>(sqlite3_column_text(results, 11));
                        cout << "Case Notes: ";
                        for (int i = 0; i < notes.length(); i++){       //for loop ensures the multiline note left by the investigator prints for 50 characters and then moves to a new line to print another 50 characters
                            if(i == 0) {            //on first iteration create a new line and print the first character value
                                cout << endl;
                                cout << notes[i];
                            }
                            else if(i % 50 != 0){   //Not first iteration and modulus operator doesn't have 0 as a remainder
                                cout << notes[i];
                            }
                            else{                   //When remainder is 0 come here to print the value and create a new line
                                cout << notes[i] << endl;
                            }
                        }
                        cout << endl;           //create new line for output

                        temp = reinterpret_cast<const char*>(sqlite3_column_text(results, 12));     //recast column value into string variable to split for output to user
                        cout << "Date of Investigation: " << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7] << endl;
                
                        temp = reinterpret_cast<const char*>(sqlite3_column_text(results, 13));     //recast column value into string variable to split for output to user
                        cout << "Start of Pathogen: " << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7] << endl;
                        
                        investigator:
                        //perform new query to find investigator information
                        if(sqlite3_column_text(results, 9) != NULL) {       //checks that investigator id is not null before using it to get the investigator
                            temp = reinterpret_cast<const char*>(sqlite3_column_text(results, 9));
                            query = "select * from investigator where investigator_id = " + temp + ";";
                            
                            if (sqlite3_prepare_v2(db, query.c_str(), -1, &results2, NULL) != SQLITE_OK) {  //perform check on query
                                LastError = sqlite3_errmsg(db);
                                sqlite3_finalize(results2);
                                cout << "There was an error: " << LastError << endl;
                                goto pet;
                            }//end if
                            else {
                                while(sqlite3_step(results2) == SQLITE_ROW){
                                    cout << endl;
                                    cout << "----Investigator----" << endl;
                                    cout << "Investigator ID: " << sqlite3_column_text(results2, 0) << endl;
                                    cout << "Investigator Name: " << sqlite3_column_text(results2, 1) << ", " << sqlite3_column_text(results2, 2) << endl;  
                                    cout << "Job Title: " << sqlite3_column_text(results2, 3) << endl; 
                                    temp = reinterpret_cast<const char*>(sqlite3_column_text(results2, 4));
                                    cout << "Phone Number: (" << temp[0] << temp[1] << temp[2] << ") " << temp[3] << temp[4] << temp[5] << "-" << temp[6] << temp[7] << temp[8] << temp[9] << endl;
                                    cout << "Email: " << sqlite3_column_text(results2, 5) << endl;
                                    //sqlite3_finalize(results2);
                                }//end while
                                cout << endl;
                            }//end else
                        }//end if to print investigator
                        
                        pet:
                        //perform new query to find the pet information
                        if(sqlite3_column_text(results, 3) != NULL) {       //checks that pet id is not null before using it to get the pet information
                            temp = reinterpret_cast<const char*>(sqlite3_column_text(results, 0));
                            
                            query = "select pet.pet_id, pet_species, pet_breed, pet_age from epi_case, pet_lookup, pet on pet.pet_id ";
                                query += "= pet_lookup.pet_id and epi_case.epi_id = pet_lookup.epi_id where epi_case.epi_id = " + temp + ";";
                            
                            if (sqlite3_prepare_v2(db, query.c_str(), -1, &results2, NULL) != SQLITE_OK) {  //perform check on query
                                LastError = sqlite3_errmsg(db);
                                sqlite3_finalize(results2);
                                cout << "There was an error: " << LastError << endl;
                                goto pathogen;
                            }//end inner if to print error
                            else {
                                cout << "----Pet Information----" << endl;
                                ///////////////////////////////////////////////////////////////////////////////////
                                while(sqlite3_step(results2) == SQLITE_ROW){
                                    cout << "Pet ID: " << sqlite3_column_text(results2, 0) << endl;
                                    if(sqlite3_column_text(results2, 1) != NULL) {
                                        cout << "Species: " << sqlite3_column_text(results2, 1) << endl;
                                    }
                                    if(sqlite3_column_text(results2, 2) != NULL) {
                                        cout << "Breed: " << sqlite3_column_text(results2, 2) << endl;      //Might need to add another while loop to step to the next row
                                    }
                                    if(sqlite3_column_text(results2, 3) != NULL) {
                                        cout << "Age: " << sqlite3_column_text(results2, 3) << endl;        //and print again until no more rows, hoping it does that auto
                                    }
                                    cout << endl;
                                    //sqlite3_step(results2);
                                }//end while
                                /////////////////////////////////////////////////////////////////////////////////
                            }//end else
                        }//end if to print pet information
                        
                        pathogen:
                        //perform new query to find the pathogen information
                        if(sqlite3_column_text(results, 14) != NULL) {      //checks that pathogen id is not null before using it to get the pathogen information
                            temp = reinterpret_cast<const char*>(sqlite3_column_text(results, 14));
                            query = "select * from pathogen where pathogen_id = " + temp + ";";

                            if (sqlite3_prepare_v2(db, query.c_str(), -1, &results2, NULL) != SQLITE_OK) {  //perform check on query
                                LastError = sqlite3_errmsg(db);
                                sqlite3_finalize(results2);
                                cout << "There was an error: " << LastError << endl;
                                goto chronic;
                            }//end if
                            else {
                                while(sqlite3_step(results2) == SQLITE_ROW){
                                    cout << "----Pathogen Information----" << endl;
                                    cout << "Pathogen ID: " << sqlite3_column_text(results2, 0) << endl;
                                    cout << "Pathogen: " << sqlite3_column_text(results2, 1) << endl;
                                    cout << "Severity: " << sqlite3_column_text(results2, 2) << endl;
                                    cout << "Pathogen Notes:";
                                    temp = reinterpret_cast<const char*>(sqlite3_column_text(results2, 3));
                                    
                                    for(int i = 0; i < temp.length(); i++){
                                        if(i == 0){     //on first iteration create a new line and print the first character value
                                            cout << endl;
                                            cout << temp[i];
                                        }
                                        else if(i % 50 != 0){   //Not first iteration and modulus operator doesn't have 0 as a remainder
                                            cout << temp[i];
                                        }
                                        else{   //When remainder is 0 come here to print the value and create a new line
                                            cout << temp[i] << endl;
                                        }
                                    }//end for
                                }//end while
                                cout << endl;
                            }//end else
                        }//end if to print the pathogen
                        
                        chronic:
                        //perform new query to find the chronic health conditions
                        if(sqlite3_column_text(results, 0) != NULL) {       //checks epi id is not null before using it to get the chronic health information
                            temp = reinterpret_cast<const char*>(sqlite3_column_text(results, 0));
                            query = "select * from Chronic_Health_Condition where epi_id = " + temp + ";";

                            if (sqlite3_prepare_v2(db, query.c_str(), -1, &results2, NULL) != SQLITE_OK) {  //perform check on query
                                LastError = sqlite3_errmsg(db);
                                sqlite3_finalize(results2);
                                cout << "There was an error: " << LastError << endl;
                                goto symptom;
                            }//end if
                            else{
                                while(sqlite3_step(results2) == SQLITE_ROW){
                                    cout << endl;
                                    cout << "----Pre-Existing Health Condition----" << endl;
                                    cout << "Condition:";
                                    temp = reinterpret_cast<const char*>(sqlite3_column_text(results2, 2));
                                    //loop to print condition information in a structured format
                                    for(int i = 0; i < temp.length(); i++){
                                        if(i == 0){     //on first iteration create a new line and print the first character value
                                            cout << endl;
                                            cout << temp[i];
                                        }
                                        else if(i % 50 != 0){   //Not first iteration and modulus operator doesn't have 0 as a remainder
                                            cout << temp[i];
                                        }
                                        else{   //When remainder is 0 come here to print the value and create a new line
                                            cout << temp[i] << endl;
                                        }
                                    }//end for
                                    cout << endl;
                                    cout << "Approximate Start of Condition: ";
                                    temp = reinterpret_cast<const char*>(sqlite3_column_text(results2, 3));
                                    cout << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7] << endl;
                                    cout << "Severity: " << sqlite3_column_text(results2, 4) << endl;
                                    cout << "General Effected Area:";
                                    temp = reinterpret_cast<const char*>(sqlite3_column_text(results2, 5));
                                    //loop to print the effected area information in a structured format
                                    for(int i = 0; i < temp.length(); i++){
                                        if(i == 0){     //on first iteration create a new line and print the first character value
                                            cout << endl;
                                            cout << temp[i];
                                        }
                                        else if(i % 50 != 0){   //Not first iteration and modulus operator doesn't have 0 as a remainder
                                            cout << temp[i];
                                        }
                                        else{   //When remainder is 0 come here to print the value and create a new line
                                            cout << temp[i] << endl;
                                        }
                                    }//end for
                                }//end while
                                cout << endl;
                            }//end else
                        }//end if to print chronic health conditions

                        symptom:
                        //perform new query to find the symptoms of the patient
                        if(sqlite3_column_text(results, 0) != NULL) {       //checks chronic id is not null before using it to get the chronic health information
                            temp = reinterpret_cast<const char*>(sqlite3_column_text(results, 0));
                            query = "select * from symptom where epi_id = " + temp + ";";
                            
                            if (sqlite3_prepare_v2(db, query.c_str(), -1, &results2, NULL) != SQLITE_OK) {  //perform check on query
                                LastError = sqlite3_errmsg(db);
                                sqlite3_finalize(results2);
                                cout << "There was an error: " << LastError << endl;
                                return;
                            }//end if
                            else {
                                while(sqlite3_step(results2) == SQLITE_ROW){
                                    cout << endl;
                                    cout << "----Patient Symptoms----" << endl;
                                    cout << "Description of Symptoms:";
                                    temp = reinterpret_cast<const char*>(sqlite3_column_text(results2, 2));
                                    //loop to print condition information in a structured format
                                    for(int i = 0; i < temp.length(); i++){
                                        if(i == 0){     //on first iteration create a new line and print the first character value
                                            cout << endl;
                                            cout << temp[i];
                                        }
                                        else if(i % 50 != 0){   //Not first iteration and modulus operator doesn't have 0 as a remainder
                                            cout << temp[i];
                                        }
                                        else{   //When remainder is 0 come here to print the value and create a new line
                                            cout << temp[i] << endl;
                                        }
                                    }//end for
                                    cout << endl;
                                    cout << "Start of Symptoms: ";
                                    temp = reinterpret_cast<const char*>(sqlite3_column_text(results2, 3));
                                    cout << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7] << endl;
                                    cout << "Severity of Symptoms: " << sqlite3_column_text(results2, 4) << endl;
                                    cout << "General Effected Area:";
                                    temp = reinterpret_cast<const char*>(sqlite3_column_text(results2, 5));
                                    //loop to print the effected area information in a structured format
                                    for(int i = 0; i < temp.length(); i++){
                                        if(i == 0){     //on first iteration create a new line and print the first character value
                                            cout << endl;
                                            cout << temp[i];
                                        }
                                        else if(i % 50 != 0){   //Not first iteration and modulus operator doesn't have 0 as a remainder
                                            cout << temp[i];
                                        }
                                        else{   //When remainder is 0 come here to print the value and create a new line
                                            cout << temp[i] << endl;
                                        }
                                    }//end for
                                }//end while
                                cout << endl;
                            }//end else
                        }//end if to print symptom information
                        break;                                                  //break while loop printing info
                    }//end while 
                }//end else
            }//end if
        }//end while
    }//end else
    cout << endl;
}//end printPatient


//function to search database by first and last name
void searchName(sqlite3 *db, string query){
    sqlite3_stmt *result;
    string strLastError, temp;
    int userInput, patient_id;
    char *err;
    int i = 1;
    int rc;

    rc = sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL);
    if(rc != SQLITE_OK){
        strLastError = sqlite3_errmsg(db);
        sqlite3_finalize(result);
        cout << "There was an error selecting patient(s) by that name: " << strLastError << endl;
        rollback(db);
        return;
    }
    
    rc = sqlite3_step(result);
    if(sqlite3_column_text(result, 0) == NULL){                     //if patient id returns null patient does not exist within database
        cout << "Patient(s) could not be found in database." << endl << endl;
        sqlite3_finalize(result);
        rollback(db);
        return;
    }

    cout << "****Patient(s) Information****" << endl;
    while (rc == SQLITE_ROW){               //Print patient first and last name with date of birth for user to choose from to see more info
        cout << i << ". " << sqlite3_column_text(result, 1) << " ";     //print the current count and the first name from table
        if(sqlite3_column_text(result, 2) != NULL){                     //make sure middle initial is not null
            cout << sqlite3_column_text(result, 2) << ". ";             //print middle initial if not null
        }
        cout << sqlite3_column_text(result, 3);     //print patient last name from database
        cout << " - DOB: ";
        temp = reinterpret_cast<const char*>(sqlite3_column_text(result, 4));              //cast dob of birth to string variable to split for proper output
        cout << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7];     //split date by MM-DD-YYYY
        cout << endl;
        i++;                                        //increment i by 1
        rc = sqlite3_step(result);                  //step to the next row if row exists
    }

    cout << endl;
    cout << "Choose patient from list or enter -1 to cancel search." << endl;
    cout << "Enter choice: ";
    cin >> userInput;
    cout << endl;

    while(!cin || userInput < 1 || userInput > i){
        if(userInput == -1){
            return;
        }
        if (!cin){
            cin.clear();
            cin.ignore(1000, '\n');
        }
        cout << "That is not a valid patient! Try again!" << endl;
        cin >> userInput;
        cout << endl;
    }
    sqlite3_reset(result);

    for (int j = 0; j < userInput; j++){
        sqlite3_step(result);
    }

    patient_id = sqlite3_column_int(result, 0);
    sqlite3_finalize(result);

    i = 1;
	query = "select * from patient where patient_id = " + to_string(patient_id) + ";";
    rc = sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL);
	if(rc != SQLITE_OK) {
		strLastError = sqlite3_errmsg(db);
		sqlite3_finalize(result);
		cout << "There was an error: " << strLastError << endl;
		rollback(db);
		return;
	}
    sqlite3_finalize(result);
    printPatient(db, query);
}//end searchName


//function to validate Date of Birth
bool isDOB(string DOB){
    for(int i = 0; i < DOB.length(); i++){                              //loop runs the length of DOB (8)
        switch(i){
            case 0:         //the first element must be 0 or 1
                if(DOB[i] == '0' || DOB[i] == '1'){                     //check that first element is 0 or 1
                    break;
                }
                else{                                                   //else return false
                    return false;
                }            
                break;                                                  //end case 0

            case 2:         //the third element must be 0, 1, 2, or 3 and never over 31  
                if(DOB[i] >= '0' && DOB[i] <= '3'){                  
                    break;
                }
                else{
                    return false;
                }
                break;                                                  //end case 2

            default:        //the fourth thru eighth elements need to be between 0 and 9
                if(DOB[i] >= '0' && DOB[i] <= '9'){
                    break;
                }
                else{
                    return false;
                }
        }//end switch
    }//end for

    //Now check that month (00), day (00), and year (0000) fit within the proper constraint once put together
    string month;
    month = DOB[0];
    month += DOB[1];
    if(month >= "01" && month <= "12"){     //check that the month is constrained to 01 thru 12
        string day;
        day = DOB[2];
        day += DOB[3];
        if(day >= "01" && day <= "31"){     //check that the day is constrained to 01 thru 31
            string year;
            year = DOB[4];
            year += DOB[5];
            year += DOB[6];
            year += DOB[7];
            if(year >= "1900" && year <= "2999"){       //check that the year is constrained to 0000 to 9999 (because i have non real characters in here with random time periods, otherwise restriction would be more relevant)
                return true;
            }
            else{
                //cout << "Error on year." << endl;
                return false;
            }
        }
        else{
            //cout << "Error on day." << endl;
            return false;
        }
    }//end if
    else{
        //cout << "Error on month." << endl;
        return false;
    }
}//end isDOB


//function is a menu with 5 options to search the database
void searchDatabase(sqlite3 *db){
    bool boolean = true;
    string query, DbMenu, ID, Fname, Lname, DOB, temp, County, test;
    int Menu, rc, i, userInput, patient_id, pathogenID;
    char * err;                         //print error message
    string LastError;                   //to print error message from query
    sqlite3_stmt * results;             //results of sql statments
    
    searchMenu();                       //print menu
    cout << "Enter choice: ";
                    
    while(boolean){                     //validation loop
        cin >> DbMenu;
        cout << endl;                   //skip line for output
        if(isDigit(DbMenu)){                                        //check entry is a digit
            if(DbMenu >= "1" && DbMenu <= "5"){                     //check entry is within constraint
                Menu = stoi(DbMenu);                                //convert string to number
                boolean = false;                                    //change bool
            }
            else {
                cout << "Please only enter 1 - 5 only." << endl;    //print error
                cin.clear();                                        
                cin.ignore(1000, '\n');
            }
        }
        else{
            cout << "Please only enter an integer number." << endl; //print error
            cin.clear();
            cin.ignore(1000, '\n');
        }
    }//end while
    boolean = true;     ///reset boolean after while loop
    cin.clear();
    cin.ignore(1000, '\n');
    
    switch(Menu){                                                   //switch case for patient database
//Search patient by id
        case 1:
            cout << "Enter Patient ID Number." << endl;
            cout << "Enter ID: ";

            while(boolean){
                cin >> ID;
                cout << endl;                                       //skip line for output
                if(isDigit(ID)) {                                   //check entry is a digit
                    boolean = false;                                //change boolean for loop
                }
                else{
                    cout << "Please only enter an integer number for the Patient ID." << endl;  //print error
                    cin.clear();
                    cin.ignore(1000, '\n');
                }
            }//end while
            boolean = true;     //reset boolean after while loop

            query = "select * from Patient where patient_ID = " + ID + ";";
            if(sqlite3_prepare_v2(db, query.c_str(), -1, &results, NULL) != SQLITE_OK) {        //check query for errors
		        LastError = sqlite3_errmsg(db);
		        sqlite3_finalize(results);
		        cout << "There was an error: " << LastError << endl;
		        rollback(db);
		        return;
	        }
            sqlite3_step(results);                                           //reset result

            if(sqlite3_column_text(results, 0) == NULL){                     //if patient id returns null patient does not exist within database
                cout << "Patient(s) could not be found in database." << endl << endl;
                sqlite3_finalize(results);
                rollback(db);
                return;
            }
            sqlite3_finalize(results);                                      //reset statement

            printPatient(db, query);                                        //send query and database to printPatient
            break;      //end case 1

//Search patient by first and last name
        case 2:
            cout << "To search by name please enter the first name of the patient." << endl;
            cout << "Enter name: ";

            while(boolean){
                getline(cin, Fname);
                cout << endl;                                                                   //skip line for output
                if(Fname.length() > 0 && Fname.length() <= 50){                                 //check input is within size constraint
                    if(isWord(Fname) || !cin) {     //if functions finds string is made up of the alphabet then change boolean to false to end loop
                        boolean = false;            //change boolean value
                    }
                    else {
                        cout << "Please only enter letters from the alphabet for first name. Entry is case sensitive." << endl; //print error
                        cin.clear();
                        Fname.clear();
                        cin.ignore(1000, '\n');
                    }
                }
                else{
                    cout << "Invalid input. Entry has a character limit of 50 and cannot be empty." << endl;            //print error
                    cin.clear();
                    Fname.clear();
                    cin.ignore(1000, '\n');
                }    
            }
            boolean = true;     //reset boolean after while loop

            cout << "To search by name please enter the last name of the patient." << endl;
            cout << "Enter name: ";

            while(boolean) {
                getline(cin, Lname);
                cout << endl;                                                                   //skip line for output
                if(Lname.length() > 0 && Lname.length() <= 50){                                 //check input is within time constraint
                    if(isWord(Lname) || !cin) {     //if string is made up of the alphabet then change boolean to false to end loop
                        boolean = false;            //change boolean for loop
                    }
                    else {
                        cout << "Please only enter letter from the alphabet for last name. Entry is case sensitive." << endl;   //print error
                        cin.clear();
                        cin.ignore(1000, '\n');
                    }
                }
                else{
                    cout << "Invalid input. Entry has character limit of 50 and cannot be empty." << endl;          //print error
                    cin.clear();
                    cin.ignore(1000, '\n');
                }    
            }
            boolean = true;     //change boolean back to true to prevent any unnessecary errors

            query = "select * from patient where Patient.First_Name = '" + Fname + "' and Patient.Last_Name = '" + Lname + "';";
            searchName(db, query);
            break;
                        
//Search patient by first and last name and date of birth
        case 3:
            cout << "Please enter the patients first name." << endl;
            cout << "Enter name: ";

            while(boolean) {
                getline(cin, Fname);
                cout << endl;                                                                   //skip line for output
                if(Fname.length() > 0 && Fname.length() <= 50){                             //check entry is within size constraint
                    if(isWord(Fname) || !cin){                                              //check entry is word
                        boolean = false;                                                    //change boolean to false
                    }
                    else {
                        cout << "Please only enter letters from the alphabet for the first name. Entry is case sensitive." << endl; //print error
                        cin.clear();
                        cin.ignore(1000, '\n');
                    }
                }
                else{
                    cout << "Invalid input. Entry has character limit of 50 and cannot be empty." << endl;      //print error
                    cin.clear();
                    cin.ignore(1000, '\n');
                }    
            }//end while
            boolean = true;     //reset boolean value

            cout << "Please enter the patients last name." << endl;
            cout << "Enter name: ";
            while(boolean) {
                getline(cin, Lname);
                cout << endl;                                                                   //skip line for output
                if(Lname.length() > 0 && Lname.length() <= 50){                                 //check entry is within size constraint
                    if(isWord(Lname) || !cin) {                                                 //check entry is word
                        boolean = false;                                                        //change boolean
                    }
                    else {
                        cout << "Please only enter letters from the alphabet for the last name. Entry is case sensitive." << endl;  //print error
                        cin.clear();
                        cin.ignore(1000, '\n');
                    }
                }
                else{
                    cout << "Invalid input. Entry has character limit of 50 and cannot be empty." << endl;  //print error
                    cin.clear();
                    cin.ignore(1000, '\n');
                }
            }//end while
            boolean = true;     //reset boolean value

            cout << "Please enter the patients date of birth. Please no hyphens or slashes. EX: (MMDDYYY)" << endl;
            cout << "Enter Date: ";
            while (boolean) {                    //validation loop for DOB before moving forward
                cin >> DOB;
                cout << endl;                    //skip line for output
                if(isDigit(DOB)){                //function returns true if DOB is only made of values 0-9
                    if(DOB.length() == 8){       //check that length is 8 char long before even checking if proper format
                        if(isDOB(DOB)){          //function returns true if DOB entered meets the constraints
                            boolean = false;
                        }
                        else{
                            cout << "Entry was not in the proper order. EX: (MMDDYYY) = (03051999)" << endl;    //print error
                            cin.clear();
                            cin.ignore(1000, '\n'); 
                        }
                    }
                    else{
                        cout << "Entry was number but not the correct length for input. Please make sure entry is 8 digits long." << endl;  //print error
                        cin.clear();
                        cin.ignore(1000, '\n');
                    }
                }//end if to validate dob
                else{
                    cout << "Please only enter integer numbers for the date of birth." << endl;     //print error
                    cin.clear();
                    cin.ignore(1000, '\n');
                }//end else of isDOB()
            }//end while
            
            cout << "****List of Patients with matching info****" << endl;
            query = "select * from patient where Patient.First_Name = '" + Fname + "' and Patient.Last_Name = '" + Lname + "' and Patient.DOB = '" + DOB + "';";
            if(sqlite3_prepare_v2(db, query.c_str(), -1, &results, NULL) != SQLITE_OK) {
		        LastError = sqlite3_errmsg(db);
		        sqlite3_finalize(results);
		        cout << "There was an error: " << LastError << endl;
		        rollback(db);
		        return;
	        }
            sqlite3_step(results);

            if(sqlite3_column_text(results, 0) == NULL){                     //if patient id returns null patient does not exist within database
                cout << "Patient(s) could not be found in database." << endl << endl;
                sqlite3_finalize(results);
                rollback(db);
                return;
            }
            sqlite3_reset(results);

            i = 1;
            while (sqlite3_step(results) == SQLITE_ROW){               //Print patient first and last name with date of birth for user to choose from to see more info
                cout << i << ". " << sqlite3_column_text(results, 1) << " ";     //print the current count and the first name from table
                if(sqlite3_column_text(results, 2) != NULL){                     //make sure middle initial is not null
                    cout << sqlite3_column_text(results, 2) << ". ";             //print middle initial if not null
                }
                cout << sqlite3_column_text(results, 3);     //print patient last name from database
                cout << " - DOB: ";
                temp = reinterpret_cast<const char*>(sqlite3_column_text(results, 4));              //cast dob of birth to string variable to split for proper output
                cout << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7];     //split date by MM-DD-YYYY
                cout << endl;
                i++;                                        //increment i by 1
            }//end while
            cout << endl;

            cout << "Choose patient from list or enter -1 to cancel search." << endl;       //print list to user of patients
            cout << "Enter choice: ";
            cin >> userInput;
            cout << endl;

            while(!cin || userInput < 1 || userInput > i){                                  //validate input
                if(userInput == -1){
                    rollback(db);
                    return;
                }
                if (!cin){
                    cin.clear();
                    cin.ignore(1000, '\n');
                }
                cout << "That is not a valid patient! Try again!" << endl;                  //print error message
                cin >> userInput;
                cout << endl;
            }

            sqlite3_reset(results);                                                         //reset results
            for (int j = 0; j < userInput; j++){                                            //set results to user choice
                sqlite3_step(results);  
            }

            patient_id = sqlite3_column_int(results, 0);                                    //store the primary key from database in patient_id
            sqlite3_finalize(results);                                                      //reset results

	        query = "select * from patient where patient_id = " + to_string(patient_id) + ";";  //query database for information of chosen patient
	        if(sqlite3_prepare_v2(db, query.c_str(), -1, &results, NULL) != SQLITE_OK) {        //check statement for errors
		        LastError = sqlite3_errmsg(db);
		        sqlite3_finalize(results);
		        cout << "There was an error: " << LastError << endl;
		        rollback(db);
		        return;
	        }

            printPatient(db, query);                                                            //send database and clear query to printPatient function
            break;                                                                              //end case 3


    //Find patients with the same Pathogen
        case 4:
            //query to get all pathogens from the pathogen table
            query = "select Pathogen_ID, Pathogen_Type, Pathogen_Severity from pathogen;";
            if(sqlite3_prepare_v2(db, query.c_str(), -1, &results, NULL) != SQLITE_OK){               //compare returned value to SQLITE_OK variable
                LastError = sqlite3_errmsg(db);                                                         //use LastError string to hold err msg from database
                sqlite3_finalize(results);                                                              //reset results statement
                cout << "There was an error selecting from Pathogen table: " << LastError << endl;      //print error message
                rollback(db);                                                                           //rollback database
                return;                                                                                 //return to main menu
            }

            i = 1;
            cout << "Which pathogen do you want to search? Pick from the list below." << endl;
            cout << "\t ---- Pathogen     |     Severity ----" << endl;
            while(sqlite3_step(results) == SQLITE_ROW){
                test = reinterpret_cast<const char*>(sqlite3_column_text(results, 1));
                if(test.length() < 13){                                                         //check if string is less than 13 in length to print 4 tabs
                    cout << i << ". " << sqlite3_column_text(results, 1) << "\t\t\t\t" << sqlite3_column_int(results, 2) << endl;
                }
                else{                                                                           //else print with 3 tabs
                    cout << i << ". " << sqlite3_column_text(results, 1) << "\t\t\t" << sqlite3_column_int(results, 2) << endl;
                }
                i++;                                                                            //increment i by 1 for output
            }//end while to print pathogens

            cout << "Enter choice: ";
            cin >> userInput;
            cout << endl;

            while(!cin || userInput < 1 || userInput > i || userInput == i){        //while loop to catch input outside of designated range
                if(userInput == -1){                               //if -1 return to main menu
                    rollback(db);
                    return;
                }
                if (!cin){                                          //if error on input
                    cin.clear();                                    //clear input
                    cin.ignore(1000, '\n');                         //ignore anything left
                }
                cout << "That is not a valid pathogen! Try again or enter -1 to cancel." << endl;      //print error message and to prompt user for re-entry
                cin >> userInput;                      
                cout << endl;
            }
            sqlite3_reset(results);                                     //reset results statement

            for(int j = 0; j < userInput; j++){                         //run until users choice
                sqlite3_step(results);                                  //move to next row
            }//end for

            pathogenID = sqlite3_column_int(results, 0);                //set pathogenID to the primary key from database
            sqlite3_finalize(results);                                  //reset results statement


            //query to get list of patients who have ever had chosen pathogen
            query = "select Patient_ID, First_Name, Middle_Initial, Last_Name, DOB, Address, County from Patient where Patient_ID = ";
                query += "(select Patient_ID from Epi_Case where Patient.Patient_ID = Epi_Case.Patient_ID and Pathogen_ID = ";
                query += to_string(pathogenID) + ");";
            if(sqlite3_prepare_v2(db, query.c_str(), -1, &results, NULL) != SQLITE_OK){               //compare returned value to SQLITE_OK variable
                LastError = sqlite3_errmsg(db);                                                         //use LastError string to hold err msg from database
                sqlite3_finalize(results);                                                              //reset results statement
                cout << "There was an error selecting from Pathogen table: " << LastError << endl;      //print error message
                rollback(db);                                                                           //rollback database
                return;                                                                                 //return to main menu
            }
            sqlite3_step(results);                                                                      //step prepared statement and execute query

            //check if empty
            if(sqlite3_column_text(results, 0) == NULL){                                                //check if nothing was returned
                cout << "No patients exist with this Pathogen in the database." << endl;            //print error message
                cout << endl;                                                                       //skip line for output
                rollback(db);                                                                       //rollback database
                return;                                                                             //return to main menu
            }

            //print results back to user
            sqlite3_reset(results);                                                                 //reset statement
            i = 1;                                                                                  //set i to 1 for output
            cout << "\t----- List of patients with matching pathogen -----" << endl;                //print list of found data
            while(sqlite3_step(results) == SQLITE_ROW){                                             //run until results no longer equal a row
                cout << i << ". " << sqlite3_column_text(results, 1) << " " << sqlite3_column_text(results, 3);
                cout << "  -  DOB: " << sqlite3_column_text(results, 4) << "  -  Address: " << sqlite3_column_text(results, 5);
                cout << ", " << sqlite3_column_text(results, 6) << endl;
                i++;                                                                                //increment i by 1 for output
            }
            sqlite3_finalize(results);                                                              //reset results statement
            cout << endl;                                                                           //skip line for output

            //relevant data
            cout << "\t----- Relevant Info from Search -----" << endl;                              //prompt for data coming next
            cout << "Number of patients who have contracted pathogen: " << i - 1 << endl;           //print number of patients with pathogen
            break;                                                                                  //end case 4


    //Find patients with the same Pathogen and County
        case 5:
            //query to get all pathogens from the pathogen table
            query = "select Pathogen_ID, Pathogen_Type, Pathogen_Severity from pathogen;";
            if(sqlite3_prepare_v2(db, query.c_str(), -1, &results, NULL) != SQLITE_OK){               //compare returned value to SQLITE_OK variable
                LastError = sqlite3_errmsg(db);                                                         //use LastError string to hold err msg from database
                sqlite3_finalize(results);                                                              //reset results statement
                cout << "There was an error selecting from Pathogen table: " << LastError << endl;      //print error message
                rollback(db);                                                                           //rollback database
                return;                                                                                 //return to main menu
            }

            i = 1;
            cout << "Which pathogen do you want to search? Pick from the list below." << endl;
            cout << "\t ---- Pathogen     |     Severity ----" << endl;
            while(sqlite3_step(results) == SQLITE_ROW){
                test = reinterpret_cast<const char*>(sqlite3_column_text(results, 1));
                if(test.length() < 13){                                                         //check if string is less than 13 in length to print 4 tabs
                    cout << i << ". " << sqlite3_column_text(results, 1) << "\t\t\t\t" << sqlite3_column_int(results, 2) << endl;
                }
                else{                                                                           //else print with 3 tabs
                    cout << i << ". " << sqlite3_column_text(results, 1) << "\t\t\t" << sqlite3_column_int(results, 2) << endl;
                }
                i++;                                                                            //increment i by 1 for output
            }//end while to print pathogens

            cout << "Enter choice: ";
            cin >> userInput;
            cout << endl;

            while(!cin || userInput < 1 || userInput > i || userInput == i){        //while loop to catch input outside of designated range
                if(userInput == -1){                               //if -1 return to main menu
                    rollback(db);
                    return;
                }
                if (!cin){                                          //if error on input
                    cin.clear();                                    //clear input
                    cin.ignore(1000, '\n');                         //ignore anything left
                }
                cout << "That is not a valid pathogen! Try again or enter -1 to cancel." << endl;      //print error message and to prompt user for re-entry
                cin >> userInput;                      
                cout << endl;
            }
            sqlite3_reset(results);                                     //reset results statement

            for(int j = 0; j < userInput; j++){                         //run until users choice
                sqlite3_step(results);                                  //move to next row
            }//end for

            pathogenID = sqlite3_column_int(results, 0);                //set pathogenID to the primary key from database
            sqlite3_finalize(results);                                  //reset results statement

            //query to get list of available counties from database
            query = "select distinct County from Patient;";
            if(sqlite3_prepare_v2(db, query.c_str(), -1, &results, NULL) != SQLITE_OK){                 //compare returned value to SQLITE_OK variable
                LastError = sqlite3_errmsg(db);                                                         //use LastError string to hold err msg from database
                sqlite3_finalize(results);                                                              //reset results statement
                cout << "There was an error selecting from Patient table: " << LastError << endl;       //print error message
                rollback(db);                                                                           //rollback database
                return;                                                                                 //return to main menu
            }

            i = 1;                                                                                      //set i to 1 for output
            cout << "Which county do you want to search by? Pick from the list below." << endl;
            cout << "\t ---- Counties ----" << endl;
            while(sqlite3_step(results) == SQLITE_ROW){                                                 //run through returned results 
                cout << i << ". " << sqlite3_column_text(results, 0) << endl;
                i++;                                                                            //increment i by 1 for output
            }//end while to print pathogens

            cout << "Enter choice: ";
            cin >> userInput;
            cout << endl;

            while(!cin || userInput < 1 || userInput > i || userInput == i){        //while loop to catch input outside of designated range
                if(userInput == -1){                               //if -1 return to main menu
                    rollback(db);
                    return;
                }
                if (!cin){                                          //if error on input
                    cin.clear();                                    //clear input
                    cin.ignore(1000, '\n');                         //ignore anything left
                }
                cout << "That is not a valid patient! Try again or press -1 to cancel." << endl;      //print error message and to prompt user for re-entry
                cin >> userInput;                      
                cout << endl;
            }//end while
            sqlite3_reset(results);                                     //reset results statement

            for(int j = 0; j < userInput; j++){                         //run until users choice
                sqlite3_step(results);                                  //move to next row
            }//end for

            County = reinterpret_cast<const char*>(sqlite3_column_text(results, 0));         //set County name from database to string County
            sqlite3_finalize(results);                                                       //reset results statement


            //query to get list of patients who have ever had chosen pathogen and are from the same county
            query = "select Patient_ID, First_Name, Middle_Initial, Last_Name, DOB, Address, County from Patient where County = '";
                query += County + "' and Patient_ID = (select Patient_ID from Epi_Case where Patient.Patient_ID = Epi_Case.Patient_ID ";
                query += "and Pathogen_ID = " + to_string(pathogenID) + ");";
            if(sqlite3_prepare_v2(db, query.c_str(), -1, &results, NULL) != SQLITE_OK){               //compare returned value to SQLITE_OK variable
                LastError = sqlite3_errmsg(db);                                                         //use LastError string to hold err msg from database
                sqlite3_finalize(results);                                                              //reset results statement
                cout << "There was an error selecting from Patient table: " << LastError << endl;       //print error message
                rollback(db);                                                                           //rollback database
                return;                                                                                 //return to main menu
            }
            sqlite3_step(results);                                                                      //step prepared statement and execute query
            
            //check if empty
            if(sqlite3_column_text(results, 0) == NULL){                                                //check if nothing was returned
                cout << "No patients exist with this Pathogen in the database." << endl;            //print error message
                cout << endl;                                                                       //skip line for output
                rollback(db);                                                                       //rollback database
                return;                                                                             //return to main menu
            }

            //print results back to user
            sqlite3_reset(results);                                                                 //reset statement
            i = 1;                                                                                  //set i to 1 for output
            cout << "\t----- List of patients with matching pathogen and county -----" << endl;     //print list of found data
            while(sqlite3_step(results) == SQLITE_ROW){                                             //run until results no longer equal a row
                cout << i << ". " << sqlite3_column_text(results, 1) << " " << sqlite3_column_text(results, 3);
                cout << "  -  DOB: " << sqlite3_column_text(results, 4) << "  -  Address: " << sqlite3_column_text(results, 5);
                cout << ", " << sqlite3_column_text(results, 6) << endl;
                i++;                                                                                //increment i by 1 for output
            }
            sqlite3_finalize(results);                                                              //reset results statement
            cout << endl;                                                                           //skip line for output

            //relevant data
            cout << "\t----- Relevant Info from Search -----" << endl;
            cout << "Number of patients who have contracted pathogen: " << i - 1 << endl;
            cout << "County of potential outbreak: " << County << endl;

            break;
    }//end switch
    cout << endl;                                                   //skip line for output before returning to main
}//end searchPatient


//function to create a new Patient in the database
void createPatient(sqlite3 *db){
    /*
    Patient_ID                  int (Primary Key)
    First_Name                  varchar(50)
    Middle_Initial              char(1)
    Last_Name                   varchar(50)
    DOB                         varchar(8)
    Address                     varchar(50)
    County                      varchar(50)
    Gender                      varchar(50)
    Marital_Status              varchar(8)
    Ethnicity                   varchar(50)
    Nationality                 varchar(50)
    Phone                       char(10)
    Email                       varchar(50)
    Epi_ID                      int
    */
    char * err;                         //print error message
    string LastError;                   //to print error message from query
    sqlite3_stmt * results;             //results of sql statments
    string query;
    string Input;
    string fname, lname, dob, address, county, gender, maritalStatus, ethnicity, nationality, phone, email;
    int Patient_ID, Epi_ID;
    char mname;
    bool loop = true;
    
    query = "begin transaction;";                                                       //attempt to create a new save point for the database if things go wrong
    if(sqlite3_exec(db, query.c_str(), NULL, NULL, &err) != SQLITE_OK){                 //begin transaction
        cout << "Error starting transaction: " << err << endl;                          //print error
        sqlite3_free(err);                                                              //free up pointer
        return;                                                                         //return to main
    }

//gather first name
    cout << "Please input the new patients first name." << endl;
    cout << "Enter name: ";
    cin.clear();
    cin.ignore(1000, '\n');
    while (loop){
        getline(cin, fname);
        cout << endl;                                                                   //skip line for output
        if(isWord(fname) && (fname.length() >= 1 && fname.length() <= 50)){
            break;
        }
        else{
            cout << "Error with name. Try again." << endl;
            cin.clear();
        }
    }//end while


//gather middle initial
    cout << "Please input the new patients middle initial. If empty enter -1." << endl;
    cout << "Enter initial: ";
    while (loop){
        cin >> Input;
        cout << endl;                                                                   //skip line for output
        if(Input == "-1"){
            Input = "NULL";
            break;
        }
        if(isWord(Input)){
            if(Input.length() == 1){
                mname = Input[0];
                break;
            }
            else{
                cout << "Initial can only be one character." << endl;
                cin.clear();
                cin.ignore(1000, '\n');
            }
        }
        else{
            cout << "Error with middle initial. Try again." << endl;
            cin.clear();
            cin.ignore(1000, '\n');
        }
    }//end while


//gather last name
    cout << "Please input the new patients last name." << endl;
    cout << "Enter name: ";
    cin.clear();
    cin.ignore(1000, '\n');

    while (loop){
        getline(cin, lname);
        cout << endl;                                                                   //skip line for output
        if(isWord(lname) && (lname.length() >= 1 && lname.length() <= 50)){
            break;
        }
        else{
            cout << "Error with last name. Try again." << endl;
            cin.clear();
        }
    }//end while


//gather dob
    cout << "Please enter the new patients date of birth. Please no hyphens or slashes. EX: (MMDDYYYY)" << endl;
    cout << "Enter Date: ";
    while (loop) {       //validation loop for DOB before moving forward
        cin >> dob;
        cout << endl;                                                                   //skip line for output
        if(isDigit(dob)){       //function returns true if DOB is only made of values 0-9
            if(dob.length() == 8){      //check that length is 8 char long before even checking if proper format
                if(isDOB(dob)){     //function returns true if DOB entered meets the constraints
                    break;
                }
                else{
                    cout << "Entry was not in the proper order. EX: (MMDDYYYY) = (03051999)" << endl;
                    cin.clear();
                    cin.ignore(1000, '\n'); 
                }
            }
            else{
                cout << "Entry was number but not the correct length for input. Please make sure entry is 8 digits long." << endl;
                cin.clear();
                cin.ignore(1000, '\n');
            }
        }//end if to validate dob
        else{
            cout << "Please only enter integer numbers for the date of birth." << endl;
            cin.clear();
            cin.ignore(1000, '\n');
        }//end else 
    }//end while


//gather Address                     varchar(50)
    cout << "Enter the new patients address. (Ex: 111 Street Name)" << endl;
    cout << "Enter address: ";
    cin.clear();
    cin.ignore(1000, '\n');
    
    while(loop){
        getline(cin, address);
        cout << endl;                                                                   //skip line for output
        if(isAddress(address)){
            if(address.length() >= 1 && address.length() <= 50){
                break;
            }
            else{
                cout << "Address can not be over 50 characters." << endl;
                cin.clear();
            }
        }
        else{
            cout << "Error with address. No comma's, periods, or special characters." << endl;
            cin.clear();
        }
    }//end while


//gather County                      varchar(50)
    cout << "Enter the county. (Ex: Marion)" << endl;
    cout << "Enter county: ";
    while(loop){       
        getline(cin, county);
        cout << endl;                                                                   //skip line for output
        if(isWord(county)){
            if(county.length() >= 1 && county.length() <= 50){
                break;
            }
            else{
                cout << "County can not be over 50 characters or left blank." << endl;
                cin.clear();
            }
        }
        else{
            cout << "Error with county. Try again." << endl;
            cin.clear();
        }
    }//end while


//gather Gender                      varchar(50)
    cout << "Enter the new patients gender. (Ex: Non Binary, Female, etc)" << endl;
    cout << "Enter gender: ";
    while(loop){ 
        getline(cin, gender);
        cout << endl;                                                                   //skip line for output
        if(isWord(gender)){
            if(gender.length() >= 1 && gender.length() <= 50){
                break;
            }
            else{
                cout << "Gender can not be over 50 characters." << endl;
                cin.clear();
            }
        }
        else{
            cout << "Invalid entry. No comma's, periods, or special characters." << endl;
            cin.clear();
        }
    }//end while


//gather Marital_Status              varchar(8)
    cout << "Enter the new patients marital status. (Ex: Married, Single, Divorced)" << endl;
    cout << "Enter marital status: ";
    while(loop){     
        getline(cin, maritalStatus);
        cout << endl;                                                                   //skip line for output
        if(isWord(maritalStatus)){
            if(maritalStatus.length() >= 1 && maritalStatus.length() <= 8){
                break;
            }
            else{
                cout << "Marital status can not be over 50 characters or left blank." << endl;
                cin.clear();
            }
        }
        else{
            cout << "Invalid entry. No comma's, periods, or special characters." << endl;
            cin.clear();
        }
    }//end while


//gather Ethnicity                   varchar(50)
    cout << "Enter the new patients ethnicity. (Ex: White, Black, African American, European American, etc.)" << endl;
    cout << "Enter ethnicity: ";
    while(loop){
        getline(cin, ethnicity);
        cout << endl;                                                                   //skip line for output
        if(isWord(ethnicity)){
            if(ethnicity.length() >= 1 && ethnicity.length() <= 50){
                break;
            }
            else{
                cout << "Ethinicity can not be over 50 characters or left blank." << endl;
                cin.clear();
            }
        }
        else{
            cout << "Invalid entry. No comma's, periods, or special characters." << endl;
            cin.clear();
        }
    }//end while


//gather Nationality                 varchar(50)
    cout << "Enter the new patients nationality. (Ex: American, Canadian, Italian, etc.)" << endl;
    cout << "Enter nationality: ";
    while(loop){      
        getline(cin, nationality);
        cout << endl;                                                                   //skip line for output
        if(isWord(nationality)){
            if(nationality.length() >= 1 && nationality.length() <= 50){
                break;
            }
            else{
                cout << "Nationality can not be over 50 characters or left blank." << endl;
                cin.clear();
            }
        }
        else{
            cout << "Invalid entry. No comma's, periods, or special characters." << endl;
            cin.clear();
        }
    }//end while


//gather Phone                       char(10)
    cout << "Enter the new patients phone number with no spaces or hyphens. (Ex: 1234567890)" << endl;
    cout << "Enter phone: ";
    while(loop){
        getline(cin, phone);
        cout << endl;                                                                   //skip line for output
        if(isDigit(phone)){
            if(phone.length() == 10){
                break;
            }
            else{
                cout << "Phone number must be 10 numbers." << endl;
                cin.clear();
            }
        }
        else{
            cout << "Invalid entry. Try again." << endl;
            cin.clear();
        }
    }//end while


//gather Email                       varchar(50)
    cout << "Enter the new patients email. (Ex: Example!423@gmail.com)" << endl;
    cout << "Enter email: ";
    while(loop){
        getline(cin, email);
        cout << endl;                                                                   //skip line for output
        if(isEmail(email)){
            if(email.length() >= 1 && email.length() <= 50){
                break;
            }
            else{
                cout << "Email can not be over 50 characters or left blank." << endl;
                cin.clear();
            }
        }
        else{
            cout << "Invalid entry. Try again." << endl;
            cin.clear();
        }
    }//end while


    query = "SELECT patient_id FROM patient ORDER BY patient_id DESC LIMIT 1;";         //query orders patient table by patient_id in a descending order. The limit 1 only returns the highest (most recent) index from table
    if((sqlite3_prepare_v2(db, query.c_str(), -1, &results, NULL)) != SQLITE_OK){       //check statement for anything errors
        LastError = sqlite3_errmsg(db);
        sqlite3_finalize(results);
        cout << "There was an error with selecting from Patient table: " << LastError << endl;         //print error from database
        rollback(db);                                                                   //rollback database to error free state
        return;                                                                         //return to main
    }
    sqlite3_reset(results);                                                             //reset statement to beginning state
    sqlite3_step(results);                                                              //step to the row with the id number
    Patient_ID = sqlite3_column_int(results, 0);                                        //set the value to the variable Patient_ID
    Patient_ID++;                                                                       //increment the index by 1 to create a unique entry 
    sqlite3_finalize(results);                                                          //reset statement when done

    if(Input == "NULL"){
        query = "insert into patient values (" + to_string(Patient_ID) + ", '" + fname + "', " + Input + ", '" + lname + "', '" + dob + "', '";
            query += address + "', '" + county + "', '" + gender + "', '" + maritalStatus + "', '" + ethnicity + "', '" + nationality + "', '" + phone + "', '";
            query += email + "', NULL)";
        //cout << "With Null line 1789: " << query << endl;
    }
    else{
        query = "insert into patient values (" + to_string(Patient_ID) + ", '" + fname + "', '" + mname + "', '" + lname + "', '" + dob + "', '";
            query += address + "', '" + county + "', '" + gender + "', '" + maritalStatus + "', '" + ethnicity + "', '" + nationality + "', '" + phone + "', '";
            query += email + "', NULL)";
        //cout << "Without NULL line 1795: " << query << endl;
    } 

    if((sqlite3_prepare_v2(db, query.c_str(), -1, &results, NULL)) != SQLITE_OK){
        LastError = sqlite3_errmsg(db);
        sqlite3_finalize(results);
        cout << "There was an error with insert into Patient table: " << LastError << endl;
        rollback(db);
        return;
    }
    sqlite3_finalize(results);

    if(sqlite3_exec(db, query.c_str(), NULL, NULL, &err) != SQLITE_OK){                 //begin transaction
        cout << "Error executing insert into Patient: " << err << endl;                 //print error
        sqlite3_free(err);                                                              //free up pointer
        return;                                                                         //return to main
    }
    
    commit(db);                                                                         //commit changes to the database
    cout << "Patient inserted into table successfully. Patient ID: " << Patient_ID << endl;
    cout << endl;
}//end createPatient


//function to create a new Pet(s) attached to patients exposure case in database
void createPet(sqlite3 *db, int epiID){
/*
****Pet****
Pet_ID                          int                         (Primary Key)
Pet_Species                     varchar(20)
Pet_Breed                       varchar(20)
Pet_Age                         int
*/

/*
****Pet Lookup****
Epi_ID                          int                         (Primary Key, Foreign Key)
Pet_ID                          int                         (Primary Key, Foreign Key)
*/

/*
****Epi Case****
Pet_ID                          int                         (Foreign Key)
*/
    int ID, age[10], cartSize = 0;                                    //store users input to insert into database for each pet
    string species[10], breed[10];                                    //stroe users input to insert into database for each pet
    string userInput;                                                 //used for user input
    string query;                                                     //used to query database
    int i = 1, choice;                                                //used for loop and validation input
    bool loop = true;                                                 //used to initiate each while loop, break statement will exit
    string LastError;                                                 //used to report error from database
    sqlite3_stmt *result;                                             //used to store results of query on database
    char *err;
    
    query = "begin transaction;";                                                       //attempt to create a new save point for the database if things go wrong
    if(sqlite3_exec(db, query.c_str(), NULL, NULL, &err) != SQLITE_OK){                 //begin transaction
        cout << "Error starting transaction: " << err << endl;                          //print error
        sqlite3_free(err);                                                              //free up pointer
        return;                                                                         //return to main
    }

    while(loop){                                                            //loop to input multiple pets
        cout << "What species is the animal? (Ex: Dog, Cat, Goldfish)" << endl;
        cout << "Enter species: ";
        cin.clear();                                                //clear input if error in input
        cin.ignore(1000, '\n');                                     //ignore anything left
        
        while(loop){                                                    //validate input from user
            getline(cin, species[cartSize]);                            //grab the entire line
            cout << endl;                                               //skip line for output
            if(species[cartSize].length() > 0 && species[cartSize].length() <= 20){
                if(isWord(species[cartSize])){                                  //string is checked character by character to check each is of the alphabet
                    break;                                                      //break and continue program
                }
                else{
                    cout << "Invalid Input. No special characters or numbers." << endl;           //print error message to user
                    cin.clear();                                                //clear input
                }
            }
            else{
                cout << "Invalid Input. Entry has character limit of 20 and cannot be empty." << endl;
                cin.clear();                                                    //clear input
            }
        }//end while


        cout << "What is the breed of your, " << species[cartSize] << "? (Ex: German Shephard, Calico, Oranda)" << endl;
        cout << "Enter breed: ";
        cin.clear();                                                //clear input

        while(loop){                                                        //validate input from user    
            getline(cin, breed[cartSize]);                                              //grab the entire line
            cout << endl;                                                               //skip line for output
            if(breed[cartSize].length() > 0 && breed[cartSize].length() <= 20){         //check that input is within size constraint of database
                if(isWord(breed[cartSize])){                              //string is checked character by character to check each is of the alphabet
                    break;                                                  //break and continue with program
                }
                else{
                    cout << "Invalid Input. No special characters or numbers." << endl;           //print error message to user
                    cin.clear();                                                //clear input
                }
            }
            else{
                cout << "Invalid Input. Entry has character limit of 20 and cannot be empty." << endl;
                cin.clear();
            }        
        }//end while

        cout << "What is the age of your, " << species[cartSize] << "?" << endl;
        cout << "Enter age: ";
        while(loop){                                                        //validate age of pet
            cin >> userInput;                                               //user enters int using a string
            cout << endl;                                                  //skip line for output
            if(isDigit(userInput)){                                         //string is check character by character to check only 0-9
                age[cartSize] = stoi(userInput);                                   //convert string to int variable
                break;                                                  //break and continue with program
            }
            else{
                cout << "Invalid Input. Enter a number." << endl;           //print error message to user
                cin.clear();                                                //clear input
                cin.ignore(1000, '\n');                                     //ignore anything left
            }
        }//end while


        cout << "Does the patient have more pets to enter? (Y or N)" << endl;                         //Find if patient has any symptom
        cout << "Enter choice: ";
        while(loop){                                                                                  //validate yes or no input
            cin >> userInput;                                                                         //get input from user as string
            cout << endl;                                                                             //skip line for output
            if(userInput == "Y" || userInput == "y" || userInput == "N" || userInput == "n"){         //check input is yes or no and end
                break;
            }
            else{
                cout << "Invalid entry. Enter 'Y' for yes or 'N' for no." << endl;          //prompt user with error message
                cin.clear();                                                                //clear input
                cin.ignore(1000, '\n');                                                     //ignore the rest
            }
        }//end while


//if answer is no update tables with all the info gathered
        if(userInput == "N" || userInput == "n"){
            
            //query the database to get the row with the highest index to increment it and create a unique id number
            query = "SELECT pet_id FROM pet ORDER BY pet_id DESC LIMIT 1;";                     //query orders pet table by pet_id in a descending order. The limit 1 only returns the highest (most recent) index from table
            if((sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL)) != SQLITE_OK){        //check statement for any errors
                LastError = sqlite3_errmsg(db);                                                 //store error message from database
                sqlite3_finalize(result);                                                       //reset the statement result
                cout << "There was an error with selecting from Pet table: " << LastError << endl;         //print error from database
                rollback(db);                                                                   //rollback database to error free state
                return;                                                                         //return to main
            }
            sqlite3_reset(result);                                                              //reset statement to beginning state
            sqlite3_step(result);                                                               //step to the row with the id number
            ID = sqlite3_column_int(result, 0);                                                 //set the value to the variable Patient_ID
            ID++;                                                                               //increment the index of current ID by 1 to create a unique entry 
            sqlite3_finalize(result);                                                           //reset statement when done
            
            for(int j = 0; j <= cartSize; j++){                 //for loop to insert all entries
        //query to insert into pet table
            query = "insert into pet values(" + to_string(ID) + ", '" + species[j] + "', '" + breed[j] + "', " + to_string(age[j]) + "); "; 
            if((sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL)) != SQLITE_OK){        //check statement for any errors
                LastError = sqlite3_errmsg(db);                                                 //store error message from database
                sqlite3_finalize(result);                                                       //reset the statement result
                cout << "There was an error with inserting into the Pet table: " << LastError << endl;         //print error from database
                rollback(db);                                                                   //rollback database to error free state
                return;                                                                         //return to main
            }
            sqlite3_finalize(result);                                                           //skip line for output


        //update pet_lookup table
            query += "insert into pet_lookup values (" + to_string(epiID) + ", " + to_string(ID) + ");";
            if((sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL)) != SQLITE_OK){        //check statement for any errors
                LastError = sqlite3_errmsg(db);                                                 //store error message from database
                sqlite3_finalize(result);                                                       //reset the statement result
                cout << "There was an error with inserting into Pet Lookup table: " << LastError << endl;         //print error from database
                rollback(db);                                                                   //rollback database to error free state
                return;                                                                         //return to main
            }
            sqlite3_finalize(result);                                                   //reset result statement
            
            if(sqlite3_exec(db, query.c_str(), NULL, NULL, &err) != SQLITE_OK){                 //begin transaction
                cout << "Error executing insert into Pet Lookup: " << err << endl;              //print error
                sqlite3_free(err);                                                              //free up pointer
                return;                                                                         //return to main
            }
            //cout << "Line 1983: " << query << endl;

        //update Epi Case with newest pet ID table
            query = "Update Epi_Case set Pet_ID = " + to_string(ID) + " where Epi_ID = " + to_string(epiID) + ";";
            if((sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL)) != SQLITE_OK){        //check statement for any errors
                LastError = sqlite3_errmsg(db);                                                 //store error message from database
                sqlite3_finalize(result);                                                       //reset the statement result
                cout << "There was an error with inserting Pet ID into Epi Case table " << LastError << endl;         //print error from database
                rollback(db);                                                                   //rollback database to error free state
                return;                                                                         //return to main
            }
            sqlite3_finalize(result);                                                   //reset result statement

            if(sqlite3_exec(db, query.c_str(), NULL, NULL, &err) != SQLITE_OK){                 //begin transaction
                cout << "Error executing insert into Epi Case: " << err << endl;                //print error
                sqlite3_free(err);                                                              //free up pointer
                return;                                                                         //return to main
            }

            //cout << "Line 2002: " << query << endl;
            ID++;                                                           //increment ID by 1 for the next iteration
            }//end for

            commit(db);                                     //commit changes
            return;                                         //once done inserting multiple pets return to exposure case to finish entry
        }//end if

//if yes increase cart size by 1
        cartSize++;                                 //increase cartSize by 1 for the next pet and pet lookup
    }//end while
}//createPet


//function to create a new Symptom(s) attached to patients exposure case in database
void createSymptom(sqlite3 *db, int epiID){
/*
****Symptom****
Symptom_ID                      int                         (Primary Key)
Epi_ID                          int                         (Foreign Key)
Symptom_Type                    varchar(200) NOT NULL
Start_Of_Symptom                char(8) NOT NULL
Symptom_Severity                int NOT NULL
Symptom_Effected_Area           varchar(100) NOT NULL
Symptom_Contagious              varchar(100) NOT NULL
*/
    int ID, severity[10], cartSize = 0;                               //store users input to insert into database for each symptom
    string type[10], area[10], contagious[10], startDate[8];          //store users input to insert into database for each symptom
    string userInput;                                                 //used for user input
    string query;                                                     //used to query database
    int i = 1, choice;                                                //used for loop and validation input
    bool loop = true;                                                 //used to initiate each while loop, break statement will exit
    string LastError;                                                 //used to report error from database
    sqlite3_stmt *result;                                             //used to store results of query on database
    char *err;
    
    query = "begin transaction;";                                                   //attempt to create a new save point for the database if things go wrong
    if(sqlite3_exec(db, query.c_str(), NULL, NULL, &err) != SQLITE_OK){             //begin transaction
        cout << "Error starting transaction: " << err << endl;                          //print error
        sqlite3_free(err);                                                              //free up pointer
        return;                                                                         //return to main
    }

    while(loop){                                                            //loop to input multiple symptoms

//gather symptom type
        cout << "What type of symptoms does the patient have? (Ex: Patient has had violent diarrhea with a high grade fever)" << endl;
        cout << "Enter symptom: ";
        cin.clear();                                                      //clear input if error in input
        cin.ignore(1000, '\n');                                           //ignore anything left
        
        while(loop){                                                            //validate user input
            getline(cin, type[cartSize]);                                       //grab the entire line
            cout << endl;                                                       //skip line for output
            if(type[cartSize].length() > 0 && type[cartSize].length() <= 200){  //check input is within size constraint for database
                break;                                                          //break and continue with program
            }
            else{
                cout << "Invalid Input. Entry has character limit of 200 and cannot be empty." << endl;     //print error message
                cin.clear();                                                                                //clear input
            }
        }//end while


//gather symptom start date
        cout << "Enter the estimated start date of the symptom. No hyphens, dashes, or slashes. (Ex: MMDDYYYY)" << endl;
        cout << "Date: ";
        while(loop){                                                  //validate user input
            cin >> startDate[cartSize];                                             //gather pathogen date from user
            cout << endl;                                                           //skip line for output
            if(startDate[cartSize].length() == 8){                                  //check entry is proper length
                if(isDate(startDate[cartSize])){                                    //use isDate function to validate the entry is a correct date
                    break;                                                          //break loop and continue program
                }
                else{
                    cout << "Invalide input. Input out of range. (Month: 01-12   Day: 01-31   Year: 1900-2999)" << endl;     //print error message
                    cin.clear();                                                                        //clear input
                    cin.ignore(1000, '\n');                                                             //ignore anything left
                }
            }
            else{
                cout << "Invalid input. Try again." << endl;                                            //print error message
                cin.clear();                                                                            //clear input
                cin.ignore(1000,'\n');                                                                  //ignore anything left
            }
        }//end while


//gather severity level of symptom
        cout << "What is the level of severtity for the patients symptoms? Enter 1 for low or 10 for high. (Ex: 6)" << endl;
        cout << "Enter severity: ";
        cin.clear();                                                //clear input

        while(loop){                                                        //validate number entered is in fact a number within range
            cin >> userInput;                                               //user enters a string for the int
            cout << endl;                                                   //skip line for output
            if(isDigit(userInput)){                                         //string is checked character by character to check each a number
                severity[cartSize] = stoi(userInput);                       //convert from string to int
                if(severity[cartSize] > 0 && severity[cartSize] <= 10){     //checks int is 1 - 10
                    break;                                                  //break loop and continue program
                }
                else{
                    cout << "Invalid entry. Enter a number 1 - 10. One is low, ten is high." << endl;       //print error message
                }
            }
            else{
                cout << "Invalid Input. No special characters or numbers." << endl;           //print error message
                cin.clear();                                                                  //clear input
                cin.ignore(1000, '\n');                                                       //ignore anything left
            }
        }//end while


//gather info on the symptoms effected area
        cout << "What is the main affected region of the patients symptoms?" << endl;
        cout << "Type input: ";
        cin.clear();                                                                //clear the input
        cin.ignore(1000, '\n');                                                     //ignore anything left

        while(loop){                                                                //validate entry is within size and made of of letters
            getline(cin, area[cartSize]);                                           //grab the entire line
            cout << endl;                                                           //skip line for output
            if(area[cartSize].length() > 0 && area[cartSize].length() <= 200){      //check input is withing size constraint for database
                break;                                                              //break and continue program
            }
            else{
                cout << "Invalid input. Entry has 200 character limit and cannot be empty." << endl;        //print error message
            }
        }//end while


//gather info on the symptoms being contagious
        cout << "How is the patient contagious?" << endl;
        cout << "Type input: ";
        cin.clear();                                                                            //clear the input

        while(loop){                                                                            //validate entry is within size and made of of letters
            getline(cin, contagious[cartSize]);                                                 //grab the entire line
            cout << endl;                                                                       //skip line for output
            if(contagious[cartSize].length() > 0 && contagious[cartSize].length() <= 200){      //check input is within size constraint for database
                break;                                                     //break and continue program
            }
            else{
                cout << "Invalid input. Entry has 200 character limit and cannot be empty." << endl;        //print error message
            }
        }//end while


        cout << "Does the patient have more symptoms to enter? (Y or N)" << endl;                     //Find if patient has any more symptoms
        cout << "Enter choice: ";
        while(loop){                                                                                  //validate yes or no input
            cin >> userInput;                                                                         //get input from user as string
            cout << endl;                                                                             //skip line for output
            if(userInput == "Y" || userInput == "y" || userInput == "N" || userInput == "n"){         //check input is yes or no and end
                break;
            }
            else{
                cout << "Invalid entry. Enter 'Y' for yes or 'N' for no." << endl;          //prompt user with error message
                cin.clear();                                                                //clear input
                cin.ignore(1000, '\n');                                                     //ignore the rest
            }
        }//end while


//if answer is no update tables with all the info gathered
        if(userInput == "N" || userInput == "n"){
            
            //query the database to get the row with the highest index to increment it and create a unique id number
            query = "SELECT symptom_id FROM symptom ORDER BY symptom_id DESC LIMIT 1;";         //query orders symptom table by symptom_id in a descending order. The limit 1 only returns the highest (most recent) index from table
            if((sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL)) != SQLITE_OK){        //check statement for any errors
                LastError = sqlite3_errmsg(db);                                                 //store error message from database
                sqlite3_finalize(result);                                                       //reset the statement result
                cout << "There was an error with selecting from Symptom table: " << LastError << endl;         //print error from database
                rollback(db);                                                                   //rollback database to error free state
                return;                                                                         //return to main
            }
            sqlite3_reset(result);                                                              //reset statement to beginning state
            sqlite3_step(result);                                                               //step to the row with the id number
            ID = sqlite3_column_int(result, 0);                                                 //set the value from database to the variable ID
            ID++;                                                                               //increment the index of current ID by 1 to create a unique entry 
            sqlite3_finalize(result);                                                           //reset statement when done
            
            for(int j = 0; j <= cartSize; j++){                 //for loop to insert all entries
                //query to insert into symptom table
                query = "insert into symptom values(" + to_string(ID) + ", " + to_string(epiID) + ", '" + type[j] + "', '" + startDate[j] + "', ";
                    query += to_string(severity[j]) + ", '" + area[j] + "', '" + contagious[j] + "'); "; 
                if((sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL)) != SQLITE_OK){        //check statement for any errors
                    LastError = sqlite3_errmsg(db);                                                 //store error message from database
                    sqlite3_finalize(result);                                                       //reset the statement result
                    cout << "There was an error with inserting into Symptom table: " << LastError << endl;         //print error from database
                    rollback(db);                                                                   //rollback database to error free state
                    return;                                                                         //return to main
                }
                sqlite3_finalize(result);                                                   //reset result statement
                
                if(sqlite3_exec(db, query.c_str(), NULL, NULL, &err) != SQLITE_OK){                 //begin transaction
                    cout << "Error executing insert into Symptom: " << err << endl;                          //print error
                    sqlite3_free(err);                                                              //free up pointer
                    return;                                                                         //return to main
                }

                //cout << "Line 2203: " << query << endl;
                ID++;                                                           //increment ID by 1 for the next iteration
            }//end for

            commit(db);                                     //commit changes to database
            return;                                         //once done inserting multiple symptoms return to exposure case to finish entry
        }//end if

//if yes increase cart size by 1
        cartSize++;                                 //increase cartSize by 1 for the next symptom
    }//end while
}//end createSymptom


//function to create a new Chronic(s) attached to patients exposure case in database
void createChronic(sqlite3 *db, int epiID){
/*
****Chronic Condition****
Chronin_ID                      int                         (Primary Key)
Epi_ID                          int                         (Foreign Key)
Chronic_Condition               varchar(100) NOT NULL
Start_Of_Condition              char(8) NOT NULL
Condition_Severity              int NOT NULL
Condition_Effected_Area         varchar(100) NOT NULL
*/
    int ID, severity[10], cartSize = 0;                               //store users input to insert into database for each chronic condition
    string condition[10], area[10], startDate[8];                     //store users input to insert into database for each chronic condition
    string userInput;                                                 //used for user input
    string query;                                                     //used to query database
    int i = 1, choice;                                                //used for loop and validation input
    bool loop = true;                                                 //used to initiate each while loop, break statement will exit
    string LastError;                                                 //used to report error from database
    sqlite3_stmt *result;                                             //used to store results of query on database
    char *err;

    query = "begin transaction;";                                                       //attempt to create a new save point for the database if things go wrong
    if(sqlite3_exec(db, query.c_str(), NULL, NULL, &err) != SQLITE_OK){                 //begin transaction
        cout << "Error starting transaction: " << err << endl;                          //print error
        sqlite3_free(err);                                                              //free up pointer
        return;                                                                         //return to main
    }

    while(loop){                                                            //loop to input multiple symptoms
//gather the patients chronic health condition
        cout << "What pre-existing health condition does the patient have? (Ex: Liver disease from birth, Diagnosed with diabetes in 2012)" << endl;
        cout << "Enter condition: ";
        cin.clear();                                                            //clear input from called function
        cin.ignore(1000, '\n');                                                 //ignore the anything left
        while(loop){                                                            //validate input from user
            getline(cin, condition[cartSize]);                                  //grab the entire line
            cout << endl;                                                       //skip line for output
            if(condition[cartSize].length() > 0 && condition[cartSize].length() <= 200){  //check input is within size constraint for database
                break;                             //break and continue with program
            }
            else{
                cout << "Invalid Input. Entry has character limit of 200 and cannot be empty." << endl;     //print error message
                cin.clear();                                                                                //clear input
            }
        }//end while


//gather the approximate start date of condition
        cout << "Enter the estimated start date of the patients health condition. No hyphens, dashes, or slashes. (Ex: MMDDYYYY)" << endl;
        cout << "Enter Date: ";
        while(loop){                                                  //validate user input
            cin >> startDate[cartSize];                                             //gather health conditions start date from user
            cout << endl;                                                           //skip line for output
            if(startDate[cartSize].length() == 8){                                  //check entry is proper length
                if(isDate(startDate[cartSize])){                                    //use isDate function to validate the entry is a correct date
                    break;                                                          //break loop and continue program
                }
                else{
                    cout << "Invalide input. Input out of range. (Month: 01-12   Day: 01-31   Year: 1900-2999)" << endl;     //print error message
                    cin.clear();                                                                        //clear input
                    cin.ignore(1000, '\n');                                                             //ignore anything left
                }
            }
            else{
                cout << "Invalid input. Try again." << endl;                                            //print error message
                cin.clear();                                                                            //clear input
                cin.ignore(1000,'\n');                                                                  //ignore anything left
            }
        }//end while


//gather severity level of chronic health condition
        cout << "How severe is the condition on the patient, level of pain or effect on life? Enter 1 for low or 10 for high. (Ex: 6)" << endl;
        cout << "Enter severity: ";
        cin.clear();                                                //clear input

        while(loop){                                                        //validate number entered is in fact a number within range
            cin >> userInput;                                               //user enters a string for the int
            cout << endl;                                                   //skip line for output
            if(isDigit(userInput)){                                         //string is checked character by character to check each a number
                severity[cartSize] = stoi(userInput);                       //convert from string to int
                if(severity[cartSize] > 0 && severity[cartSize] <= 10){     //checks int is 1 - 10
                    break;                                                  //break loop and continue program
                }
                else{
                    cout << "Invalid entry. Enter a number 1 - 10. One is low, ten is high." << endl;       //print error message
                }
            }
            else{
                cout << "Invalid Input. No special characters or numbers." << endl;           //print error message
                cin.clear();                                                                  //clear input
                cin.ignore(1000, '\n');                                                       //ignore anything left
            }
        }//end while


//gather general info on the effected area of the health condition
        cout << "What is the main affected region of the patients health condition?" << endl;
        cout << "(Ex: Liver, bile ducts, and esophagus from over production of bile. Patient is also immunocompromised from medications.)" << endl;
        cout << "Type input: ";
        cin.clear();                                                                //clear the input
        cin.ignore(1000, '\n');                                                     //ignore anything left
        while(loop){                                                                //validate entry is within size and made of of letters
            getline(cin, area[cartSize]);                                           //grab the entire line
            cout << endl;                                                           //skip line for output
            if(area[cartSize].length() > 0 && area[cartSize].length() <= 200){      //check input is withing size constraint for database
                    break;                                                          //break and continue program
            }
            else{
                cout << "Invalid Input. Entry has character limit of 200 and cannot be empty." << endl;     //print error message to user
                cin.clear();                                               //clear input
            }
        }//end while


//input multiple conditions if or end loop
        cout << "Does the patient have more health conditions to enter not yet covered? (Y or N)" << endl;      //Find if patient has any more health conditions
        cout << "Enter choice: ";
        while(loop){                                                                                  //validate yes or no input
            cin >> userInput;                                                                         //get input from user as string
            cout << endl;                                                                             //skip line for output
            if(userInput == "Y" || userInput == "y" || userInput == "N" || userInput == "n"){         //check input is yes or no and end
                break;
            }
            else{
                cout << "Invalid entry. Enter 'Y' for yes or 'N' for no." << endl;          //prompt user with error message
                cin.clear();                                                                //clear input
                cin.ignore(1000, '\n');                                                     //ignore the rest
            }
        }//end while


//if answer is no update tables with all the info gathered
        if(userInput == "N" || userInput == "n"){
            
            //query the database to get the row with the highest index to increment it and create a unique id number
            query = "SELECT chronic_id FROM chronic_health_condition ORDER BY chronic_id DESC LIMIT 1;";         //query orders Chronic_Condition table by chronic_id in a descending order. The limit 1 only returns the highest (most recent) index from table
            if((sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL)) != SQLITE_OK){        //check statement for any errors
                LastError = sqlite3_errmsg(db);                                                 //store error message from database
                sqlite3_finalize(result);                                                       //reset the statement result
                cout << "There was an error with selecting from Chronic Health Condition table: " << LastError << endl;         //print error from database
                rollback(db);                                                                   //rollback database to error free state
                return;                                                                         //return to main
            }
            
            sqlite3_reset(result);                                                              //reset statement to beginning state
            sqlite3_step(result);                                                               //step to the row with the id number
            ID = sqlite3_column_int(result, 0);                                                 //set the value from database to the variable ID
            ID++;                                                                               //increment the index of current ID by 1 to create a unique entry 
            sqlite3_finalize(result);                                                           //reset statement when done
            
            for(int j = 0; j <= cartSize; j++){                 //for loop to insert all entries
            
                //query to insert into Chronic Health Condtion table
                query = "insert into Chronic_Health_Condition values(" + to_string(ID) + ", " + to_string(epiID) + ", '" + condition[j] + "', '";
                    query += startDate[j] + "', " + to_string(severity[j]) + ", '" + area[j] + "'); "; 
                if((sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL)) != SQLITE_OK){        //check statement for any errors
                    LastError = sqlite3_errmsg(db);                                                 //store error message from database
                    sqlite3_finalize(result);                                                       //reset the statement result
                    cout << "There was an error with inserting into Chronic Health Condition table: " << LastError << endl;         //print error from database
                    rollback(db);                                                                   //rollback database to error free state
                    return;                                                                         //return to main
                }
                sqlite3_finalize(result);                                                   //reset result statement

                if(sqlite3_exec(db, query.c_str(), NULL, NULL, &err) != SQLITE_OK){             //begin transaction
                    cout << "Error executing insert into Chronic Health Condition: " << err << endl;       //print error
                    sqlite3_free(err);                                                              //free up pointer
                    return;                                                                         //return to main
                }

                //cout << "Line 2388: " << query << endl;
                ID++;                                                           //increment ID by 1 for the next iteration
            }//end for

            commit(db);                                     //commit changes to database
            return;                                         //once done inserting multiple health conditions return to exposure case to finish entry
        }//end if

//if yes increase cart size by 1
        cartSize++;                                 //increase cartSize by 1 for the next health condition
    }//end while
}//end createChronic


//function to create a new Exposure case
void createEpi(sqlite3 *db){
/*
**Epi Table**
Epi_ID                          int                         (Primary Key)
Patient_ID                      int                         (Foreign Key)
Housing                         varchar(20) NOT NULL
Pet_ID                          int                         (Foreign Key)
Household_Size                  int NOT NULL
Water_Source                    char(4) NOT NULL
Water_Contact                   varchar(100) NOT NULL
Sexual_Activity                 varchar(100) NOT NULL
Animal_Contact                  varchar(100) NOT NULL
Investigator_ID                 int                         (Foreign Key)
Travel                          varchar(100) NOT NULL
Note                            varchar(500) NOT NULL
Investigation_Date              char(8) NOT NULL
Start_Of_Pathogen               char(8) NOT NULL
Pathogen_ID                     int                         (Foreign Key)
*/
    int epiID, patientID, petID, investigatorID, pathogenID;                                                                    //used for storing primary key, foreign keys for table or from other tables
    int householdSize;                                                                                                          //used for storing user data for insertion
    string housing, waterSource, waterContact, sexualActivity, animalContact, travel, note, investigationDate, pathogenDate;    //used for storing user data for insertion
    string userInput, temp, Fname, Lname;                                                                                       //used for user input
    string query;                                                                                                               //used to query database
    int i = 1, choice;                                                                                                          //used for loop and validation input
    bool loop = true;                                                                                                           //used to initiate each while loop, break statement will exit
    string LastError;                                                                                                           //used to report error from database
    sqlite3_stmt *result;                                                                                                       //used to store results of query on database
    char *err;
    
    query = "begin transaction;";                                                       //attempt to create a new save point for the database if things go wrong
    if(sqlite3_exec(db, query.c_str(), NULL, NULL, &err) != SQLITE_OK){                 //begin transaction
        cout << "Error starting transaction: " << err << endl;                          //print error
        sqlite3_free(err);                                                              //free up pointer
        return;                                                                         //return to main
    }//end if


    cout << "To create an exposure case we need to find the patient first or create a new patient if it does not exist." << endl;
    cout << "Remember searches are case sensitive." << endl;
    cout << "Please enter the first name of the patient:" << endl;
    cout << "Enter name: ";
    cin.clear();                                                                //clear input
    cin.ignore(1000, '\n');                                                     //ignore anything left

    while(loop){                                                                //validate first name of patient
        getline(cin, Fname);                                                    //getline incase patient name may be multiple parts
        cout << endl;
        if(Fname.length() > 0 && Fname.length() <= 50){
            if(isWord(Fname)) {                                                     //find if string is made up of the alphabet and return boolean 
                break;                                                              //break loop and continue program
            }
            else {                                                                                                                      
                cout << "Please only enter letters from the alphabet for first name. Entry is case sensitive." << endl;     //print error message
            }
        }
        else{
            cout << "Invalid input. Entry has character limit of 50 and cannot be empty." << endl;
        }
    }//end while
            
    cout << "Please enter the last name of the patient:" << endl;
    cout << "Enter name: ";
    while(loop) {                                                       //validate input of patient last name
        getline(cin, Lname);                                            //getline incase patient name may be multiple parts
        cout << endl;                                                   //skip line for output
        if(Lname.length() > 0 && Lname.length() <= 50){
            if(isWord(Lname)) {                                     //if string is made up of the alphabet then break; to end loop
                break;                                              //break loop and continue program
            }
            else {
                cout << "Please only enter letter from the alphabet for last name. Entry is case sensitive." << endl;   //print error message
            }
        }
        else{
            cout << "Invalid input. Entry has a character limit of 50 and cannot be empty." << endl;
        }
    }//end while

    query = "select * from patient where Patient.First_Name = '" + Fname + "' and Patient.Last_Name = '" + Lname + "';";
    if(sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL) != SQLITE_OK) {         //prepare statement and make sure no errors occur
		LastError = sqlite3_errmsg(db);                                                 //print error message from database
		sqlite3_finalize(result);                                                       //clear result
		cout << "There was an error: " << LastError << endl;                            //print error
		rollback(db);                                                                   //rollback database to previous state before error
		return;                                                                         //return to main
	}
    sqlite3_step(result);

    if(sqlite3_column_text(result, 0) == NULL){                     //if patient id returns null patient does not exist within database, prompt to create patient
        cout << "Patient(s) could not be found in database. Check entry or create new patient." << endl << endl;
        sqlite3_finalize(result);                                                       //clear result
        rollback(db);                                                                   //rollback database to previous state before error
        return;                                                                         //return to main
    }
    sqlite3_reset(result);                                                              //reset result to beginning to iterate through results 
    i = 1;                                                                              //set i to 1 for output
    cout << "****Patient(s) Information****" << endl;
    while (sqlite3_step(result) == SQLITE_ROW){                     //Print patient first and last name with date of birth for user to choose from to see more info
        cout << i << ". " << sqlite3_column_text(result, 1) << " ";                     //print the current count and the first name from table
        if(sqlite3_column_text(result, 2) != NULL){                                     //make sure middle initial is not null
            cout << sqlite3_column_text(result, 2) << ". ";                             //print middle initial if not null
        }
        cout << sqlite3_column_text(result, 3);                                         //print patient last name from database
        cout << " - DOB: ";
        temp = reinterpret_cast<const char*>(sqlite3_column_text(result, 4));           //cast dob of birth to string variable to split for proper output
        cout << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7];     //split date by MM-DD-YYYY
        cout << endl;
        i++;                                                                            //increment i by 1
    }//end while
    cout << endl;

    cout << "Choose patient from list or enter -1 to cancel search and return to main menu." << endl;
    cout << "Enter choice: ";
    cin >> choice;                                                                      //user inputs an int
    cout << endl;                                                                       //skip line for output

    while(!cin || choice < 1 || choice >= i){                                            //validate choice was within the proper range of the output
        if(choice == -1){                                                                   //if user enters -1 return to main
            rollback(db);                                                                   //rollback since cancelling
            return;                                                                         //return to main
        }
        if (!cin){                                                                      //if unexepected inputs clear input
            cin.clear();
            cin.ignore(1000, '\n');
        }
        cout << "That is not a valid patient! Try again!" << endl;                      //prompt user of error and allow reentry
        cin >> choice;
        cout << endl;                                                                   //skip line
    }//end while

    sqlite3_reset(result);                                                              //reset result statement to the beginning
    for (int j = 0; j < choice; j++){                                                   //loop runs to the patient chosen by user
        sqlite3_step(result);                                                           //and sets result to that patient row
    }

    if(sqlite3_column_text(result, 13) != NULL){                                         //print message to inform user of how database is handling dublicate exposures cases
        cout << "Patient already has an exposure case on file. Creating a new exposure case" << endl;   //patient file will hold the most recent exposure case
        cout << "will cause the newest case to be linked to their file." << endl;               //info still in database for integrity and research
        cout << "Older case is still stored in the database." << endl;                          //can be reached through edit menu (will update with functionality that uses it like pathogen searches)
    }

    patientID = sqlite3_column_int(result, 0);                                          //patientID stores the patients ID from database
    sqlite3_finalize(result);                                                           //clear result statement for reuse 


//gather Housing Information 20
    cout << "Enter the housing situation of the patient? (Ex: Lives in car, Own home, Rent apartment)" << endl;
    cout << "Type input: ";
    cin.clear();                                                            //clear input
    cin.ignore(1000, '\n');                                                 //ignore anything left

    while(loop){                                                            //validation loop for user input
        getline(cin, housing);                                              //makes sure to grab the entire input
        cout << endl;                                                       //skip line for output
        if(isWord(housing)){                                                //check input is made up of letters and spaces no special characters
            if(housing.length() > 0 && housing.length() <= 20){             //check if input is within the size constraint of the database
                break;                                                               //break loop and continue program
            }
            else{
                cout << "Invalid Input. 20 character limit." << endl;                        //print error message with length limit
            }
        }
        else{
            cout << "Invalid Input. No special characters or numbers. Try again." << endl;        //prompt user with error and to try again
        }
    }//end while


//gather Household size int
    cout << "How many people live with the patient? (Ex: 5)" << endl;
    cout << "Enter choice: ";

    while(loop){                                                        //validate number of people living with patient is a number
        if(!cin){                                                       //clear input if error in input
            cin.clear();
            cin.ignore(1000, '\n');
        }
        cin >> userInput;                                               //user enter int using a string
        cout << endl;                                                   //skip line for output
        if(isDigit(userInput)){                                         //string is check character by character to check only 0-9
            householdSize = stoi(userInput);                            //convert string to int type
            if(householdSize >= 0){                                     //check not negative
                break;                                                  //break and continue program
            }
            else{
                cout << "Invalid Input. Number cannot be negative." << endl;    //print error message to user
                cin.clear();                                                    //clear input
                cin.ignore(1000, '\n');                                         //ignore anything left
            }
        }
        else{
            cout << "Invalid Input. Enter a number." << endl;           //print error message to user
            cin.clear();                                                //clear input
            cin.ignore(1000, '\n');                                     //ignore anything left
        }
    }//end while


//gather Water Source 4
    cout << "What is the patients water source? (1 or 2)" << endl;                      //prompt input for type of water source
    cout << "1. City" << endl;
    cout << "2. Well" << endl;
    cout << "Enter choice: ";

    while(loop){                                                                        //valid the user has chosen 1 or 2
        cin >> waterSource;                                                             //gather input for water source
        cout << endl;                                                                   //skip line for output
        if(waterSource == "1"){                                                         //check if input is 1
            waterSource = "City";                                                       //set water source to City
            break;                                                                      //break loop and continue program
        }
        else if(waterSource == "2"){                                                    //check if input is 2
            waterSource = "Well";                                                       //set water source to Well
            break;                                                                      //break loop and continue program
        }
        else{
            cout << "Invalid entry. Enter 1 for City or Enter 2 for Well." << endl;     //print error message
            cin.clear();                                                                //clear input
            cin.ignore(1000, '\n');                                                     //ignore anything left
        }
    }//end while


//gather Water Contact 100
    cout << "Has the patient had any recent water contact? (Ex: Fishers public swimming pool, Scummy Pond, Tap water from home)" << endl;
    cout << "Type input: ";
    cin.clear();                                                            //clear input
    cin.ignore(1000, '\n');                                                 //ignore the rest

    while(loop){                                                            //validate input is within size for database
        getline(cin, waterContact);                                         //grab the entire input
        cout << endl;                                                       //skip line for output
        if(waterContact.length() > 0 && waterContact.length() <= 100){      //input cannot be blank or over 100 characters
            break;                                                          //break loop continue program
        }
        else{
            cout << "Invalid input. Entry has a 100 character limit and cannot be empty." << endl;      //print error message
        }
    }//end while


//gather Sexual Activity 100
    cout << "Is the patient sexually active? (Ex: Currently active with multiple partners, Not Active)" << endl;
    cout << "Type input: ";
    while(loop){                                                                        //validation loop for user input
        getline(cin, sexualActivity);                                                   //gather the entire input line
        cout << endl;                                                                   //skip line for output
        if(sexualActivity.length() > 0 && sexualActivity.length() <= 100){              //check input is within size constraint for database
            break;                                                                      //break loop and continue program
        }
        else{
            cout << "Invalid input. Character limit of 100 for input and cannot be empty." << endl;         //print error message
        }
    }//end while


//gather Travel 100
    cout << "Has the patient travelled anywhere in the past 3 months? (Ex: Recently took a trip to South America)" << endl;
    cout << "Type input: ";

    while(loop){                                                                       //validation loop 
        getline(cin, travel);                                                          //take the entire input line
        cout << endl;                                                                  //skip line for output
        if(travel.length() > 0 && travel.length() <= 100){                             //check input is within size constraint for database
            break;                                                                     //break loop and continue the program
        }
        else{
            cout << "Invalid input. Character limit of 100 for input." << endl;             //print error message
        }
    }//end while


//gather Pathogen ID int
    query = "select * from pathogen";
    if((sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL)) != SQLITE_OK){             //check for errors with query
        LastError = sqlite3_errmsg(db);                                                      //store the error message from database
        sqlite3_finalize(result);                                                            //reset the result statment
        cout << "There was an error with selecting from Pathogen table: " << LastError << endl;              //print error message
        rollback(db);                                                                        //rollback database to previous state
        return;                                                                              //return to main program
    }

    sqlite3_reset(result);                                                                   //reset results to beginning
    i = 1;                                                                                   //set i to 1 for output in loop
    cout << "What pathogen has the patient contracted? If patient has not contracted a pathogen press -1 to cancel and return to main." << endl;
    while(sqlite3_step(result) == SQLITE_ROW){                                               //loop to print each row
        cout << i << ". Pathogen: " << sqlite3_column_text(result, 1) << "   |   Severity: " << sqlite3_column_text(result, 2) << endl;
        i++;
    }//end while to print pathogen list

    cout << "Enter choice: ";
    while(loop){                                                //validate users input is an investigator
        cin >> userInput;                                       //user enters using a string
        cout << endl;                                           //skip line for output
        if(userInput == "-1"){                                                                  //check if user enter -1
            cout << "No pathogen no exposure case, returning to main menu..." << endl;          //print message of cancelation
            cin.clear();                                                                        //clear input
            cin.ignore(1000, '\n');                                                             //ignore anything left
            rollback(db);                                                                       //rollback database to previous state
            return;                                                                             //return to main program
        }
        if(isDigit(userInput)){                                 //isDigit checks one character at a time for it to be a digit
            choice = stoi(userInput);                           //convert string to int
            if(choice >= 1 && choice < i){                       //check int falls within constraints
                break;                                          //break loop to continue program
            }
            else{   
                cout << "Invalid entry. Enter number between 1 and " << i - 1 << "." << endl;   //print error message
                cin.clear();                                                                //clear input
                cin.ignore(1000, '\n');                                                     //clear anything left
            }
        }
        else{
            cout << "Invalid input. Enter the number representing the desired pathogen." << endl;             //print error message
            cin.clear();                                                                    //clear input
            cin.ignore(1000, '\n');                                                         //clear anything left
        }
    }//end while

    sqlite3_reset(result);                                                                  //reset statement to beginning of results
    for(int j = 0; j < choice; j++){                                                        //loop progress statement to the correct investigator
        sqlite3_step(result);                                                               //move to next row from query        
    }//end for

    pathogenID = sqlite3_column_int(result, 0);                                         //set investigatorID to the current investigator_ID from database    
    sqlite3_finalize(result);                                                              //reset result
    

//gather Start Of Pathogen 8
    cout << "Enter the estimated start date of the pathogen. No hyphens, dashes, or slashes. (Ex: MMDDYYYY)" << endl;
    cout << "Enter Date: ";

    while(loop){                                                                //validate user input
        cin >> pathogenDate;                                                    //gather pathogen date from user
        cout << endl;                                                           //skip line for output
        if(pathogenDate.length() == 8){                                         //check entry is proper length
            if(isDate(pathogenDate)){                                           //use isDate function to validate the entry is a correct date
                break;                                                          //break loop and continue program
            }
            else{
                cout << "Invalide input. Input out of range. (Month: 01-12   Day: 01-31   Year: 1900-2999)" << endl;     //print error message
                cin.clear();                                                                        //clear input
                cin.ignore(1000, '\n');                                                             //ignore anything left
            }
        }
        else{
            cout << "Invalid input. Try again." << endl;                                            //print error message
            cin.clear();                                                                            //clear input
            cin.ignore(1000,'\n');                                                                  //ignore anything left
        }
    }//end while


//gather Investigator ID int
    cout << "Pick your credentials from the line up so it can be saved to this case?" << endl;
    query = "select investigator_id, investigator_first_name, investigator_last_name, job_title from investigator;";
    if((sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL)) != SQLITE_OK){                    //check statement for anything errors
        LastError = sqlite3_errmsg(db);                                                             //store error message from database
        sqlite3_finalize(result);                                                                   //reset the statement result
        cout << "There was an error with selecting from Investigator table: " << LastError << endl;                     //print error from database
        rollback(db);                                                                               //rollback database to error free state
        return;                                                                                     //return to main
    }
    sqlite3_reset(result);                                                                          //reset results to beginning
    
    i = 1;
    while(sqlite3_step(result) == SQLITE_ROW){                                                      //loop to print each row
        cout << i << ". " << sqlite3_column_text(result, 1) << " " << sqlite3_column_text(result, 2) << "   |   " << sqlite3_column_text(result, 3) << endl;
        i++;
    }//end while to print investigator

    cout << "Enter choice: ";
    while(loop){                                                //validate users input is an investigator
        cin >> userInput;                                       //user enters using a string
        cout << endl;                                           //skip line for output
        if(isDigit(userInput)){                                 //isDigit checks one character at a time for it to be a digit
            choice = stoi(userInput);                           //convert string to int
            if(choice >= 1 && choice < i){                       //check int falls within constraints
                break;                                          //break loop to continue program
            }
            else{   
                cout << "Invalid entry. Enter number between 1 and " << i << "." << endl;   //print error message
                cin.clear();                                                                //clear input
                cin.ignore(1000, '\n');                                                     //clear anything left
            }
        }
        else{
            cout << "Invalid input. Enter the number representing your information." << endl;             //print error message
            cin.clear();                                                                    //clear input
            cin.ignore(1000, '\n');                                                         //clear anything left
        }
    }//end while

    sqlite3_reset(result);                                                                 //reset statement to beginning of results
    for(int j = 0; j < choice; j++){                                                       //loop progress statement to the correct investigator
        sqlite3_step(result);                                                                       
    }
    investigatorID = sqlite3_column_int(result, 0);                                        //set investigatorID to the current investigator_ID from database  
    sqlite3_finalize(result);                                                              //reset result


//gather Investigation Date 8
    cout << "Enter the date of the investigation. No hyphens, dashes, or slashes. (Ex: MMDDYYYY)" << endl;
    cout << "Enter Date: ";
    
    while(loop){                                                                                //validate input loop
        cin >> investigationDate;                                                               //gather the date
        cout << endl;                                                                           //skip line for output
        if(investigationDate.length() == 8){                                                    //checks it's length first
            if(isDate(investigationDate)){                                                      //use date function to check for correct format
                break;                                                                          //continue program once done with validation
            }
            else{
                cout << "Invalide input. Try again. (Month: 01-12    Day: 01-31    Year: 1999-2999)" << endl;   //print error message with example
                cin.clear();                                                                                    //clear input
                cin.ignore(1000, '\n');                                                                         //ignore anything left
            }
        }
        else{
            cout << "Invalid input. Try again." << endl;                                        //print error message
            cin.clear();                                                                        //clear input
            cin.ignore(1000,'\n');                                                              //ignore anything left
        }
    }//end while


//gather Animal Contact 100
    cout << "Has the patient had any exotic animal contact?";
    cout << "(Ex: Recently went to the zoo and pet some of the animals, Came into contact with possum and got scratched)" << endl;
    cout << "Type input: ";
    cin.clear();                                                                                //clear input from previous loop
    cin.ignore(1000, '\n');                                                                     //ignore anything left from previous loop

    while(loop){                                                                                //validate user input
        getline(cin, animalContact);                                                            //gather the entire line
        cout << endl;                                                                           //skip line for output
        if(animalContact.length() > 0 && animalContact.length() <= 100){                        //check it falls within size constraint for database
            break;                                                                              //continue program
        }
        else{
            cout << "Invalid input. Character limit of 100 for input or empty." << endl;        //print error message
            cin.clear();                                                                        //clear the input
        }
    }//end while


//since we made it this far, query the database to get the row with the highest index to increment it and create a unique id number
    query = "SELECT epi_id FROM Epi_Case ORDER BY epi_id DESC LIMIT 1;";                //query orders epi table by epi_id in a descending order. The limit 1 only returns the highest (most recent) index from table
    if((sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL)) != SQLITE_OK){        //check statement for anything errors
        LastError = sqlite3_errmsg(db);                                                 //store error message from database
        sqlite3_finalize(result);                                                       //reset the statement result
        cout << "There was an error with selecting from Epi Case table: " << LastError << endl;         //print error from database
        rollback(db);                                                                   //rollback database to error free state
        return;                                                                         //return to main
    }
    sqlite3_reset(result);                                                             //reset statement to beginning state
    sqlite3_step(result);                                                              //step to the row with the id number
    epiID = sqlite3_column_int(result, 0);                                             //set the value to the variable Patient_ID
    epiID++;                                                                           //increment the index by 1 to create a unique entry 
    sqlite3_finalize(result);                                                          //reset statement when done


//query to insert into epi case what is gathered so far. The only thing missing is the note attached and the pet ID which will be updated after if patient has pet, otherwise it's already null and move on to symptom and condition
    query = "insert into Epi_Case (Epi_ID, Patient_ID, Housing, Household_Size, Water_Source, Water_Contact, Sexual_Activity, ";
        query += "Animal_Contact, Investigator_ID, Travel, Note, Investigation_Date, Start_Of_Pathogen, Pathogen_ID) values (";
        query += to_string(epiID) + ", " + to_string(patientID) + ", '" + housing + "', " + to_string(householdSize) + ", '";
        query += waterSource + "', '" + waterContact + "', '" + sexualActivity + "', '" + animalContact + "', ";
        query += to_string(investigatorID) + ", '" + travel + "', 'NULL', '" + investigationDate + "', '" + pathogenDate + "', ";
        query += to_string(pathogenID) + ");";

    if(sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL) != SQLITE_OK) {     //check query for errors
		LastError = sqlite3_errmsg(db);                                             //store error message from database
		sqlite3_finalize(result);                                                   //reset the statement result
		cout << "There was an error inserting into Epi Case table " << LastError << endl;                        //print the error
		rollback(db);                                                               //rollback database to error free state
		return;                                                                     //return to main menu
	}
    
    if(sqlite3_exec(db, query.c_str(), NULL, NULL, &err) != SQLITE_OK){                 //execute if no errors
        cout << "Error executing insert into Epi Case: " << err << endl;                     //print error
        sqlite3_free(err);                                                              //free up pointer
        return;                                                                         //return to main
    }
    commit(db);                              //commit changes in database with everything collected so far  


//gather Pet Information int
    cout << "Does the patient have any pets? (Y or N)" << endl;                         //Find if patient has any pets
    cout << "Enter choice: ";

    while(loop){                                                                        //validate yes or no input
        cin >> userInput;                                                               //get input from user as string
        cout << endl;                                                                   //skip line for output
        if(userInput == "N" || userInput == "n"){                                       //if patient has no pets
            break;
        }
        else if(userInput == "Y" || userInput == "y"){                                  //check input is yes or no and end
            createPet(db, epiID);                                                       //insert into pets table
            break;                                                                      //break loop and continue program
        }
        else{
            cout << "Invalid entry. Enter 'Y' for yes or 'N' for no." << endl;          //prompt user with error message
            cin.clear();                                                                //clear input
            cin.ignore(1000, '\n');                                                     //ignore the rest
        }
    }//end while


//gather if Symptom
    //call function to  create symptom (send the database, send the epi id of current case)
    cout << "Does the patient have any symptoms from the pathogen? (Y or N)" << endl;                         //Find if patient has any symptom
    cout << "Enter choice: ";

    while(loop){                                                                                              //validate yes or no input
        cin >> userInput;                                                                                     //get input from user as string
        cout << endl;                                                                   //skip line for output
        if(userInput == "N" || userInput == "n"){                                       //if patient has no symptoms
            break;
        }
        else if(userInput == "Y" || userInput == "y"){          //check input is yes or no and end
            createSymptom(db, epiID);
            break;
        }
        else{
            cout << "Invalid entry. Enter 'Y' for yes or 'N' for no." << endl;          //prompt user with error message
            cin.clear();                                                                //clear input
            cin.ignore(1000, '\n');                                                     //ignore the rest
        }
    }//end while


//gather if chronic health condition
    //call function to create chronic health condition (send the database, send epi id of current case) 
    cout << "Does the patient have an existing health condition? (Y or N)" << endl;                      //Find if patient has any conditions
    cout << "Enter choice: ";

    while(loop){                                                                                         //validate yes or no input
        cin >> userInput;                                                                                //get input from user as string
        cout << endl;                                                                   //skip line for output
        if(userInput == "N" || userInput == "n"){                                       //if patient has no chronic illness
            break;
        }
        if(userInput == "Y" || userInput == "y"){                                    //check input is yes or no and end
            createChronic(db, epiID);                                                //call function to insert into Health Conditions table
            break;                                                                   //continue program when done
        }
        else{
            cout << "Invalid entry. Enter 'Y' for yes or 'N' for no." << endl;          //print error message
            cin.clear();                                                                //clear input
            cin.ignore(1000, '\n');                                                     //ignore the rest
        }
    }//end while

    query = "begin transaction;";                                                       //attempt to create a new save point for the database if things go wrong
    if(sqlite3_exec(db, query.c_str(), NULL, NULL, &err) != SQLITE_OK){                 //begin transaction
        cout << "Error starting transaction: " << err << endl;                          //print error
        sqlite3_free(err);                                                              //free up pointer
        return;                                                                         //return to main
    }

//Update epi case with note at very end
//gather Note 500
    cout << "Enter any notes you have about the case. 500 character limit." << endl;
    cout << "Type input: ";
    cin.clear();                                                                        //clear input
    cin.ignore(1000, '\n');                                                             //ignore the rest

    while(loop){                                                                        //validate input
        getline(cin, note);                                                             //gather entire line
        cout << endl;                                                                   //skip line for output
        if(note.length() > 0 && note.length() <= 500){                                  //check note fits within size constraint for database
            break;                                                                      //break loop continue program
        }
        else{
            cout << "Invalid input. Character limit of 500 for the input." << endl;         //print error message
            cin.clear();                                                                    //clear input
        }
    }//end while

	query = "update Epi_Case set note = '" + note + "' where epi_id = " + to_string(epiID) + ";";   //query to update epi_case for patient with note
	if(sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL) != SQLITE_OK) {         //check for errors with query
		LastError = sqlite3_errmsg(db);                                                 //store error message from database
		sqlite3_finalize(result);                                                       //reset statement
		cout << "There was an error updating Epi Case " << LastError << endl;                            //print error message
		rollback(db);                                                                   //rollback databaset to previous state
		return;                                                                         //return to main program
	}
    sqlite3_finalize(result);                                                           //reset result statement

    if(sqlite3_exec(db, query.c_str(), NULL, NULL, &err) != SQLITE_OK){                 //begin transaction
        cout << "Error executing update into Epi Case: " << err << endl;                             //print error
        sqlite3_free(err);                                                              //free up pointer
        return;                                                                         //return to main
    }

    //cout << "query line 2999: " << query << endl;                                     //delete when done
    cout << "Patient's exposure case has been inserted successfully." << endl << endl;

//update patient epi_id with newly created epi case
    query = "update patient set epi_id = " + to_string(epiID) + " where patient_id = " + to_string(patientID) + ";";        //link epi case to patient file
    if(sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL) != SQLITE_OK) {         //check for errors with query
		LastError = sqlite3_errmsg(db);                                                 //store error message from database
		sqlite3_finalize(result);                                                       //reset statement
		cout << "There was an error updating Patient Epi ID " << LastError << endl;     //print error message
		rollback(db);                                                                   //rollback databaset to previous state
		return;                                                                         //return to main program
	}
    sqlite3_finalize(result);                                                           //reset result

    if(sqlite3_exec(db, query.c_str(), NULL, NULL, &err) != SQLITE_OK){                 //begin transaction
        cout << "Error executing update into Patient: " << err << endl;                 //print error
        sqlite3_free(err);                                                              //free up pointer
        return;                                                                         //return to main
    }

    commit(db);                                                                         //commit changes to database
    cout << "Patient has been linked to newly created case." << endl << endl;       //extra endl for output 
}//end createEpi


//function to print menu for edit Patient
void editPatientMenu(){
    cout << "**************  MENU  **************" << endl;
    cout << "Which patient field would you like to edit?" << endl;
    cout << "1. First Name" << endl;
    cout << "2. Middle Initial" << endl;
    cout << "3. Last Name" << endl;
    cout << "4. DOB" << endl;
    cout << "5. Address" << endl;
    cout << "6. County" << endl;
    cout << "7. Gender" << endl;
    cout << "8. Marital Status" << endl;
    cout << "9. Ethnicity" << endl;
    cout << "10. Nationality" << endl;
    cout << "11. Phone Number" << endl;
    cout << "12. Email" << endl;
}//end editPatientMenu


//function to edit a chosen patients info that is not a primary or foreign key
void editPatient(sqlite3 *db){
    /*
    Patient_ID                  int (Primary Key)
    First_Name                  varchar(50)
    Middle_Initial              char(1)
    Last_Name                   varchar(50)
    DOB                         varchar(8)
    Address                     varchar(50)
    County                      varchar(50)
    Gender                      varchar(50)
    Marital_Status              varchar(8)
    Ethnicity                   varchar(50)
    Nationality                 varchar(50)
    Phone                       char(10)
    Email                       varchar(50)
    Epi_ID                      int
    */
    char * err;                         //print error message
    string LastError;                   //to print error message from query
    sqlite3_stmt * result;             //results of sql statments
    string query;                       //string to query database
    string userInput;                   //string to get user input
    string fname, lname, dob, address, county, gender, maritalStatus, ethnicity, nationality, phone, email; //strings to store info from database or to update database
    int patientID;                      //int variable to house primary key of patient
    bool loop = true;                   //boolean for validation loops
    query = "begin transaction;";       //begin transaction with database
    string temp;                        //used for date manipulation
    int choice, choice2, i = 1;         //choice is used for selections, i is used for output in loops and some conditionals
    int count = 0;                                                                      //variable only used in loop for iteration count
    int rc;                             
//begin transaction
    if(sqlite3_exec(db, query.c_str(), NULL, NULL, &err) != SQLITE_OK){
        cout << "Error starting transaction: " << err << endl;
        sqlite3_free(err);
        return;
    }

//find if user wants to search by id or name
    cout << "Do you want to pick from the list of patients or by the First and Last name? (Enter: 1 or 2)" << endl;
    cout << "1. Find patient from list" << endl;
    cout << "2. Find patient by First and Last name" << endl;
    cout << "Enter choice: ";

    while(loop){                                        //validate input loop
        cin >> userInput;                               //gather user input
        cout << endl;                                   //skip line for output
        if(isDigit(userInput)){                         //check string input is a number
            choice = stoi(userInput);                   //convert string to int value
            if(choice == 1 || choice == 2){             //check number is 1 or 2
                break;                                  //break loop and continue with program
            }
            else{
                cout << "Invalid input. Entry must be 1 or 2." << endl;     //print error
                cin.clear();                                                //clear input
                cin.ignore(1000, '\n');                                     //ignore anything left
            }
        }
        else{
            cout << "Invalid input. Entry must be a number 1 or 2" << endl;         //print error message
            cin.clear();                //clear input
            cin.ignore(1000, '\n');     //ignore anything left
        }
    }//end while

//if choice is 1
    if(choice == 1){
        query = "select * from patient";                    //set query to get everything from patient table
        if(sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL) != SQLITE_OK) {         //prepare statement and make sure no errors occur
            LastError = sqlite3_errmsg(db);                                                 //print error message from database
            sqlite3_finalize(result);                                                       //clear result
            cout << "There was an error selecting from Patient table: " << LastError << endl;                            //print error
            rollback(db);                                                                   //rollback database to previous state before error
            return;                                                                         //return to main
        }

        i = 1;                                                                              //set i to 1 for output
        cout << "****Patient(s) Information****" << endl;
        while (sqlite3_step(result) == SQLITE_ROW){                     //Print patient first and last name with date of birth for user to choose from to see more info
            cout << i << ". " << sqlite3_column_text(result, 1) << " ";                     //print the current count and the first name from table
            if(sqlite3_column_text(result, 2) != NULL){                                     //make sure middle initial is not null
                cout << sqlite3_column_text(result, 2) << ". ";                             //print middle initial if not null
            }
            cout << sqlite3_column_text(result, 3);                                         //print patient last name from database
            cout << " - DOB: ";
            temp = reinterpret_cast<const char*>(sqlite3_column_text(result, 4));           //cast dob of birth to string variable to split for proper output
            cout << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7];     //split date by MM-DD-YYYY
            cout << endl;
            i++;                                                                            //increment i by 1
        }//end while
        cout << endl;

        cout << "Choose patient from list or enter -1 to cancel search and return to main menu." << endl;
        cout << "Enter choice: ";
        cin >> choice2;                                                                      //user inputs an int
        cout << endl;                                                                        //skip line for output

        while(!cin || choice2 < 1 || choice2 >= i){                                            //validate choice was within the proper range of the output
            if(choice2 == -1){                                                                   //if user enters -1 return to main
                rollback(db);                                                                   //rollback since cancelling
                return;                                                                         //return to main
            }
            if (!cin){                                                                      //if unexepected inputs clear input
                cin.clear();
                cin.ignore(1000, '\n');
            }
            cout << "That is not a valid patient! Try again!" << endl;                      //prompt user of error and allow reentry
            cin >> choice2;
            cout << endl;                                                                   //skip line for output
        }

        sqlite3_reset(result);                                                              //reset result statement to the beginning
        for (int j = 0; j < choice2; j++){                                                   //loop runs to the patient chosen by user
            sqlite3_step(result);                                                           //and sets result to that patient row
        }

        patientID = sqlite3_column_int(result, 0);                                          //patientID stores the patients ID from database
        sqlite3_finalize(result);                                                           //clear result statement for reuse
    }//end if (choice 1)


//if choice is 2
    if(choice == 2){
        cout << "Remember searches are case sensitive." << endl;
        cout << "Please enter the first name of the patient." << endl;
        cout << "Enter name: ";
        cin.clear();                                                                //clear input
        cin.ignore(1000, '\n');                                                     //ignore anything left
        
        while(loop){                                                                //validate first name of patient
            getline(cin, fname);                                                    //getline incase patient name may be multiple parts
            cout << endl;
            if(fname.length() > 0 && fname.length() <= 50){
                if(isWord(fname)) {                                                     //find if string is made up of the alphabet and return boolean 
                    break;                                                              //break loop and continue program
                }
                else {                                                                                                                      
                    cout << "Please only enter letters from the alphabet for first name. Entry is case sensitive." << endl;     //print error message
                }
            }
            else{
                cout << "Invalid input. Entry has a character limit of 50 and cannot be empty." << endl;
            }
        }//end while
                
        cout << "Please enter the last name of the patient:" << endl;
        cout << "Enter name: ";
        while(loop) {                                                       //validate input of patient last name
            getline(cin, lname);                                            //getline incase patient name may be multiple parts
            cout << endl;                                                   //skip line for output
            if(lname.length() > 0 && lname.length() <= 50){
                if(isWord(lname)) {                                     //if string is made up of the alphabet then break; to end loop
                    break;                                              //break loop and continue program
                }
                else {
                    cout << "Please only enter letter from the alphabet for last name. Entry is case sensitive." << endl;   //print error message
                }
            }
            else{
                cout << "Invalid input. Entry has a character limit of 50 and cannot be empty." << endl;
            }    
        }//end while

        query = "select * from patient where Patient.First_Name = '" + fname + "' and Patient.Last_Name = '" + lname + "';";
        if(sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL) != SQLITE_OK) {         //prepare statement and make sure no errors occur
            LastError = sqlite3_errmsg(db);                                                 //print error message from database
            sqlite3_finalize(result);                                                       //clear result
            cout << "There was an error selecting from Patient table: " << LastError << endl;                            //print error
            rollback(db);                                                                   //rollback database to previous state before error
            return;                                                                         //return to main
        }

        sqlite3_step(result);
        if(sqlite3_column_text(result, 0) == NULL){                     //if patient id returns null patient does not exist within database, prompt to create patient
            cout << "Patient(s) could not be found in database. Check entry or create new patient." << endl << endl;
            sqlite3_finalize(result);                                                       //clear result
            rollback(db);                                                                   //rollback database to previous state before error
            return;                                                                         //return to main
        }
        sqlite3_reset(result);                                                              //reset result to beginning to iterate through results 
        
        i = 1;                                                                              //set i to 1 for output
        cout << "****Patient(s) Information****" << endl;
        while (sqlite3_step(result) == SQLITE_ROW){                     //Print patient first and last name with date of birth for user to choose from to see more info
            cout << i << ". " << sqlite3_column_text(result, 1) << " ";                     //print the current count and the first name from table
            if(sqlite3_column_text(result, 2) != NULL){                                     //make sure middle initial is not null
                cout << sqlite3_column_text(result, 2) << ". ";                             //print middle initial if not null
            }
            cout << sqlite3_column_text(result, 3);                                         //print patient last name from database
            cout << " - DOB: ";
            temp = reinterpret_cast<const char*>(sqlite3_column_text(result, 4));           //cast dob of birth to string variable to split for proper output
            cout << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7];     //split date by MM-DD-YYYY
            cout << endl;
            i++;                                                                            //increment i by 1
        }//end while
        cout << endl;

        cout << "Choose patient from list or enter -1 to cancel search and return to main menu." << endl;
        cout << "Enter choice: ";
        cin >> choice;                                                                      //user inputs an int
        cout << endl;                                                                       //skip line for output

        while(!cin || choice < 1 || choice >= i){                                            //validate choice was within the proper range of the output
            if(choice == -1){                                                                   //if user enters -1 return to main
            rollback(db);                                                                   //rollback since cancelling
            return;                                                                         //return to main
            }
            if (!cin){                                                                      //if unexepected inputs clear input
                cin.clear();
                cin.ignore(1000, '\n');
            }
            cout << "That is not a valid patient! Try again!" << endl;                      //prompt user of error and allow reentry
            cin >> choice;
            cout << endl;
        }

        sqlite3_reset(result);                                                              //reset result statement to the beginning
        for (int j = 0; j < choice; j++){                                                   //loop runs to the patient chosen by user
            sqlite3_step(result);                                                           //and sets result to that patient row
        }

        patientID = sqlite3_column_int(result, 0);                                          //patientID stores the patients ID from database
        sqlite3_finalize(result);                                                           //clear result statement for reuse
    }//end if (choice 2)
    

//What aspect of the patient info is under edit
    while(loop){
        if(userInput == "n" || userInput == "N"){       //condition to break loop and finish with editing
            break;
        }
        else{
            query = "select * from Patient where Patient_ID = " + to_string(patientID) + ";";             //query database each time to grab most recent information
            if((sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL)) != SQLITE_OK){        //check statement for anything errors
                LastError = sqlite3_errmsg(db);                                                 //store error message from database
                sqlite3_finalize(result);                                                       //reset the statement result
                cout << "There was an error with selecting from Patient table: " << LastError << endl;         //print error from database
                rollback(db);                                                                   //rollback database to error free state
                return;                                                                         //return to main
            } 
            sqlite3_reset(result);                                                              //reset statement
            sqlite3_step(result);                                                               //step to correct row
                    
            cout << endl;                               //skip line for output
            editPatientMenu();                  //print menu for editPatient
            cout << "Enter menu choice: ";

            while(loop){                                        //validate input loop
                cin >> userInput;                               //gather user input
                cout << endl;                                   //skip line for output
                if(isDigit(userInput)){                         //check string input is a number
                    choice = stoi(userInput);                   //convert string to int value
                    if(choice >= 1 && choice <= 12){             //check number is 1 - 12
                        break;                                  //break loop and continue with program
                    }
                    else{
                        cout << "Invalid input. Entry must be 1 thru 12." << endl;     //print error
                        cin.clear();                                                //clear input
                        cin.ignore(1000, '\n');                                     //ignore anything left
                    }
                }
                else{
                    cout << "Invalid input. Entry must be a number 1 thru 12" << endl;         //print error message
                    cin.clear();                //clear input
                    cin.ignore(1000, '\n');     //ignore anything left
                }
            }//end while

            if(count > 0){                                                                      //if not first iteration
                query = "begin transaction;";                                                   //attempt to create a new save point for the database if things go wrong
                if(sqlite3_exec(db, query.c_str(), NULL, NULL, &err) != SQLITE_OK){             //begin transaction
                cout << "Error starting transaction: " << err << endl;                          //print error
                sqlite3_free(err);                                                              //free up pointer
                return;                                                                         //return to main
                }
            }//end if
            count++;                        //increment count

            switch(choice){
    //edit First Name
                case 1:
                    cout << "Patients current first name in database is, " << sqlite3_column_text(result, 1) << endl;
                    cout << "Enter new name: ";
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore anything left
                    while(loop){                                                                //validate first name of patient
                        getline(cin, fname);                                                    //getline incase patient name may be multiple parts
                        cout << endl;
                        if(fname.length() > 0 && fname.length() <= 50){
                            if(isWord(fname)) {                                                     //find if string is made up of the alphabet and return boolean 
                                break;                                                              //break loop and continue program
                            }
                            else {                                                                                                                      
                                cout << "Please only enter letters from the alphabet for first name. Entry is case sensitive." << endl;     //print error message
                                cin.clear();                                                                                //clear input
                            }
                        }
                        else{
                            cout << "Invalid input. Entry has a character limit of 50 and cannot be empty." << endl;    //print error message
                            cin.clear();                                                                    //clear input
                        }    
                    }//end while
                    
                    query = "update Patient set First_Name = '" + fname + "' where Patient_ID = " + to_string(patientID);       //query with update to database
                    rc = sqlite3_exec(db, query.c_str(), NULL, &result, NULL);                                  //return a value if execution was successful or not
                    if(rc != SQLITE_OK) {                                                                       //compare rc to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating First Name: " << LastError << endl;                //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                     //print update
                    commit(db);                                                 //commit changes
                    cout << "First Name updated." << endl;                      //print success
                    sqlite3_finalize(result);                                   //reset result statement
                    break;                                                      //end case 1


    //edit Middle Initial
                case 2:
                    if (sqlite3_column_text(result, 2) != NULL) {                               // If middle initial is null don't try to print it
                        cout << "Patients current middle initial in database is, " << sqlite3_column_text(result, 2) << endl;
                    }
                    else{
                        cout << "Patients current middle initial in database is empty." << endl;        //print value as null
                    }
                    
                    cout << "Enter new middle initial. If empty enter -1." << endl;                     //prompt user for entry
                    cout << "Enter initial: ";

                    while (loop){                                                       //validate user input
                        cin >> userInput;                                               //gather user input as string
                        cout << endl;                                                   //skip line for output
                        if(userInput == "-1"){                                          //if input is -1 set userInput to NULL and break
                            userInput = "NULL"; 
                            break;
                        }
                        if(isWord(userInput)){                                          //if input is a letter
                            if(userInput.length() == 1 && userInput != " "){
                                //mname = userInput[0];
                                break;
                            }
                            else{
                                cout << "Initial can only be one character only." << endl;      //print error message
                                cin.clear();                                                    //clear input
                                cin.ignore(1000, '\n');                                         //ignore anything left
                            }
                        }
                        else{
                            cout << "Error with middle initial. Try again." << endl;            //print error message
                            cin.clear();                                                        //clear input
                            cin.ignore(1000, '\n');                                             //ignore anything left
                        }
                    }//end while

                    if(userInput == "NULL"){
                        query = "update Patient set Middle_Initial = '0' where Patient_ID = " + to_string(patientID);    //query with update if NULL
                    }
                    else{
                        query = "update Patient set Middle_Initial = '";
                            query += userInput + "' where Patient_ID = " + to_string(patientID);       //query with update if not NULL
                    }

                    if(sqlite3_exec(db, query.c_str(), NULL, &result, NULL) != SQLITE_OK) {                //compare returned value from exec to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                    //store error from database
                        sqlite3_finalize(result);                                                          //finalize results
                        cout << "There was an error updating Middle Initial: " << LastError << endl;       //print error message
                        rollback(db);                                                                      //rollback database
                        return;                                                                            //break loop and return to main menu
                    }

                    cout << "Updating....";                                                     //print update
                    commit(db);                                                                 //commit changes
                    cout << "Middle Initial updated." << endl;                                  //print success
                    sqlite3_finalize(result);                                                   //reset result
                    break;                                                                      //end case 2
                

    //edit Last Name
                case 3:
                    cout << "Patients current last name in database is, " << sqlite3_column_text(result, 3) << endl;
                    cout << "Enter new name: ";
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore anything left

                    while(loop){                                                                //validate first name of patient
                        getline(cin, lname);                                                    //getline incase patient name may be multiple parts
                        cout << endl;
                        if(lname.length() > 0 && lname.length() <= 50){
                            if(isWord(lname)) {                                                     //find if string is made up of the alphabet and return boolean 
                                break;                                                              //break loop and continue program
                            }
                            else {                                                                                                                      
                                cout << "Please only enter letters from the alphabet for last name. Entry is case sensitive." << endl;     //print error message
                                cin.clear();                                                                                                //clear input
                            }
                        }
                        else{
                            cout << "Invalid input. Entry has a character limit of 50 and cannot be empty." << endl;    //print error message
                            cin.clear();                                                                    //clear input
                        }    
                    }//end while

                    query = "update Patient set Last_Name = '" + lname + "' where Patient_ID = " + to_string(patientID);       //query with update to database
                    if(sqlite3_exec(db, query.c_str(), NULL, &result, NULL) != SQLITE_OK) {                     //compare exec to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating Last Name: " << LastError << endl;                 //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                             //print update
                    commit(db);                                                         //commit changes
                    cout << "Last Name updated." << endl;                               //print success
                    sqlite3_finalize(result);                                           //reset result
                    break;                                                              //end case 3
                

    //edit DOB
                case 4:
                    temp = reinterpret_cast<const char*>(sqlite3_column_text(result, 4));           //cast dob of birth to string variable to split for proper output
                    cout << "Patient's current Date Of Birth in database is: ";
                    cout << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7] << endl;     //split date by MM-DD-YYYY
                    cout << "Enter new DOB with no hyphens or slashes. EX: (MMDDYYYY) = (03051999)" << endl;
                    cout << "Enter DOB: ";
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore anything left
                    
                    while (loop) {       //validation loop for DOB before moving forward
                        cin >> dob;
                        cout << endl;
                        if(isDigit(dob)){       //function returns true if DOB is only made of values 0-9
                            if(dob.length() == 8){      //check that length is 8 char long before even checking if proper format
                                if(isDOB(dob)){     //function returns true if DOB entered meets the constraints
                                    break;
                                }
                                else{
                                    cout << "Entry was not in the proper order. EX: (MMDDYYYY) = (03051999)" << endl;   //print error message
                                    cin.clear();                                                                        //clear input
                                    cin.ignore(1000, '\n');                                                             //ignore anything left
                                }
                            }
                            else{
                                cout << "Entry was number but not the correct length for input. Please make sure entry is 8 digits long." << endl;      //print error message
                                cin.clear();                                                                            //clear input
                                cin.ignore(1000, '\n');                                                                 //ignore anything left
                            }
                        }//end if to validate dob
                        else{
                            cout << "Please only enter integer numbers for the date of birth." << endl;     //print error message
                            cin.clear();                                                                    //clear input
                            cin.ignore(1000, '\n');                                                         //ignore anything left
                        }//end else 
                    }//end while
                    
                    query = "update Patient set DOB = '" + dob + "' where Patient_ID = " + to_string(patientID);       //query with update to database
                    if(sqlite3_exec(db, query.c_str(), NULL, &result, NULL) != SQLITE_OK) {                     //compare exec to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating Date Of Birth: " << LastError << endl;             //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                         //print update
                    commit(db);                                                     //commit changes
                    cout << "Date Of Birth updated." << endl;                       //print success
                    sqlite3_finalize(result);                                       //reset result
                    break;                                                          //end case 4
                
    //edit Address
                case 5:
                    cout << "Patients current Address in database is, " << sqlite3_column_text(result, 5) << endl;
                    cout << "Enter new address: ";
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore anything left
                    
                    while(loop){
                        getline(cin, address);                                      //gather the entire line for the address
                        cout << endl;                               //skip line for output
                        if(isAddress(address)){                                     //check input fits constraints
                            if(address.length() >= 1 && address.length() <= 50){    //make sure size fits database constraint
                                break;                                              //break from loop continue program
                            }
                            else{
                                cout << "Invalid input. Entry has a character limit of 50 and cannot be empty." << endl;   //print error message
                                cin.clear();                                                //clear input
                            }
                        }
                        else{
                            cout << "Error with address. No comma's, periods, or special characters." << endl;  //print error message
                            cin.clear();                                                    //clear input
                        }
                    }//end while

                    query = "update Patient set Address = '" + address + "' where Patient_ID = " + to_string(patientID);       //query with update to database
                    if(sqlite3_exec(db, query.c_str(), NULL, &result, NULL) != SQLITE_OK) {                     //compare exec to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating Address: " << LastError << endl;                   //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                         //print update
                    commit(db);                                                     //commit changes
                    cout << "Address updated." << endl;                             //print success
                    sqlite3_finalize(result);                                       //reset result
                    break;                                                           //end case 5
                
                
    //edit County
                case 6:
                    cout << "Patients current County in database is, " << sqlite3_column_text(result, 6) << endl;
                    cout << "Enter new county: ";
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore anything left
                    
                    while(loop){                                                        //validate input
                        getline(cin, county);                                           //gather the entire line for multi word counties
                        cout << endl;                               //skip line for output
                        if(isWord(county)){                                             //check everything is made up of letters
                            if(county.length() >= 1 && county.length() <= 50){          //check size constraint for database
                                break;                                                  //break loop and continue program
                            }
                            else{
                                cout << "Invalid input. Entry has a character limit of 50 and cannot be empty." << endl;  //print error message
                                cin.clear();                                                            //clear input
                            }
                        }
                        else{
                            cout << "Error with county. Try again." << endl;                        //print error message
                            cin.clear();                                                            //clear input
                        }
                    }//end while

                    query = "update Patient set County = '" + county + "' where Patient_ID = " + to_string(patientID);       //query with update to database
                    if(sqlite3_exec(db, query.c_str(), NULL, &result, NULL) != SQLITE_OK) {                     //compare exec to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating County: " << LastError << endl;                    //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                         //print update
                    commit(db);                                                     //commit changes
                    cout << "County updated." << endl;                             //print success
                    sqlite3_finalize(result);                                       //reset result
                    break;                                                          //end case 6
                

    //edit Gender
                case 7:
                    cout << "Patients current Gender in database is, " << sqlite3_column_text(result, 7) << endl;
                    cout << "Enter new gender: ";
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore anything left
                    
                    while(loop){ 
                        getline(cin, gender);                                               //grab the entire line
                        cout << endl;                                                       //skip line for output
                        if(isWord(gender)){                                                 //check input is made of letters
                            if(gender.length() >= 1 && gender.length() <= 50){              //conditional to check size constraint for database
                                break;                                                      //break loop and continue program
                            }
                            else{
                                cout << "Invalid input. Entry has a character limit of 50 and cannot be empty." << endl;                    //print error message
                                cin.clear();                                                                //clear input
                            }
                        }
                        else{
                            cout << "Invalid entry. No comma's, periods, or special characters." << endl;   //print error message
                            cin.clear();                                                                    //clear input
                        }
                    }//end while                    
                    
                    query = "update Patient set Gender = '" + gender + "' where Patient_ID = " + to_string(patientID);       //query with update to database
                    if(sqlite3_exec(db, query.c_str(), NULL, &result, NULL) != SQLITE_OK) {                     //compare exec to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating Gender: " << LastError << endl;                    //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                         //print update
                    commit(db);                                                     //commit changes
                    cout << "Gender updated." << endl;                             //print success
                    sqlite3_finalize(result);                                       //reset result
                    break;                                                          //end case 7
                

    //edit Marital Status
                case 8:
                    cout << "Patients current Marital Status in database is, " << sqlite3_column_text(result, 8) << endl;
                    cout << "Enter new marital status: ";
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore anything left

                    while(loop){                                                                //validate user input
                        getline(cin, maritalStatus);                                            //grab entire line
                        cout << endl;                               //skip line for output
                        if(isWord(maritalStatus)){                                              //check input is made of letters
                            if(maritalStatus.length() >= 1 && maritalStatus.length() <= 8){         //check size constraint for database
                                break;                                             //break loop and continue program
                            }
                            else{
                                cout << "Invalid input. Entry has a character limit of 50 and cannot be empty." << endl;      //print error message
                                cin.clear();                                                                    //clear input
                            }
                        }
                        else{
                            cout << "Invalid entry. No comma's, periods, or special characters." << endl;       //print error message
                            cin.clear();                                                                    //clear input
                        }
                    }//end while                    

                    query = "update Patient set Marital_Status = '" + maritalStatus + "' where Patient_ID = " + to_string(patientID);       //query with update to database
                    if(sqlite3_exec(db, query.c_str(), NULL, &result, NULL) != SQLITE_OK) {                     //compare exec to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating Marital Status: " << LastError << endl;            //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                         //print update
                    commit(db);                                                     //commit changes
                    cout << "Marital Status updated." << endl;                      //print success
                    sqlite3_finalize(result);                                       //reset result
                    break;                                                          //end case 8
                

    //edit Ethnicity
                case 9:
                    cout << "Patients current Ethnicity in database is, " << sqlite3_column_text(result, 9) << endl;
                    cout << "Enter new ethnicity: ";
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore anything left
                    
                    while(loop){                                                                    //validate user input
                        getline(cin, ethnicity);                                                    //grab the entire line
                        cout << endl;                                   //skip line for output
                        if(isWord(ethnicity)){                                                      //check input is made of letters
                            if(ethnicity.length() >= 1 && ethnicity.length() <= 50){                //check size constraint for database
                                break;                                                              //break loop and continue program
                            }
                            else{
                                cout << "Invalid input. Entry has a character limit of 50 and cannot be empty." << endl;  //print error message
                                cin.clear();                                                                //clear input
                            }
                        }
                        else{
                            cout << "Invalid entry. No comma's, periods, or special characters." << endl;   //print error message
                            cin.clear();                                                                    //clear input
                        }
                    }//end while                

                    query = "update Patient set Ethnicity = '" + ethnicity + "' where Patient_ID = " + to_string(patientID);       //query with update to database
                    if(sqlite3_exec(db, query.c_str(), NULL, &result, NULL) != SQLITE_OK) {                                                                       //compare exec to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating Ethnicity: " << LastError << endl;                //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                         //print update
                    commit(db);                                                     //commit changes
                    cout << "Ethnicity updated." << endl;                           //print success
                    sqlite3_finalize(result);                                       //reset result
                    break;                                                          //end case 9
                

    //edit Nationality
                case 10:
                    cout << "Patients current Nationality in database is, " << sqlite3_column_text(result, 10) << endl;
                    cout << "Enter new nationality: ";
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore anything left
                    
                    while(loop){      
                        getline(cin, nationality);                                              //grab the entire line
                        cout << endl;                               //skip line for output
                        if(isWord(nationality)){                                                //check input is made of letters
                            if(nationality.length() >= 1 && nationality.length() <= 50){        //check size of input for database
                                break;                                                          //break loop and continue program
                            }
                            else{
                                cout << "Invalid input. Entry has a character limit of 50 and cannot be empty." << endl;     //print error message
                                cin.clear();                                                                    //clear input
                            }
                        }
                        else{
                            cout << "Invalid entry. No comma's, periods, or special characters." << endl;       //print error message
                            cin.clear();                                                                        //clear input
                        }
                    }//end while    

                    query = "update Patient set Nationality = '" + nationality + "' where Patient_ID = " + to_string(patientID);       //query with update to database
                    if(sqlite3_exec(db, query.c_str(), NULL, &result, NULL) != SQLITE_OK) {                     //compare exec to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating Nationality: " << LastError << endl;               //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                         //print update
                    commit(db);                                                     //commit changes
                    cout << "Nationality updated." << endl;                             //print success
                    sqlite3_finalize(result);                                       //reset result
                    break;                                                          //end case 10
                

    //edit Phone
                case 11:
                    temp = reinterpret_cast<const char*>(sqlite3_column_text(result, 11));
                    cout << "Patients current Phone number in database is, (";
                    cout << temp[0] << temp[1] << temp[2] << ") " << temp[3] << temp [4] << temp[5] << "-";
                    cout << temp[6] << temp[7] << temp[8] << temp[9] << endl;
                    cout << "Enter new phone number with no spaces or hyphens. (Ex: 1234567890)" << endl;
                    cout << "Enter new phone: ";
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore anything left

                    while(loop){                                                        //validate input
                        getline(cin, phone);                                            //grab entire line
                        cout << endl;                                                   //skip line for output
                        if(isDigit(phone)){                                             //check input is made of numbers
                            if(phone.length() == 10){                                   //check input is the correct length of numbers
                                break;                                                  //break loop and continue program
                            }
                            else{
                                cout << "Invalid input. Entry must be 10 characters." << endl;     //print error message
                                cin.clear();                                            //clear input
                            }
                        }
                        else{
                            cout << "Invalid entry. Try again." << endl;                //print error message
                            cin.clear();                                                //clear input
                        }
                    }//end while

                    query = "update Patient set Phone = '" + phone + "' where Patient_ID = " + to_string(patientID);       //query with update to database
                    if(sqlite3_exec(db, query.c_str(), NULL, &result, NULL) != SQLITE_OK) {                     //compare exec to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating Phone number: " << LastError << endl;              //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                         //print update
                    commit(db);                                                     //commit changes
                    cout << "Phone number updated." << endl;                        //print success
                    sqlite3_finalize(result);                                       //reset result
                    break;                                                          //end case 11
                

    //edit Email
                case 12:
                    cout << "Patients current Email address in database is, " << sqlite3_column_text(result, 12) << endl;
                    cout << "Enter new email: ";
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore anything left

                    while(loop){                                                                //validate user input
                        getline(cin, email);                                                    //grab the entire line
                        cout << endl;                                   //skip line for output
                        if(isEmail(email)){                                                     //check email fits certain requirements
                            if(email.length() >= 1 && email.length() <= 50){                    //check size constraint for database
                                break;                                                          //break loop and continue program
                            }
                            else{
                                cout << "Invalid input. Entry has a character limit of 50 and cannot be empty." << endl;       //print error message
                                cin.clear();                                                                //clear input
                            }
                        }
                        else{
                            cout << "Invalid entry. Try again." << endl;                                    //print error message
                            cin.clear();                                                                    //clear input
                        }
                    }//end while                    
                    
                    query = "update Patient set Email = '" + email + "' where Patient_ID = " + to_string(patientID);       //query with update to database
                    if(sqlite3_exec(db, query.c_str(), NULL, &result, NULL) != SQLITE_OK) {                     //compare exec to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating Email: " << LastError << endl;                     //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                         //print update
                    commit(db);                                                     //commit changes
                    cout << "Email address updated." << endl;                       //print success
                    sqlite3_finalize(result);                                       //reset result
                    break;                                                          //end case 12
            }//end switch case for editing
            cout << endl;                               //skip line for output


//prompt user to continue editing or end session
            cout << "Do you have more to edit for this patient? (Enter: y or n)" << endl;
            cout << "Enter choice: ";

            while(loop){                                                                                              //validate yes or no input
                cin >> userInput;                                                                                     //get input from user as string
                if(userInput == "Y" || userInput == "y" || userInput == "N" || userInput == "n"){                     //check input is yes or no and end
                    break;
                }
                else{
                    cout << "Invalid entry. Enter 'Y' for yes or 'N' for no." << endl;          //prompt user with error message
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore the rest
                }
            }//end while
        }//end else
    }//end while (edit patient info)
    cout << endl;                                                                           //skip line for output before returning to main
}//edit patient


//function to print the menu for edit Epi
void editEpiMenu(){
    cout << "**************  MENU  **************" << endl;
    cout << "Which field of the exposure case would you like to edit?" << endl;
    cout << "1. Housing Situation" << endl;
    cout << "2. Household Size" << endl;
    cout << "3. Water Source" << endl;
    cout << "4. Water Contact" << endl;
    cout << "5. Sexual Activity" << endl;
    cout << "6. Animal Contact" << endl;
    cout << "7. Change Investigator" << endl;
    cout << "8. Travel" << endl;
    cout << "9. Note" << endl;
    cout << "10. Investigation Date" << endl;
    cout << "11. Start Date Of Pathogen" << endl;
    cout << "Enter choice: ";
}//end editEpiMenu


//function to edit a chosen patients exposure case(s) info that is not a primary/foreign key
void editEpi(sqlite3 *db){
/*
**Epi Table**
Epi_ID                          int                         (Primary Key)
Patient_ID                      int                         (Foreign Key)
Housing                         varchar(20) NOT NULL
Pet_ID                          int                         (Foreign Key)
Household_Size                  int NOT NULL
Water_Source                    char(4) NOT NULL
Water_Contact                   varchar(100) NOT NULL
Sexual_Activity                 varchar(100) NOT NULL
Animal_Contact                  varchar(100) NOT NULL
Investigator_ID                 int                         (Foreign Key)
Travel                          varchar(100) NOT NULL
Note                            varchar(500) NOT NULL
Investigation_Date              char(8) NOT NULL
Start_Of_Pathogen               char(8) NOT NULL
Pathogen_ID                     int                         (Foreign Key)
*/
    int epiID, patientID, petID, investigatorID, pathogenID;                                                                    //used for storing primary key, foreign keys for table or from other tables
    int householdSize;                                                                                                          //used for storing user data for insertion
    string housing, waterSource, waterContact, sexualActivity, animalContact, travel, note, investigationDate, pathogenDate;    //used for storing user data for insertion
    string userInput, temp, fname, lname;                                                                                       //used for user input
    string query, query2;                                                                                                       //used to query database
    int i = 1, choice, choice2;                                                                                                 //used for loop and validation input
    bool loop = true;                                                                                                           //used to initiate each while loop, break statement will exit
    string LastError;                                                                                                           //used to report error from database
    sqlite3_stmt *result, *result2;                                                                                             //used to store results of query on database
    char *err;
    query = "begin transaction;";
    int count = 0;                                                                      //variable only used in loop for iteration count
    int rc;

//begin transaction
    rc = sqlite3_exec(db, query.c_str(), NULL, NULL, &err);
    if(rc != SQLITE_OK){
        cout << "Error starting transaction: " << err << endl;
        sqlite3_free(err);
        return;
    }

//find if user wants to search by id or name
    cout << "Do you want to pick from the list of patients or by the First and Last name? (Enter: 1 or 2)" << endl;
    cout << "1. Find patient from list" << endl;
    cout << "2. Find patient by First and Last name" << endl;
    cout << "Enter choice: ";

    while(loop){                                        //validate input loop
        cin >> userInput;                               //gather user input
        cout << endl;
        if(isDigit(userInput)){                         //check string input is a number
            choice = stoi(userInput);                   //convert string to int value
            if(choice == 1 || choice == 2){             //check number is 1 or 2
                break;                                  //break loop and continue with program
            }
            else{
                cout << "Invalid input. Entry must be 1 or 2." << endl;     //print error
                cin.clear();                                                //clear input
                cin.ignore(1000, '\n');                                     //ignore anything left
            }
        }
        else{
            cout << "Invalid input. Entry must be a number 1 or 2" << endl;         //print error message
            cin.clear();                //clear input
            cin.ignore(1000, '\n');     //ignore anything left
        }
    }//end while

//if choice is 1
    if(choice == 1){
        query = "select * from patient";                    //set query to get everything from patient table
        if(sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL) != SQLITE_OK) {         //prepare statement and make sure no errors occur
            LastError = sqlite3_errmsg(db);                                                 //print error message from database
            sqlite3_finalize(result);                                                       //clear result
            cout << "There was an error selecting from Patient table: " << LastError << endl;                            //print error
            rollback(db);                                                                   //rollback database to previous state before error
            return;                                                                         //return to main
        }

        i = 1;                                                                              //set i to 1 for output
        cout << "****Patient(s) Information****" << endl;
        while (sqlite3_step(result) == SQLITE_ROW){                     //Print patient first and last name with date of birth for user to choose from to see more info
            cout << i << ". " << sqlite3_column_text(result, 1) << " ";                     //print the current count and the first name from table
            if(sqlite3_column_text(result, 2) != NULL){                                     //make sure middle initial is not null
                cout << sqlite3_column_text(result, 2) << ". ";                             //print middle initial if not null
            }
            cout << sqlite3_column_text(result, 3);                                         //print patient last name from database
            cout << " - DOB: ";
            temp = reinterpret_cast<const char*>(sqlite3_column_text(result, 4));           //cast dob of birth to string variable to split for proper output
            cout << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7];     //split date by MM-DD-YYYY
            cout << endl;
            i++;                                                                            //increment i by 1
        }//end while
        cout << endl;

        cout << "Choose patient from list or enter -1 to cancel search and return to main menu." << endl;
        cout << "Enter choice: ";
        cin >> choice2;                                                                      //user inputs an int
        cout << endl;                                                                           //skip line for output

        while(!cin || choice2 < 1 || choice2 >= i){                                            //validate choice was within the proper range of the output
            if(choice2 == -1){                                                                   //if user enters -1 return to main
                rollback(db);                                                                   //rollback since cancelling
                return;                                                                         //return to main
            }
            if (!cin){                                                                      //if unexepected inputs clear input
                cin.clear();
                cin.ignore(1000, '\n');
            }
            cout << "That is not a valid patient! Try again!" << endl;                      //prompt user of error and allow reentry
            cin >> choice2;
            cout << endl;                                                                   //skip line for output
        }

        sqlite3_reset(result);                                                              //reset result statement to the beginning
        for (int j = 0; j < choice2; j++){                                                   //loop runs to the patient chosen by user
            sqlite3_step(result);                                                           //and sets result to that patient row
        }

        patientID = sqlite3_column_int(result, 0);                                          //patientID stores the patients ID from database
    }//end if (choice 1)


//if choice is 2
    if(choice == 2){
        cout << "Remember searches are case sensitive." << endl;
        cout << "Please enter the first name of the patient." << endl;
        cout << "Enter name: ";
        cin.clear();                                                                //clear input
        cin.ignore(1000, '\n');                                                     //ignore anything left
        while(loop){                                                                //validate first name of patient
            getline(cin, fname);                                                    //getline incase patient name may be multiple parts
            cout << endl;
            if(fname.length() > 0 && fname.length() <= 50){
                if(isWord(fname)) {                                                     //find if string is made up of the alphabet and return boolean 
                    break;                                                              //break loop and continue program
                }
                else {                                                                                                                      
                    cout << "Please only enter letters from the alphabet for first name. Entry is case sensitive." << endl;     //print error message
                    cin.clear();
                }
            }
            else{
                cout << "Invalid input. Entry has a character limit of 50 and cannot be empty." << endl;
                cin.clear();
            }
        }//end while
                
        cout << "Please enter the last name of the patient." << endl;
        cout << "Enter name: ";
        while(loop) {                                                       //validate input of patient last name
            getline(cin, lname);                                            //getline incase patient name may be multiple parts
            cout << endl;                                                   //skip line for output
            if(lname.length() > 0 && lname.length() <= 50){
                if(isWord(lname)) {                                     //if string is made up of the alphabet then break; to end loop
                    break;                                              //break loop and continue program
                }
                else {
                    cout << "Please only enter letter from the alphabet for last name. Entry is case sensitive." << endl;   //print error message
                    cin.clear();
                }
            }
            else{
                cout << "Invalid input. Entry has a character limit of 50 and cannot be empty." << endl;
                cin.clear();
            }    
        }//end while

        query = "select * from patient where Patient.First_Name = '" + fname + "' and Patient.Last_Name = '" + lname + "';";
        if(sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL) != SQLITE_OK) {         //prepare statement and make sure no errors occur
            LastError = sqlite3_errmsg(db);                                                 //print error message from database
            sqlite3_finalize(result);                                                       //clear result
            cout << "There was an error selecting from Patient table: " << LastError << endl;                            //print error
            rollback(db);                                                                   //rollback database to previous state before error
            return;                                                                         //return to main
        }

        sqlite3_step(result);
        if(sqlite3_column_text(result, 0) == NULL){                     //if patient id returns null patient does not exist within database, prompt to create patient
            cout << "Patient(s) could not be found in database. Check entry or create new patient." << endl << endl;
            sqlite3_finalize(result);                                                       //clear result
            rollback(db);                                                                   //rollback database to previous state before error
            return;                                                                         //return to main
        }
        sqlite3_reset(result);                                                              //reset result to beginning to iterate through results 
        
        i = 1;                                                                              //set i to 1 for output
        cout << "****Patient(s) Information****" << endl;
        while (sqlite3_step(result) == SQLITE_ROW){                     //Print patient first and last name with date of birth for user to choose from to see more info
            cout << i << ". " << sqlite3_column_text(result, 1) << " ";                     //print the current count and the first name from table
            if(sqlite3_column_text(result, 2) != NULL){                                     //make sure middle initial is not null
                cout << sqlite3_column_text(result, 2) << ". ";                             //print middle initial if not null
            }
            cout << sqlite3_column_text(result, 3);                                         //print patient last name from database
            cout << " - DOB: ";
            temp = reinterpret_cast<const char*>(sqlite3_column_text(result, 4));           //cast dob of birth to string variable to split for proper output
            cout << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7];     //split date by MM-DD-YYYY
            cout << endl;
            i++;                                                                            //increment i by 1
        }//end while
        cout << endl;

        cout << "Choose patient from list or enter -1 to cancel search and return to main menu." << endl;
        cout << "Enter choice: ";
        cin >> choice;                                                                      //user inputs an int
        cout << endl;                                                                       //skip line for output

        while(!cin || choice < 1 || choice >= i){                                            //validate choice was within the proper range of the output
            if(choice == -1){                                                                   //if user enters -1 return to main
                rollback(db);                                                                   //rollback since cancelling
                return;                                                                         //return to main
            }
            if (!cin){                                                                      //if unexepected inputs clear input
                cin.clear();
                cin.ignore(1000, '\n');
            }
            cout << "That is not a valid patient! Try again!" << endl;                      //prompt user of error and allow reentry
            cin >> choice;
            cout << endl;                                                                   //skip line for output
        }//end while

        sqlite3_reset(result);                                                              //reset result statement to the beginning
        for (int j = 0; j < choice; j++){                                                   //loop runs to the patient chosen by user
            sqlite3_step(result);                                                           //and sets result to that patient row
        }

        patientID = sqlite3_column_int(result, 0);                                          //patientID stores the patients ID from database
    }//end if (choice 2)
    

//Query database to return all epi cases to a patient and enough info for the investigator to choose the correct case to edit
//If epiId is not null
    if(sqlite3_column_text(result, 13) != NULL){                    //if column is not empty then the patient has an exposure case that can be editted
        
        sqlite3_finalize(result);                                                           //clear result statement for reuse
        query = "select Epi_ID, Investigation_Date, Start_Of_Pathogen, Pathogen.Pathogen_Type ";    //query to grab any exposure case for that patient
            query += "from Epi_Case join Pathogen ";
            query += "on Pathogen.Pathogen_ID = Epi_Case.Pathogen_ID ";
            query += "where Epi_Case.Patient_ID = " + to_string(patientID) + ";";
        if((sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL)) != SQLITE_OK){        //check statement for anything errors
            LastError = sqlite3_errmsg(db);                                                 //store error message from database
            sqlite3_finalize(result);                                                       //reset the statement result
            cout << "There was an error with selecting from Epi Case table: " << LastError << endl;         //print error from database
            rollback(db);                                                                   //rollback database to error free state
            return;                                                                         //return to main
        } 
        sqlite3_reset(result);                                                              //reset result to beginning to iterate through results 

        i = 1;                                                                              //set i to 1 for output
        cout << "****Patient Exposure Case(s)****" << endl;
        while (sqlite3_step(result) == SQLITE_ROW){                     //Print patient first and last name with date of birth for user to choose from to see more info
            cout << i << ". Epi ID: " << sqlite3_column_text(result, 0) << " ";             //print the current count and the Epi_ID from table
            cout << "Start of Investigation: ";                                                 //print investigation date
            temp = reinterpret_cast<const char*>(sqlite3_column_text(result, 1));           //cast investigation date to temp then split for proper output
            cout << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7] << " ";     //split date by MM-DD-YYYY
            cout << "Start of Pathogen: ";                                                 //print investigation date
            temp = reinterpret_cast<const char*>(sqlite3_column_text(result, 2));           //cast start date of pathogen to temp then split for proper output
            cout << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7] << " ";     //split date by MM-DD-YYYY
            cout << "Pathogen: " << sqlite3_column_text(result, 3);                                                 //print investigation date       
            cout << endl;
            i++;                                                                            //increment i by 1
        }//end while
        cout << endl;

        cout << "Choose patient from list or enter -1 to cancel search and return to main menu." << endl;
        cout << "Enter choice: ";
        cin >> choice;                                                                      //user inputs an int
        cout << endl;

        while(!cin || choice < 1 || choice >= i){                                            //validate choice was within the proper range of the output
            if(choice == -1){                                                                   //if user enters -1 return to main
                rollback(db);                                                                   //rollback since cancelling
                return;                                                                         //return to main
            }            
            if (!cin){                                                                      //if unexepected inputs clear input
                cin.clear();
                cin.ignore(1000, '\n');
            }
            cout << "That is not a valid patient! Try again!" << endl;                      //prompt user of error and allow reentry
            cin >> choice;
            cout << endl;
        }

        sqlite3_reset(result);                                                              //reset result statement to the beginning
        for (int j = 0; j < choice; j++){                                                   //loop runs to the patient chosen by user
            sqlite3_step(result);                                                           //and sets result to that patient row
        }

        epiID = sqlite3_column_int(result, 0);                                             //epiID stores the exposure ID from database
        sqlite3_finalize(result);                                                           //clear result statement for reuse
    }
//If patient does not have an exposure case to edit
    else{                                                                           //if Epi_ID is empty then there is nothing to edit and return to main
        cout << "Patient does not have an exposure case to edit. Returning to main menu..." << endl;        //print message to user of no epi case found
        cout << endl;
        rollback(db);                                                                                       //rollback database to previous state
        sqlite3_finalize(result);                                                                           //reset results
        return;                                                                                             //return to main menu
    }


//What aspect of the patient exposure case is under edit
    while(loop){
        if(userInput == "n" || userInput == "N"){       //condition to break loop and finish with editing
            break;
        }
        else{
            //query database each time for most recent info from case file
            query = "select * from Epi_Case where Patient_ID = " + to_string(patientID) + " and Epi_ID = " + to_string(epiID) + ";";
            if((sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL)) != SQLITE_OK){        //check statement for anything errors
                LastError = sqlite3_errmsg(db);                                                 //store error message from database
                sqlite3_finalize(result);                                                       //reset the statement result
                cout << "There was an error with selecting from Epi Case table: " << LastError << endl;         //print error from database
                rollback(db);                                                                   //rollback database to error free state
                return;                                                                         //return to main
            } 
            sqlite3_reset(result);                                                              //reset statement
            sqlite3_step(result);                                                               //step to correct row
                    
            cout << endl;                               //skip line for output
            editEpiMenu();                  //print menu for edit exposure case

            while(loop){                                        //validate input loop
                cin >> userInput;                               //gather user input
                cout << endl;                                   //skip line for output
                if(isDigit(userInput)){                         //check string input is a number
                    choice = stoi(userInput);                   //convert string to int value
                    if(choice >= 1 && choice <= 11){            //check number is 1 - 11
                        break;                                  //break loop and continue with program
                    }
                    else{
                        cout << "Invalid input. Entry must be 1 thru 11." << endl;     //print error
                        cin.clear();                                                //clear input
                        cin.ignore(1000, '\n');                                     //ignore anything left
                    }
                }
                else{
                    cout << "Invalid input. Entry must be a number 1 thru 11" << endl;         //print error message
                    cin.clear();                //clear input
                    cin.ignore(1000, '\n');     //ignore anything left
                }
            }//end while
        
            if(count > 0){                                                                      //if not first iteration
                query = "begin transaction;";                                                   //attempt to create a new save point for the database if things go wrong
                if(sqlite3_exec(db, query.c_str(), NULL, NULL, &err) != SQLITE_OK){             //begin transaction
                cout << "Error starting transaction: " << err << endl;                          //print error
                sqlite3_free(err);                                                              //free up pointer
                return;                                                                         //return to main
                }
            }//end if
            count++;                        //increment count

            switch(choice){
    //edit the patients housing situation       20
                case 1:
                    cout << "Patients housing information from database: " << sqlite3_column_text(result, 2) << endl;
                    cout << "Type input: ";
                    cin.clear();                                                            //clear input
                    cin.ignore(1000, '\n');                                                 //ignore anything left
                    while(loop){                                                            //validation loop for user input
                        getline(cin, housing);                                              //makes sure to grab the entire input
                        cout << endl;                                                       //skip line for output
                        if(isWord(housing)){                                                //check input is made up of letters and spaces no special characters
                            if(housing.length() > 0 && housing.length() <= 20){             //check if input is within the size constraint of the database
                                break;                                                               //break loop and continue program
                            }
                            else{
                                cout << "Invalid Input. 20 character limit." << endl;                        //print error message with length limit
                                cin.clear();
                            }
                        }
                        else{
                            cout << "Invalid Input. No special characters or numbers. Try again." << endl;        //prompt user with error and to try again
                            cin.clear();
                        }
                    }//end while

                    query = "update Epi_Case set Housing = '" + housing + "' where Epi_ID = " + to_string(epiID);       //query with update to database
                    rc = sqlite3_exec(db, query.c_str(), NULL, &result, NULL);                                  //return a value if execution was successful or not
                    if(rc != SQLITE_OK) {                                                                       //compare rc to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating Housing: " << LastError << endl;                   //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                     //print update
                    commit(db);                                                 //commit changes
                    cout << "Housing information updated." << endl;             //print success
                    sqlite3_finalize(result);                                   //reset result statement
                    break;                                                      //end case 1


    //edit the patients household size
                case 2:
                    cout << "Patients current household size from database: " << sqlite3_column_int(result, 4) << endl;
                    cout << "Enter new household size: ";
                    
                    while(loop){                                                        //validate number of people living with patient is a number
                        if(!cin){                                                       //clear input if error in input
                            cin.clear();
                            cin.ignore(1000, '\n');
                        }
                        cin >> userInput;                                               //user enter int using a string
                        cout << endl;                                                   //skip line for output
                        if(isDigit(userInput)){                                         //string is check character by character to check only 0-9
                            householdSize = stoi(userInput);                            //convert string to int type
                            if(householdSize >= 0){                                     //check not negative
                                break;                                                  //break and continue program
                            }
                            else{
                                cout << "Invalid Input. Number cannot be negative." << endl;    //print error message to user
                                cin.clear();                                                    //clear input
                                cin.ignore(1000, '\n');                                         //ignore anything left
                            }
                        }
                        else{
                            cout << "Invalid Input. Enter a number." << endl;           //print error message to user
                            cin.clear();                                                //clear input
                            cin.ignore(1000, '\n');                                     //ignore anything left
                        }
                    }//end while

                    query = "update Epi_Case set Household_Size = " + to_string(householdSize) + " where Epi_ID = " + to_string(epiID);       //query with update to database
                    rc = sqlite3_exec(db, query.c_str(), NULL, &result, NULL);                                  //return a value if execution was successful or not
                    if(rc != SQLITE_OK) {                                                                       //compare rc to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating Household Size: " << LastError << endl;            //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                                     //print update
                    commit(db);                                                                 //commit changes
                    cout << "Household Size updated." << endl;                                  //print success
                    sqlite3_finalize(result);                                                   //reset result
                    break;                                                                      //end case 2
                

    //edit the patients water source
                case 3:
                    cout << "From database patients current water source: " << sqlite3_column_text(result, 5) << endl;
                    cout << "Enter new water source (1 or 2)" << endl;                         //prompt input for type of water source
                    cout << "1. City" << endl;
                    cout << "2. Well" << endl;
                    cout << "Enter choice: ";
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore anything left

                    while(loop){                                                                        //valid the user has chosen 1 or 2
                        cin >> waterSource;                                                             //gather input for water source
                        cout << endl;                                                                   //skip line for output
                        if(waterSource == "1"){                                                         //check if input is 1
                            waterSource = "City";                                                       //set water source to City
                            break;                                                                      //break loop and continue program
                        }
                        else if(waterSource == "2"){                                                    //check if input is 2
                            waterSource = "Well";                                                       //set water source to Well
                            break;                                                                      //break loop and continue program
                        }
                        else{
                            cout << "Invalid entry. Enter 1 for City or Enter 2 for Well." << endl;     //print error message
                            cin.clear();                                                                //clear input
                            cin.ignore(1000, '\n');                                                     //ignore anything left
                        }
                    }//end while

                    query = "update Epi_Case set Water_Source = '" + waterSource + "' where Epi_ID = " + to_string(epiID);       //query with update to database
                    rc = sqlite3_exec(db, query.c_str(), NULL, &result, NULL);                                  //return a value if execution was successful or not
                    if(rc != SQLITE_OK) {                                                                       //compare rc to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating Water Source: " << LastError << endl;              //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                             //print update
                    commit(db);                                                         //commit changes
                    cout << "Water Source updated." << endl;                            //print success
                    sqlite3_finalize(result);                                           //reset result
                    break;                                                              //end case 3
                

    //edit Water Contact info for patient
                case 4:
                    cout << "Patients current water contact: " << sqlite3_column_text(result, 6) << endl;
                    cout << "Enter new water contact: ";
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore anything left

                    while(loop){                                                            //validate input is within size for database
                        getline(cin, waterContact);                                         //grab the entire input
                        cout << endl;                                                       //skip line for output
                        if(waterContact.length() > 0 && waterContact.length() <= 100){      //input cannot be blank or over 100 characters
                            break;                                                          //break loop continue program
                        }
                        else{
                            cout << "Invalid input. Entry has a 100 character limit and cannot be empty." << endl;      //print error message
                            cin.clear();                                                                                //clear input
                        }
                    }//end while

                    query = "update Epi_Case set Water_Contact = '" + waterContact + "' where Epi_ID = " + to_string(epiID);       //query with update to database
                    rc = sqlite3_exec(db, query.c_str(), NULL, &result, NULL);                                  //return a value if execution was successful or not
                    if(rc != SQLITE_OK) {                                                                       //compare rc to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating Water Contact: " << LastError << endl;             //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                             //print update
                    commit(db);                                                         //commit changes
                    cout << "Water Contact updated." << endl;                           //print success
                    sqlite3_finalize(result);                                           //reset result
                    break;                                                              //end case 4


    //edit Sexual Activity info of patient
                case 5:
                    cout << "From database patients current sexual activity: " << sqlite3_column_text(result, 7) << endl;
                    cout << "Enter new sexual activity: ";
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore anything left
                    
                    while(loop){                                                                        //validation loop for user input
                        getline(cin, sexualActivity);                                                   //gather the entire input line
                        cout << endl;                                                                   //skip line for output
                        if(sexualActivity.length() > 0 && sexualActivity.length() <= 100){              //check input is within size constraint for database
                            break;                                                                      //break loop and continue program
                        }
                        else{
                            cout << "Invalid input. Character limit of 100 for input and cannot be empty." << endl;         //print error message
                            cin.clear();                                                                                    //clear input
                        }
                    }//end while

                    query = "update Epi_Case set Sexual_Activity = '" + sexualActivity + "' where Epi_ID = " + to_string(epiID);       //query with update to database
                    rc = sqlite3_exec(db, query.c_str(), NULL, &result, NULL);                                  //return a value if execution was successful or not
                    if(rc != SQLITE_OK) {                                                                       //compare rc to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating Sexual Activity: " << LastError << endl;           //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                             //print update
                    commit(db);                                                         //commit changes
                    cout << "Patients Sexual Activity updated." << endl;                //print success
                    sqlite3_finalize(result);                                           //reset result
                    break;                                                              //end case 5
                
                
    //edit Animal Contact info
                case 6:
                    cout << "Patients current animal contact: " << sqlite3_column_text(result, 8) << endl;
                    cout << "Enter new animal contact: ";
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore anything left
                    
                    while(loop){                                                                                //validate user input
                        getline(cin, animalContact);                                                            //gather the entire line
                        cout << endl;                                                                           //skip line for output
                        if(animalContact.length() > 0 && animalContact.length() <= 100){                        //check it falls within size constraint for database
                            break;                                                                              //continue program
                        }
                        else{
                            cout << "Invalid input. Character limit of 100 for input or empty." << endl;        //print error message
                            cin.clear();                                                                        //clear the input
                        }
                    }//end while

                    query = "update Epi_Case set Animal_Contact = '" + animalContact + "' where Epi_ID = " + to_string(epiID);       //query with update to database
                    rc = sqlite3_exec(db, query.c_str(), NULL, &result, NULL);                                  //return a value if execution was successful or not
                    if(rc != SQLITE_OK) {                                                                       //compare rc to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating Animal Contact: " << LastError << endl;            //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                             //print update
                    commit(db);                                                         //commit changes
                    cout << "Animal Contact updated." << endl;                          //print success
                    sqlite3_finalize(result);                                           //reset result
                    break;                                                              //end case 6
                

    //edit Investigator attached to case
                case 7:
                    query = "select Investigator_First_Name || ' ' || Investigator_Last_Name as 'Name' ";
                        query += "from Investigator where Investigator_ID = " + to_string(sqlite3_column_int(result, 9)) + ";";
                    if((sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL)) != SQLITE_OK){        //check statement for anything errors
                        LastError = sqlite3_errmsg(db);                                                 //store error message from database
                        sqlite3_finalize(result);                                                       //reset the statement result
                        cout << "There was an error with selecting from Investigator table: " << LastError << endl;         //print error from database
                        rollback(db);                                                                   //rollback database to error free state
                        return;                                                                         //return to main
                    } 
                    sqlite3_reset(result);                                                              //reset statement
                    sqlite3_step(result);                                                               //step to correct row
                
                    //print list of investigators to choose from    
                    //cout << "Current Investigator is: " << sqlite3_column_text(result, 0) << " " << sqlite3_column_text(result, 1) << endl;
                    cout << "Current Investigator is: " << sqlite3_column_text(result, 0) << endl;
                    cout << "Pick new credentials to link to case: " << endl;;
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore anything left
                    sqlite3_finalize(result);                                                   //reset statement
                    
                    //
                    query = "select investigator_id, investigator_first_name, investigator_last_name, job_title from investigator;";
                    if((sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL)) != SQLITE_OK){                    //check statement for anything errors
                        LastError = sqlite3_errmsg(db);                                                             //store error message from database
                        sqlite3_finalize(result);                                                                   //reset the statement result
                        cout << "There was an error with selecting from Investigator table: " << LastError << endl;         //print error from database
                        rollback(db);                                                                               //rollback database to error free state
                        return;                                                                                     //return to main
                    }
                    sqlite3_reset(result);                                                                          //reset results to beginning
                    
                    i = 1;
                    while(sqlite3_step(result) == SQLITE_ROW){                                                      //loop to print each row
                        cout << i << ". " << sqlite3_column_text(result, 1) << " " << sqlite3_column_text(result, 2) << "   |   " << sqlite3_column_text(result, 3) << endl;
                        i++;
                    }//end while to print investigator

                    cout << "Enter choice: ";
                    while(loop){                                                //validate users input is an investigator
                        cin >> userInput;                                       //user enters using a string
                        cout << endl;                                           //skip line for output
                        if(isDigit(userInput)){                                 //isDigit checks one character at a time for it to be a digit
                            choice = stoi(userInput);                           //convert string to int
                            if(choice >= 1 && choice < i){                       //check int falls within constraints
                                break;                                          //break loop to continue program
                            }
                            else{   
                                cout << "Invalid entry. Enter number between 1 and " << i << "." << endl;   //print error message
                                cin.clear();                                                                //clear input
                                cin.ignore(1000, '\n');                                                     //clear anything left
                            }
                        }
                        else{
                            cout << "Invalid input. Enter the number representing your information." << endl;             //print error message
                            cin.clear();                                                                    //clear input
                            cin.ignore(1000, '\n');                                                         //clear anything left
                        }
                    }//end while

                    sqlite3_reset(result);                                                                 //reset statement to beginning of results
                    for(int j = 0; j < choice; j++){                                                       //loop progress statement to the correct investigator
                        sqlite3_step(result);                                                                       
                    }

                    investigatorID = sqlite3_column_int(result, 0);                                        //set investigatorID to the current investigator_ID from database  
                    sqlite3_finalize(result);                                                              //reset result

                    //query with update to database
                    query = "update Epi_Case set Investigator_ID = " + to_string(investigatorID) + " where Epi_ID = " + to_string(epiID);       
                    if(sqlite3_exec(db, query.c_str(), NULL, NULL, NULL) != SQLITE_OK) {                        //compare exec to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        cout << "There was an error updating Epi Case: " << LastError << endl;                  //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                             //print update
                    commit(db);                                                         //commit changes
                    cout << "Investigator attached to case updated." << endl;           //print success
                    break;                                                              //end case 7
                

    //edit Travel history of patient
                case 8:
                    cout << "Patients current travel history: " << sqlite3_column_text(result, 10) << endl;
                    cout << "Enter new travel history: ";
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore anything left
                    
                    while(loop){                                                                       //validation loop 
                        getline(cin, travel);                                                          //take the entire input line
                        cout << endl;                                                                  //skip line for output
                        if(travel.length() > 0 && travel.length() <= 100){                             //check input is within size constraint for database
                            break;                                                                     //break loop and continue the program
                        }
                        else{
                            cout << "Invalid input. Character limit of 100 for input." << endl;             //print error message
                            cin.clear();
                        }
                    }//end while

                    query = "update Epi_Case set Travel = '" + travel + "' where Epi_ID = " + to_string(epiID);       //query with update to database
                    rc = sqlite3_exec(db, query.c_str(), NULL, &result, NULL);                                  //return a value if execution was successful or not
                    if(rc != SQLITE_OK) {                                                                       //compare rc to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating Travel history: " << LastError << endl;                //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                             //print update
                    commit(db);                                                         //commit changes
                    cout << "Travel history updated." << endl;                          //print success
                    sqlite3_finalize(result);                                           //reset result
                    break;                                                              //end case 8
                

    //edit the note placed in the exposure case
                case 9:
                    cout << "Current note attached to Patient: " << sqlite3_column_text(result, 11) << endl;
                    cout << "Enter new note: ";
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore anything left
                    
                    while(loop){                                                                        //validate input
                        getline(cin, note);                                                             //gather entire line
                        cout << endl;                                                                   //skip line for output
                        if(note.length() > 0 && note.length() <= 500){                                  //check note fits within size constraint for database
                            break;                                                                      //break loop continue program
                        }
                        else{
                            cout << "Invalid input. Character limit of 500 for the input." << endl;         //print error message
                            cin.clear();
                        }
                    }//end while

                    query = "update Epi_Case set Note = '" + note + "' where Epi_ID = " + to_string(epiID);       //query with update to database
                    rc = sqlite3_exec(db, query.c_str(), NULL, &result, NULL);                                  //return a value if execution was successful or not
                    if(rc != SQLITE_OK) {                                                                       //compare rc to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating case Note: " << LastError << endl;                //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                             //print update
                    commit(db);                                                         //commit changes
                    cout << "Note attached to patient updated." << endl;                //print success
                    sqlite3_finalize(result);                                           //reset result
                    break;                                                              //end case 9
                

    //edit Start Date of Investigation
                case 10:
                    cout << "Current start date of investigation: " << sqlite3_column_text(result, 12) << endl;
                    cout << "Enter new start date, no hypens or slashes. (Ex: MMDDYYYY)." << endl;
                    cout << "Enter Date: ";
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore anything left
                    
                    while(loop){                                                                                //validate input loop
                        cin >> investigationDate;                                                               //gather the date
                        cout << endl;                                                                           //skip line for output
                        if(investigationDate.length() == 8){                                                    //checks it's length first
                            if(isDate(investigationDate)){                                                      //use date function to check for correct format
                                break;                                                                          //continue program once done with validation
                            }
                            else{
                                cout << "Invalide input. Try again. (Month: 01-12    Day: 01-31    Year: 1999-2999)" << endl;   //print error message with example
                                cin.clear();                                                                                    //clear input
                                cin.ignore(1000, '\n');                                                                         //ignore anything left
                            }
                        }
                        else{
                            cout << "Invalid input. Try again." << endl;                                        //print error message
                            cin.clear();                                                                        //clear input
                            cin.ignore(1000,'\n');                                                              //ignore anything left
                        }
                    }//end while

                    query = "update Epi_Case set Investigation_Date = '" + investigationDate + "' where Epi_ID = " + to_string(epiID);       //query with update to database
                    rc = sqlite3_exec(db, query.c_str(), NULL, &result, NULL);                                  //return a value if execution was successful or not
                    if(rc != SQLITE_OK) {                                                                       //compare rc to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating Investigation Date: " << LastError << endl;                //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                             //print update
                    commit(db);                                                         //commit changes
                    cout << "Investigation Date updated." << endl;                      //print success
                    sqlite3_finalize(result);                                           //reset result
                    break;                                                              //end case 10


    //edit Start Date of Pathogen
                case 11:
                    cout << "Start date of pathogen on file: " << sqlite3_column_text(result, 13) << endl;
                    cout << "Enter new pathogen start date, no hyphens or slashes. (Ex: MMDDYYYY)." << endl;
                    cout << "Enter Date: ";
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore anything left
                    
                    while(loop){                                                                //validate user input
                        cin >> pathogenDate;                                                    //gather pathogen date from user
                        cout << endl;                                                           //skip line for output
                        if(pathogenDate.length() == 8){                                         //check entry is proper length
                            if(isDate(pathogenDate)){                                           //use isDate function to validate the entry is a correct date
                                break;                                                          //break loop and continue program
                            }
                            else{
                                cout << "Invalide input. Input out of range. (Month: 01-12   Day: 01-31   Year: 1900-2999)" << endl;     //print error message
                                cin.clear();                                                                        //clear input
                                cin.ignore(1000, '\n');                                                             //ignore anything left
                            }
                        }
                        else{
                            cout << "Invalid input. Try again." << endl;                                            //print error message
                            cin.clear();                                                                            //clear input
                            cin.ignore(1000,'\n');                                                                  //ignore anything left
                        }
                    }//end while

                    query = "update Epi_Case set Start_Of_Pathogen = '" + pathogenDate + "' where Epi_ID = " + to_string(epiID);       //query with update to database
                    rc = sqlite3_exec(db, query.c_str(), NULL, &result, NULL);                                  //return a value if execution was successful or not
                    if(rc != SQLITE_OK) {                                                                       //compare rc to Sqlite ok variable
                        LastError = sqlite3_errmsg(db);                                                         //store error from database
                        sqlite3_finalize(result);                                                               //finalize results
                        cout << "There was an error updating Pathogen Start Date: " << LastError << endl;                //print error message
                        rollback(db);                                                                           //rollback database
                        return;                                                                                 //break loop and return to main menu
                    }

                    cout << "Updating....";                                             //print update
                    commit(db);                                                         //commit changes
                    cout << "Pathogen start date updated." << endl;                     //print success
                    sqlite3_finalize(result);                                           //reset result
                    break;                                                              //end case 11
            }//end switch case for editing        
            cout << endl;                               //skip line for output


//prompt user to continue editing or end session
            cout << "Do you have more to edit for this patient? (Enter: y or n)" << endl;
            cout << "Enter choice: ";
            while(loop){                                                                                              //validate yes or no input
                cin >> userInput;                                                                                     //get input from user as string
                if(userInput == "Y" || userInput == "y" || userInput == "N" || userInput == "n"){                     //check input is yes or no and end
                    break;
                }
                else{
                    cout << "Invalid entry. Enter 'Y' for yes or 'N' for no." << endl;          //prompt user with error message
                    cin.clear();                                                                //clear input
                    cin.ignore(1000, '\n');                                                     //ignore the rest
                }
            }//end while
        }//end else
    }//end while
    cout << endl;                                                                               //skip line for output before returning to main
}//end editEpi


//function to delete a patients symptom from database
void deleteSymptom(sqlite3 *db){
/*
****Symptom****
Symptom_ID                      int                         (Primary Key)
Epi_ID                          int                         (Foreign Key)
Symptom_Type                    varchar(200) NOT NULL
Start_Of_Symptom                char(8) NOT NULL
Symptom_Severity                int NOT NULL
Symptom_Effected_Area           varchar(100) NOT NULL
Symptom_Contagious              varchar(100) NOT NULL
*/    
    int epiID, patientID, symptomID;                                                                                            //used for storing primary key, foreign keys for table or from other tables
    string userInput, temp, fname, lname;                                                                                       //used for user input
    string query;                                                                                                               //used to query database
    int i = 1, choice, choice2;                                                                                                 //used for loop and validation input
    bool loop = true;                                                                                                           //used to initiate each while loop, break statement will exit
    string LastError;                                                                                                           //used to report error from database
    sqlite3_stmt *result;                                                                                                       //used to store results of query on database
    query = "begin transaction;";
    char *err;


//begin transaction
    if(sqlite3_exec(db, query.c_str(), NULL, NULL, &err) != SQLITE_OK){
        cout << "Error starting transaction: " << err << endl;
        sqlite3_free(err);
        return;
    }

//find if user wants to search by id or name
    cout << "To delete a symptom we first need to find the patient it belongs to." << endl;
    cout << "Do you want to pick from a list of patients or by the First and Last name? (Enter: 1 or 2)" << endl;
    cout << "1. Find patient from list" << endl;
    cout << "2. Find patient by First and Last name" << endl;
    cout << "Enter choice: ";

    while(loop){                                        //validate input loop
        cin >> userInput;                               //gather user input
        cout << endl;
        if(isDigit(userInput)){                         //check string input is a number
            choice = stoi(userInput);                   //convert string to int value
            if(choice == 1 || choice == 2){             //check number is 1 or 2
                break;                                  //break loop and continue with program
            }
            else{
                cout << "Invalid input. Entry must be 1 or 2." << endl;     //print error
                cin.clear();                                                //clear input
                cin.ignore(1000, '\n');                                     //ignore anything left
            }
        }
        else{
            cout << "Invalid input. Entry must be a number 1 or 2" << endl;         //print error message
            cin.clear();                //clear input
            cin.ignore(1000, '\n');     //ignore anything left
        }
    }//end while

//if choice is 1
    if(choice == 1){
        query = "select Patient_ID, First_Name, Middle_Initial, Last_Name, DOB, Epi_ID from Patient where Patient_ID = ";
        query += "(select Patient_ID from Epi_Case where Patient.Patient_ID = Epi_Case.Patient_ID and Epi_Case.Epi_ID = ";
        query += "(select Epi_ID from Symptom where Epi_Case.Epi_ID = Symptom.Epi_ID));"; //set query to get patient info of patients that have symptoms in database regardless of most recent epi_case linked in patient file
        if(sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL) != SQLITE_OK) {         //prepare statement and make sure no errors occur
            LastError = sqlite3_errmsg(db);                                                 //print error message from database
            sqlite3_finalize(result);                                                       //clear result
            cout << "There was an error selecting from Patient table: " << LastError << endl;                            //print error
            rollback(db);                                                                   //rollback database to previous state before error
            return;                                                                         //return to main
        }

        i = 1;                                                                              //set i to 1 for output
        cout << "Pick from list of patients with symptoms in database." << endl;                  
        cout << "****Patient(s) Information****" << endl;
        while (sqlite3_step(result) == SQLITE_ROW){                     //Print patient first and last name with date of birth for user to choose from to see more info
            cout << i << ". " << sqlite3_column_text(result, 1) << " ";                     //print the current count and the first name from table
            if(sqlite3_column_text(result, 2) != NULL){                                     //make sure middle initial is not null
                cout << sqlite3_column_text(result, 2) << ". ";                             //print middle initial if not null
            }
            cout << sqlite3_column_text(result, 3);                                         //print patient last name from database
            cout << " - DOB: ";
            temp = reinterpret_cast<const char*>(sqlite3_column_text(result, 4));           //cast dob of birth to string variable to split for proper output
            cout << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7];     //split date by MM-DD-YYYY
            cout << endl;
            i++;                                                                            //increment i by 1
        }//end while
        cout << endl;

        cout << "Choose patient from list or enter -1 to cancel search and return to main menu." << endl;
        cout << "Enter choice: ";
        cin >> choice2;                                                                      //user inputs an int
        cout << endl;

        while(!cin || choice2 < 1 || choice2 >= i){                                            //validate choice was within the proper range of the output
            if(choice2 == -1){                                                                   //if user enters -1 return to main
                rollback(db);                                                                   //rollback since cancelling
                return;                                                                         //return to main
            }
            if (!cin){                                                                      //if unexepected inputs clear input
                cin.clear();
                cin.ignore(1000, '\n');
            }
            cout << "That is not a valid patient! Try again!" << endl;                      //prompt user of error and allow reentry
            cin >> choice2;
            cout << endl;
        }

        sqlite3_reset(result);                                                              //reset result statement to the beginning
        for (int j = 0; j < choice2; j++){                                                   //loop runs to the patient chosen by user
            sqlite3_step(result);                                                           //and sets result to that patient row
        }

        patientID = sqlite3_column_int(result, 0);                                          //patientID stores the patients ID from database
    }//end if (choice 1)


//if choice is 2
    if(choice == 2){
        cout << "Remember searches are case sensitive." << endl;
        cout << "Please enter the first name of the patient." << endl;
        cout << "Enter name: ";
        cin.clear();                                                                //clear input
        cin.ignore(1000, '\n');                                                     //ignore anything left

        while(loop){                                                                //validate first name of patient
            getline(cin, fname);                                                    //getline incase patient name may be multiple parts
            cout << endl;
            if(fname.length() > 0 && fname.length() <= 50){
                if(isWord(fname)) {                                                     //find if string is made up of the alphabet and return boolean 
                    break;                                                              //break loop and continue program
                }
                else {                                                                                                                      
                    cout << "Please only enter letters from the alphabet for first name. Entry is case sensitive." << endl;     //print error message
                    cin.clear();
                }
            }
            else{
                cout << "Invalid input. Entry has a character limit of 50 and cannot be empty." << endl;
                cin.clear();
            }
        }//end while
                
        cout << "Please enter the last name of the patient." << endl;
        cout << "Enter name: ";
        while(loop) {                                                       //validate input of patient last name
            getline(cin, lname);                                            //getline incase patient name may be multiple parts
            cout << endl;                                                   //skip line for output
            if(lname.length() > 0 && lname.length() <= 50){
                if(isWord(lname)) {                                     //if string is made up of the alphabet then break; to end loop
                    break;                                              //break loop and continue program
                }
                else {
                    cout << "Please only enter letter from the alphabet for last name. Entry is case sensitive." << endl;   //print error message
                }
            }
            else{
                cout << "Invalid input. Entry has a character limit of 50 and cannot be empty." << endl;
            }    
        }//end while

        //query if multiple patients with the same name, grab their info only if they have symptoms in the symptoms table
        query = "select Patient_ID, First_Name, Middle_Initial, Last_Name, DOB, Epi_ID from Patient where First_Name = ";
            query += "'" + fname + "' and Last_Name = '" + lname + "' and Patient_ID = (select Patient_ID from Epi_Case where ";
            query += "Patient.Patient_ID = Epi_Case.Patient_ID and Epi_Case.Epi_ID = (select Epi_ID from Symptom where ";
            query += "Epi_Case.Epi_ID = Symptom.Epi_ID));";                                 //query will grab any patient by this name who has symtoms within the database 
        if(sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL) != SQLITE_OK) {         //prepare statement and make sure no errors occur
            LastError = sqlite3_errmsg(db);                                                 //print error message from database
            sqlite3_finalize(result);                                                       //clear result
            cout << "There was an error selecting from Patient table: " << LastError << endl;                            //print error
            rollback(db);                                                                   //rollback database to previous state before error
            return;                                                                         //return to main
        }

        sqlite3_step(result);
        if(sqlite3_column_text(result, 0) == NULL){                     //if patient id returns null patient does not exist within database, prompt to create patient
            cout << "Patient(s) could not be found in database. Check entry or create new patient." << endl << endl;
            sqlite3_finalize(result);                                                       //clear result
            rollback(db);                                                                   //rollback database to previous state before error
            return;                                                                         //return to main
        }
        sqlite3_reset(result);                                                              //reset result to beginning to iterate through results 
        
        i = 1;                                                                              //set i to 1 for output
        cout << "Pick from available list of patients with this name." << endl;
        cout << "****Patient(s) Information****" << endl;
        while (sqlite3_step(result) == SQLITE_ROW){                     //Print patient first and last name with date of birth for user to choose from to see more info
            cout << i << ". " << sqlite3_column_text(result, 1) << " ";                     //print the current count and the first name from table
            if(sqlite3_column_text(result, 2) != NULL){                                     //make sure middle initial is not null
                cout << sqlite3_column_text(result, 2) << ". ";                             //print middle initial if not null
            }
            cout << sqlite3_column_text(result, 3);                                         //print patient last name from database
            cout << " - DOB: ";
            temp = reinterpret_cast<const char*>(sqlite3_column_text(result, 4));           //cast dob of birth to string variable to split for proper output
            cout << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7];     //split date by MM-DD-YYYY
            cout << endl;
            i++;                                                                            //increment i by 1
        }//end while

        cout << endl;
        cout << "Choose patient from list or enter -1 to cancel search and return to main menu." << endl;
        cout << "Enter choice: ";
        cin >> choice;                                                                      //user inputs an int
        cout << endl;                                                                       //skip line for output

        while(!cin || choice < 1 || choice >= i){                                            //validate choice was within the proper range of the output
            if(choice == -1){                                                                   //if user enters -1 return to main
                rollback(db);                                                                   //rollback since cancelling
                return;                                                                         //return to main
            }
            if (!cin){                                                                      //if unexepected inputs clear input
                cin.clear();
                cin.ignore(1000, '\n');
            }
            cout << "That is not a valid patient! Try again!" << endl;                      //prompt user of error and allow reentry
            cin >> choice;
            cout << endl;                                                                   //skip line for output
        }

        sqlite3_reset(result);                                                              //reset result statement to the beginning
        for (int j = 0; j < choice; j++){                                                   //loop runs to the patient chosen by user
            sqlite3_step(result);                                                           //and sets result to that patient row
        }

        patientID = sqlite3_column_int(result, 0);                                          //patientID stores the patients ID from database
    }//end if (choice 2)
    sqlite3_finalize(result);                                                               //reset statement


//query to use patient id to find list of symptoms associated to that patient up for deletion
    query = "select Symptom_ID, Epi_ID, Symptom_Type, Start_Of_Symptom from Symptom where Symptom.Epi_ID = ";
        query += "(select Epi_ID from Epi_Case where Epi_Case.Epi_ID = Symptom.Epi_ID and Patient_ID = ";
        query += "(select Patient_ID from Patient where Patient.Patient_ID = Epi_Case.Patient_ID and Patient.Patient_ID = ";
        query += to_string(patientID) + "));";
    if(sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL) != SQLITE_OK) {         //prepare statement and make sure no errors occur
        LastError = sqlite3_errmsg(db);                                                 //print error message from database
        sqlite3_finalize(result);                                                       //clear result
        cout << "There was an error selecting from Symptom table: " << LastError << endl;                            //print error
        rollback(db);                                                                   //rollback database to previous state before error
        return;                                                                         //return to main
    }

    sqlite3_step(result);
    if(sqlite3_column_text(result, 0) == NULL){                     //if patient id returns null patient does not exist within database, prompt to create patient
        cout << "Patient does not be have any symptoms in the database." << endl;
        sqlite3_finalize(result);                                                       //clear result
        rollback(db);                                                                   //rollback database to previous state before error
        return;                                                                         //return to main
    }
    sqlite3_reset(result);                                                              //reset result to beginning to iterate through results 
        
    i = 1;                                                                              //set i to 1 for output
    cout << "Pick from available list of symptoms associated with this patient." << endl;
    cout << "****Patient Symptom Information****" << endl;
    while (sqlite3_step(result) == SQLITE_ROW){                     //Print patient first and last name with date of birth for user to choose from to see more info
        cout << i << ". Symptom: " << sqlite3_column_text(result, 2) << "  --  ";
        cout << "Start Date: ";
        temp = reinterpret_cast<const char*>(sqlite3_column_text(result, 3));           //cast start date of symptom to string variable to split for proper output
        cout << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7];     //split date by MM-DD-YYYY
        cout << endl;
        i++;                                                                            //increment i by 1
    }//end while

    cout << endl;
    cout << "Choose symptom from list or enter -1 to cancel search and return to main menu." << endl;
    cout << "Enter choice: ";
    cin >> choice;                                                                      //user inputs an int
    cout << endl;                                                                       //skip line for output

    while(!cin || choice < 1 || choice >= i){                                            //validate choice was within the proper range of the output
        if(choice == -1){                                                                //if user enters -1 return to main
            rollback(db);                                                                //rollback since cancelling
            return;                                                                      //return to main
        }
        if (!cin){                                                                       //if unexepected inputs clear input
            cin.clear();
            cin.ignore(1000, '\n');
        }
        cout << "That is not a valid symptom! Try again!" << endl;                       //prompt user of error and allow reentry
        cin >> choice;
        cout << endl;                                                                    //skip line for output
    }

    sqlite3_reset(result);                                                              //reset result statement to the beginning
    for (int j = 0; j < choice; j++){                                                   //loop runs to the patient chosen by user
        sqlite3_step(result);                                                           //and sets result to that patient row
    }

    symptomID = sqlite3_column_int(result, 0);                                          //set int variable to primary key from symptom
                                            
    query = "delete from Symptom where Symptom_ID = " + to_string(symptomID) + ";";
    //cout << "Delete symptom line 5044: " << query << endl;
    if(sqlite3_exec(db, query.c_str(), NULL, NULL, NULL) != SQLITE_OK) {                        //execution will return value to compare against SQLITE_OK
        LastError = sqlite3_errmsg(db);                                                         //store error from database
        cout << "There was an error deleting from Symptom: " << LastError << endl;                //print error message
        rollback(db);                                                                           //rollback database
        return;                                                                                 //break loop and return to main menu
    }

    cout << "Deleting....";                                             //print update
    commit(db);                                                         //commit changes
    cout << "Symptom deleted successfully." << endl;                     //print success
    cout << endl;                                                       //skip line for output
}//end deleteSymptom


//function to delete a patients chronic illness from database
void deleteChronic(sqlite3 *db){
/*
****Chronic Condition****
Chronin_ID                      int                         (Primary Key)
Epi_ID                          int                         (Foreign Key)
Chronic_Condition               varchar(100) NOT NULL
Start_Of_Condition              char(8) NOT NULL
Condition_Severity              int NOT NULL
Condition_Effected_Area         varchar(100) NOT NULL
*/    
    int epiID, patientID, chronicID;                                                                                            //used for storing primary key, foreign keys for table or from other tables
    string userInput, temp, fname, lname;                                                                                       //used for user input
    string query;                                                                                                               //used to query database
    int i = 1, choice, choice2;                                                                                                 //used for loop and validation input
    bool loop = true;                                                                                                           //used to initiate each while loop, break statement will exit
    string LastError;                                                                                                           //used to report error from database
    sqlite3_stmt *result;                                                                                                       //used to store results of query on database
    query = "begin transaction;";
    char *err;


//begin transaction
    if(sqlite3_exec(db, query.c_str(), NULL, NULL, &err) != SQLITE_OK){
        cout << "Error starting transaction: " << err << endl;
        sqlite3_free(err);
        return;
    }

//find if user wants to search by id or name
    cout << "To delete a chronic illness we first need to find the patient it belongs to." << endl;
    cout << "Do you want to pick from a list of patients or by the First and Last name? (Enter: 1 or 2)" << endl;
    cout << "1. Find patient from list" << endl;
    cout << "2. Find patient by First and Last name" << endl;
    cout << "Enter choice: ";

    while(loop){                                        //validate input loop
        cin >> userInput;                               //gather user input
        cout << endl;
        if(isDigit(userInput)){                         //check string input is a number
            choice = stoi(userInput);                   //convert string to int value
            if(choice == 1 || choice == 2){             //check number is 1 or 2
                break;                                  //break loop and continue with program
            }
            else{
                cout << "Invalid input. Entry must be 1 or 2." << endl;     //print error
                cin.clear();                                                //clear input
                cin.ignore(1000, '\n');                                     //ignore anything left
            }
        }
        else{
            cout << "Invalid input. Entry must be a number 1 or 2" << endl;         //print error message
            cin.clear();                //clear input
            cin.ignore(1000, '\n');     //ignore anything left
        }
    }//end while

//if choice is 1
    if(choice == 1){
        //set query to get patient info of patients that have chronic_illness in database regardless of most recent epi_case linked in patient file
        query = "select Patient_ID, First_Name, Middle_Initial, Last_Name, DOB, Epi_ID from Patient where Patient_ID = ";
        query += "(select Patient_ID from Epi_Case where Patient.Patient_ID = Epi_Case.Patient_ID and Epi_Case.Epi_ID = ";
        query += "(select Epi_ID from Chronic_Health_Condition where Epi_Case.Epi_ID = Chronic_Health_Condition.Epi_ID));"; 
        if(sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL) != SQLITE_OK) {         //prepare statement and make sure no errors occur
            LastError = sqlite3_errmsg(db);                                                 //print error message from database
            sqlite3_finalize(result);                                                       //clear result
            cout << "There was an error selecting from Patient table: " << LastError << endl;                            //print error
            rollback(db);                                                                   //rollback database to previous state before error
            return;                                                                         //return to main
        }

        i = 1;                                                                              //set i to 1 for output
        cout << "Pick from list of patients with chronic health condition in database." << endl;                  
        cout << "****Patient(s) Information****" << endl;
        while (sqlite3_step(result) == SQLITE_ROW){                     //Print patient first and last name with date of birth for user to choose from to see more info
            cout << i << ". " << sqlite3_column_text(result, 1) << " ";                     //print the current count and the first name from table
            if(sqlite3_column_text(result, 2) != NULL){                                     //make sure middle initial is not null
                cout << sqlite3_column_text(result, 2) << ". ";                             //print middle initial if not null
            }
            cout << sqlite3_column_text(result, 3);                                         //print patient last name from database
            cout << " - DOB: ";
            temp = reinterpret_cast<const char*>(sqlite3_column_text(result, 4));           //cast dob of birth to string variable to split for proper output
            cout << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7];     //split date by MM-DD-YYYY
            cout << endl;
            i++;                                                                            //increment i by 1
        }//end while
        cout << endl;

        cout << "Choose patient from list or enter -1 to cancel search and return to main menu." << endl;
        cout << "Enter choice: ";
        cin >> choice2;                                                                      //user inputs an int
        cout << endl;                                                                        //skip line for output

        while(!cin || choice2 < 1 || choice2 >= i){                                            //validate choice was within the proper range of the output
            if(choice2 == -1){                                                                   //if user enters -1 return to main
                rollback(db);                                                                   //rollback since cancelling
                return;                                                                         //return to main
            }
            if (!cin){                                                                      //if unexepected inputs clear input
                cin.clear();
                cin.ignore(1000, '\n');
            }
            cout << "That is not a valid patient! Try again!" << endl;                      //prompt user of error and allow reentry
            cin >> choice2;
            cout << endl;                                                                   //skip line for output
        }

        sqlite3_reset(result);                                                              //reset result statement to the beginning
        for (int j = 0; j < choice2; j++){                                                   //loop runs to the patient chosen by user
            sqlite3_step(result);                                                           //and sets result to that patient row
        }

        patientID = sqlite3_column_int(result, 0);                                          //patientID stores the patients ID from database
    }//end if (choice 1)


//if choice is 2
    if(choice == 2){
        cout << "Remember searches are case sensitive." << endl;
        cout << "Please enter the first name of the patient." << endl;
        cout << "Enter name: ";
        cin.clear();                                                                //clear input
        cin.ignore(1000, '\n');                                                     //ignore anything left
        
        while(loop){                                                                //validate first name of patient
            getline(cin, fname);                                                    //getline incase patient name may be multiple parts
            cout << endl;
            if(fname.length() > 0 && fname.length() <= 50){
                if(isWord(fname)) {                                                     //find if string is made up of the alphabet and return boolean 
                    break;                                                              //break loop and continue program
                }
                else {                                                                                                                      
                    cout << "Please only enter letters from the alphabet for first name. Entry is case sensitive." << endl;     //print error message
                    cin.clear();
                }
            }
            else{
                cout << "Invalid input. Entry has a character limit of 50 and cannot be empty." << endl;
                cin.clear();
            }
        }//end while
                
        cout << "Please enter the last name of the patient." << endl;
        cout << "Enter name: ";
        while(loop) {                                                       //validate input of patient last name
            getline(cin, lname);                                            //getline incase patient name may be multiple parts
            cout << endl;                                                   //skip line for output
            if(lname.length() > 0 && lname.length() <= 50){
                if(isWord(lname)) {                                     //if string is made up of the alphabet then break; to end loop
                    break;                                              //break loop and continue program
                }
                else {
                    cout << "Please only enter letter from the alphabet for last name. Entry is case sensitive." << endl;   //print error message
                    cin.clear();
                }
            }
            else{
                cout << "Invalid input. Entry has a character limit of 50 and cannot be empty." << endl;
                cin.clear();
            }    
        }//end while

        //query if multiple patients with the same name, grab any health condition information related to them from the table and return it
        query = "select Patient_ID, First_Name, Middle_Initial, Last_Name, DOB, Epi_ID from Patient where First_Name = ";
            query += "'" + fname + "' and Last_Name = '" + lname + "' and Patient_ID = (select Patient_ID from Epi_Case where ";
            query += "Patient.Patient_ID = Epi_Case.Patient_ID and Epi_Case.Epi_ID = (select Epi_ID from Chronic_Health_Condition where ";
            query += "Epi_Case.Epi_ID = Chronic_Health_Condition.Epi_ID));";                                 
        if(sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL) != SQLITE_OK) {         //prepare statement and make sure no errors occur
            LastError = sqlite3_errmsg(db);                                                 //print error message from database
            sqlite3_finalize(result);                                                       //clear result
            cout << "There was an error selecting from Patient table: " << LastError << endl;              //print error
            rollback(db);                                                                   //rollback database to previous state before error
            return;                                                                         //return to main
        }

        sqlite3_step(result);
        if(sqlite3_column_text(result, 0) == NULL){                     //if patient id returns null patient does not exist within database, prompt to create patient
            cout << "Patient(s) could not be found in database. Check entry or create new patient." << endl << endl;
            sqlite3_finalize(result);                                                       //clear result
            rollback(db);                                                                   //rollback database to previous state before error
            return;                                                                         //return to main
        }
        sqlite3_reset(result);                                                              //reset result to beginning to iterate through results 
        
        i = 1;                                                                              //set i to 1 for output
        cout << "Pick from available list of patients with this name." << endl;
        cout << "****Patient(s) Information****" << endl;
        while (sqlite3_step(result) == SQLITE_ROW){                     //Print patient first and last name with date of birth for user to choose from to see more info
            cout << i << ". " << sqlite3_column_text(result, 1) << " ";                     //print the current count and the first name from table
            if(sqlite3_column_text(result, 2) != NULL){                                     //make sure middle initial is not null
                cout << sqlite3_column_text(result, 2) << ". ";                             //print middle initial if not null
            }
            cout << sqlite3_column_text(result, 3);                                         //print patient last name from database
            cout << " - DOB: ";
            temp = reinterpret_cast<const char*>(sqlite3_column_text(result, 4));           //cast dob of birth to string variable to split for proper output
            cout << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7];     //split date by MM-DD-YYYY
            cout << endl;
            i++;                                                                            //increment i by 1
        }//end while

        cout << endl;
        cout << "Choose patient from list or enter -1 to cancel search and return to main menu." << endl;
        cout << "Enter choice: ";
        cin >> choice;                                                                      //user inputs an int
        cout << endl;                                                                       //skip line for output

        while(!cin || choice < 1 || choice >= i){                                            //validate choice was within the proper range of the output
            if(choice == -1){                                                                   //if user enters -1 return to main
                rollback(db);                                                                   //rollback since cancelling
                return;                                                                         //return to main
            }
            if (!cin){                                                                      //if unexepected inputs clear input
                cin.clear();
                cin.ignore(1000, '\n');
            }
            cout << "That is not a valid patient! Try again!" << endl;                      //prompt user of error and allow reentry
            cin >> choice;
            cout << endl;                                                                   //skip line for output
        }

        sqlite3_reset(result);                                                              //reset result statement to the beginning
        for (int j = 0; j < choice; j++){                                                   //loop runs to the patient chosen by user
            sqlite3_step(result);                                                           //and sets result to that patient row
        }

        patientID = sqlite3_column_int(result, 0);                                          //patientID stores the patients ID from database
    }//end if (choice 2)
    sqlite3_finalize(result);                                                               //reset statement


//query to use patient id to find list of chronic illness associated to that patient up for deletion
    query = "select Chronic_ID, Epi_ID, Chronic_Condition, Start_Of_Condition from Chronic_Health_Condition where Chronic_Health_Condition.Epi_ID = ";
        query += "(select Epi_ID from Epi_Case where Epi_Case.Epi_ID = Chronic_Health_Condition.Epi_ID and Patient_ID = ";
        query += "(select Patient_ID from Patient where Patient.Patient_ID = Epi_Case.Patient_ID and Patient.Patient_ID = ";
        query += to_string(patientID) + "));";
    if(sqlite3_prepare_v2(db, query.c_str(), -1, &result, NULL) != SQLITE_OK) {         //prepare statement and make sure no errors occur
        LastError = sqlite3_errmsg(db);                                                 //print error message from database
        sqlite3_finalize(result);                                                       //clear result
        cout << "There was an error selecting from Chronic Health Condition table: " << LastError << endl;             //print error
        rollback(db);                                                                   //rollback database to previous state before error
        return;                                                                         //return to main
    }

    sqlite3_step(result);
    if(sqlite3_column_text(result, 0) == NULL){                     //if patient id returns null patient does not exist within database, prompt to create patient
        cout << "Patient does not be have any chronic illness in the database." << endl;
        sqlite3_finalize(result);                                                       //clear result
        rollback(db);                                                                   //rollback database to previous state before error
        return;                                                                         //return to main
    }
    sqlite3_reset(result);                                                              //reset result to beginning to iterate through results 
        
    i = 1;                                                                              //set i to 1 for output
    cout << "Pick from available list of chronic health conditions associated with this patient." << endl;
    cout << "****Patient Condition Information****" << endl;
    while (sqlite3_step(result) == SQLITE_ROW){                     //Print patient first and last name with date of birth for user to choose from to see more info
        cout << i << ". Health Condition: " << sqlite3_column_text(result, 2) << "  --  ";
        cout << "Start Date: ";
        temp = reinterpret_cast<const char*>(sqlite3_column_text(result, 3));           //cast start date of symptom to string variable to split for proper output
        cout << temp[0] << temp[1] << "-" << temp[2] << temp[3] << "-" << temp[4] << temp[5] << temp[6] << temp[7];     //split date by MM-DD-YYYY
        cout << endl;
        i++;                                                                            //increment i by 1
    }//end while

    cout << endl;
    cout << "Choose patient from list or enter -1 to cancel search and return to main menu." << endl;
    cout << "Enter choice: ";
    cin >> choice;                                                                      //user inputs an int
    cout << endl;
        
    while(!cin || choice < 1 || choice >= i){                                           //validate choice was within the proper range of the output
        if(choice == -1){                                                                   //if user enters -1 return to main
            rollback(db);                                                                   //rollback since cancelling
            return;                                                                         //return to main
        }
        if (!cin){                                                                      //if unexepected inputs clear input
            cin.clear();
            cin.ignore(1000, '\n');
        }
        cout << "That is not a valid patient! Try again!" << endl;                      //prompt user of error and allow reentry
        cin >> choice;
        cout << endl;
    }

    sqlite3_reset(result);                                                              //reset result statement to the beginning
    for (int j = 0; j < choice; j++){                                                   //loop runs to the patient chosen by user
        sqlite3_step(result);                                                           //and sets result to that patient row
    }

    chronicID = sqlite3_column_int(result, 0);                                          //set int variable to primary key from symptom
                                            
    query = "delete from Chronic_Health_Condition where Chronic_ID = " + to_string(chronicID) + ";";
    //cout << "Delete chronic line 5351: " << query << endl;
    if(sqlite3_exec(db, query.c_str(), NULL, NULL, NULL) != SQLITE_OK) {                                //execution will return value to compare against SQLITE_OK
        LastError = sqlite3_errmsg(db);                                                                 //store error from database
        cout << "There was an error deleting from Chronic Health Condition: " << LastError << endl;     //print error message
        rollback(db);                                                                                   //rollback database
        return;                                                                                         //break loop and return to main menu
    }

    cout << "Deleting....";                                                                 //print update
    commit(db);                                                                             //commit changes
    cout << "Chronic Health Condition deleted successfully." << endl;                       //print success
    cout << endl;                                                                           //skip line for output
}//end deleteChronic


//function to print main menu
void MainMenu(){
    cout << "************ Menu ************" << endl;
    cout << "1. Search Database" << endl;
    cout << "2. Create New Patient" << endl;
    cout << "3. Create New Exposure Case" << endl;
    cout << "4. Edit Patient Info" << endl;
    cout << "5. Edit Exposure Case" << endl;
    cout << "6. Delete Symptom" << endl;
    cout << "7. Delete Chronic Condition" << endl;
    cout << "8. Exit Database" << endl;
}//end MainMenu

//
//Main
//
int main() {
	int rc;             									//for errors
    sqlite3 * db;       									//pointer to database
    sqlite3_stmt *pRes;                                     //The previous results of a query statement
    string query;       								    //string for sql statements
    char * err;         									//pointer to error message
    string DbMenu, DOB, Fname, Lname, ID;         		//used for menu navigation by user
    int Menu, IDnumber;
    bool boolean = true;        //boolean for internal loop
    bool Run = true;            //boolean for program termination
    
    //Open Database //////////////////////////////////////////
    rc = sqlite3_open_v2("Exposure Tracking.db", &db, SQLITE_OPEN_READWRITE, NULL);      		//open database using built in function

    if(rc != SQLITE_OK) {                                   							//check if the database could be opened successfully
        cout << "Error in connection: " << sqlite3_errmsg(db);                          //print error message with exact error using header function
        sqlite3_close(db);  															//close database (DO EVERYTIME and exception or error has happened. Otherwise could corrept entire database.)
        return -1;          															//return negative one to show program ended with error
    }
    else {
        cout << "Database opened successfully" << endl;     					//print message that database was opened successfully
    }

    //editEpi(db);
    //cout << "IT's ALIVE! IT'S ALIVE!" << endl; 

    ////////////////////////////////////////////////////////////////////////
    //Main Loop for Database
    while(Run){                                                                 //main program loop
        MainMenu();                                                             //print main menu
        cout << "Enter menu choice: ";

        while(boolean){                                                         //validate input
            cin >> DbMenu;                                                      
            cout << endl;
            if(DbMenu == "8"){                                                  //if 8 follow lable to exit program
                Run = false;
                goto here;
            }
            else if(isDigit(DbMenu)){                                           //isDigit returns boolean if entry is an int
                if(DbMenu >= "1" && DbMenu <= "7"){                             //check that input is between menu size
                    Menu = stoi(DbMenu);                                        //convert string to int
                    boolean = false;                                            //change loop condition to false
                }
                else {
                    cout << "Please only enter a number 1 - 8" << endl;         //print error
                    cin.clear();
                    cin.ignore(1000, '\n');
                }
            }//end else if
            else{
                cout << "Please only enter an integer number." << endl;
                cin.clear();
                cin.ignore(1000, '\n');
            }
        }//end while
        boolean = true;         //reset boolean value after validation loop ends

        //switch case for main menu
        switch(Menu){
            //Search Database (multiple searches)
            case 1:
                searchDatabase(db);                     
                break;

            //Create New Patient
            case 2:
                createPatient(db);
                break;

            //Create New Exposure Case
            case 3:
                createEpi(db);
                break;

            //Edit Patient Info
            case 4:
                editPatient(db);
                break;

            //Edit Exposure Table
            case 5:
                editEpi(db);
                break;

            //Delete from Symptom table
            case 6:
                deleteSymptom(db);
                break;
            
            //Delete from chronic condition table
            case 7:
                deleteChronic(db);
                break;

        }//end switch for program
    }//end main while loop for program

here:       //label sends the program here immediately if the user exits the database to ensure no other code executes 
    //Exit message and close database
    cout << "Closing database...";                              //print before hand in case it errors
    sqlite3_close(db);                                          //close database
    cout << "Database closed." << endl << endl;                 //print success in closure
    cout << "See you space cowboy..." << endl;                  //print farewell
}//end main
//
//Main
//

//Function to print the results of the first query statement
int callback(void *data, int argc, char **argv, char **azColName) {
    for(int i = 0; i < argc; i++) {  	
            cout << azColName[i] << ": ";     			//print the column name
            if(argv[i] != NULL) {             				//if not NULL print the column data
                cout << argv[i];                       //print the value of the column
            }//end if
            cout << endl;  						//go to next line if the column is empty
        }//end for
    cout << endl;
    return 0;
}//end callback