Program Name: Exposure Tracking Database
Author: Michael Krause
Last Update: May 10, 2022
Purpose: To design and create a database and then implement a program to interact with the database. 
Command line user interface to search the database in multiple ways. Add patients and create new exposure cases.
Edit any patient or exposure case and the info there in. Remove smaller tables from the database. All in an effort
to track any food born illness to stop a potential pathogen from spreading or to track outbreaks occuring in a community
to call the proper response. 


Problem Statement:
Tracking of communicable diseases is an extremely important process of any public health department. For any health
department the goal is to track infectious disease, big or small, and squash it before it takes over a city or worse.
Investigators are the staff from the public health department who investigate each case by getting in touch with the
patient and collecting a wealth of information on an individual patient and anyone they may have come in contact with.
The only way the public health department can do this is with an organized and structured database management system
that collects all of a patients information. The collected data needs to be stored for later access for data analysis,
viewing, or data manipulation. For this I created a small database in SQLITE filled with mock data to run all of my
tests and to verify program execution. 


My Solution:
My database solution sees that an investigator can register patients in the database and assigns a unique primary key
to each patient. If a patient comes in without a pathogen that patients information will still be stored in the 
database in case they ever come back with a pathogen. If a patient does have a pathogen their can only be an exposure 
case if they have a patient file already in the database to link it to. If there is not one the Investigator is 
directed back to the main menu with the message they need to create a new patient file before proceeding.

Once an investigator has either created a new patient or finds the patient in the database already, they can now begin
to collect all the information required for the exposure case, collect multiple pets, collect multiple symptoms, and
collect multiple chronic illnesses that will all be linked to the Exposure Case. A single patient can have multiple
exposure cases but only the most recent made Epi case will be linked in the patients file. 

Once a patient and/or epi case is created it's important to be able edit any piece of data from the data base to either 
update patient information or fix an error on input. So the investigator can use the program to edit any piece of 
information gathered during data entry. 

- Investigator can Search database by Patient ID
- Investigator can Search database by First and Last Name
- Investigator can Search database by First Name, Last Name, and Date of Birth
- Investigator can Search database by Pathogen to return list of patients with that pathogen
- Investigator can Search database by Pathogen and County to return list of patients with that pathogen

- Investigator can enter a New Patient in database
- Investigator can enter a New Exposure Case in database
- Investigator can Edit a Patient File in database
- Investigator can Edit an Exposure Case in database
- Investigator can Edit any Pet in database searched by Patient
- Investigator can Edit any Symptom in database searched by Patient
- Investigator can Edit any Chronic Illness in database searched by Patient
- Investigator can Delete any Symptom in database searched by Patient
- Investigator can Delete any Chronic Illness in database by searched by Patient

When the investigator is finished and chooses to exit the program, the program will close the connection with the database 
and print a farewell message. The next time the Investigator comes back to the program it will reconnect with the database
and all previous changes from program execution will show instead of the previous data. 


//To do list:
1. First time working with database. Instead of functions make it more object oriented.

2. Go back through and replace a lot using recursion. Focused on just getting a working build and finishing documentation before
making updates.

3. More validation functions instead of repeating validation checks. Most are needed because of output and cin errors bouncing
between functions or calling the same one multiple times. getline causes a lot of these issues, find work around in function.

4. Queue instead of an array, easy change but not one I was about to do so close to the project being due.

5. Add a login and logout at beginning of program. When Investigator logs in with their credentials an auto grab of the date and time
is performed and added to the clock-in of the Investigator. Similar for when they logout and grab the date and time to store in clock
out. The rate is already inserted and the hours is a metric we can calculate automatically by the clock in clock out and the pay of 
the Investigator is another metric calculated by hours * rate. 

6. Create a new table off of Investigator to have clock-in, clock-out, rate, and hours columns. Because the Investigator may be clocking
in and out multiple times a day. It also keeps a record of the Investigators Time Card. Maybe a bridge table for the multiple inputs in a
day and then have a Time Card table linked that just tracks the total hours from each day. Each day would have to have primary key. 

7. Add locks to insert, deletion, and update queries on database to keep database integrity if multiple investigators using the database
at one time.